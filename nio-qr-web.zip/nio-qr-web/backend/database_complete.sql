
-- =====================================================
-- BANCO DE DADOS PATRIMÔNIOTECH - VERSÃO COMPLETA
-- Sistema integrado Web + Mobile
-- =====================================================

-- Criar banco de dados
CREATE DATABASE patrimonio_tech;

-- Conectar ao banco
\c patrimonio_tech;

-- Extensões necessárias
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- =======================
-- TABELAS DO SISTEMA
-- =======================

-- Tabela de usuários (com suporte mobile)
CREATE TABLE usuarios (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    usuario VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE,
    senha VARCHAR(100) NOT NULL,
    telefone VARCHAR(20),
    cargo VARCHAR(50),
    status VARCHAR(20) DEFAULT 'Ativo' CHECK (status IN ('Ativo', 'Inativo')),
    permissoes JSONB DEFAULT '{}',
    ultimo_acesso TIMESTAMP,
    dispositivo_mobile VARCHAR(100),
    push_token VARCHAR(255),
    preferencias_mobile JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de localizações
CREATE TABLE localizacoes (
    id SERIAL PRIMARY KEY,
    bloco VARCHAR(50),
    andar VARCHAR(10),
    setor VARCHAR(100) NOT NULL,
    sala VARCHAR(50) NOT NULL,
    descricao TEXT,
    capacidade INTEGER,
    responsavel VARCHAR(100),
    observacoes TEXT,
    coordenadas_gps POINT,
    codigo_qr VARCHAR(100) UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de patrimônios (otimizada para mobile)
CREATE TABLE patrimonios (
    id SERIAL PRIMARY KEY,
    codigo VARCHAR(50) UNIQUE NOT NULL,
    nome VARCHAR(200) NOT NULL,
    descricao TEXT,
    categoria VARCHAR(100) NOT NULL,
    subcategoria VARCHAR(100),
    localizacao_id INTEGER REFERENCES localizacoes(id),
    responsavel VARCHAR(100),
    valor_aquisicao DECIMAL(15,2),
    valor_atual DECIMAL(15,2),
    data_aquisicao DATE,
    garantia DATE,
    fornecedor VARCHAR(200),
    numero_serie VARCHAR(100),
    status VARCHAR(20) DEFAULT 'Ativo' CHECK (status IN ('Ativo', 'Inativo', 'Manutenção', 'Descartado')),
    observacoes TEXT,
    qr_code VARCHAR(100) UNIQUE,
    foto VARCHAR(255),
    foto_mobile VARCHAR(255),
    thumbnail VARCHAR(255),
    ultima_verificacao TIMESTAMP,
    verificado_por INTEGER REFERENCES usuarios(id),
    tags JSONB DEFAULT '[]',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de manutenções (com suporte mobile)
CREATE TABLE manutencoes (
    id SERIAL PRIMARY KEY,
    patrimonio_id INTEGER NOT NULL REFERENCES patrimonios(id),
    tipo VARCHAR(50) NOT NULL CHECK (tipo IN ('Preventiva', 'Corretiva', 'Preditiva')),
    titulo VARCHAR(200) NOT NULL,
    descricao TEXT NOT NULL,
    prioridade VARCHAR(20) DEFAULT 'Média' CHECK (prioridade IN ('Baixa', 'Média', 'Alta', 'Urgente')),
    status VARCHAR(20) DEFAULT 'Pendente' CHECK (status IN ('Pendente', 'Em Andamento', 'Concluída', 'Cancelada')),
    data_solicitacao DATE DEFAULT CURRENT_DATE,
    data_agendamento DATE,
    data_conclusao DATE,
    responsavel_solicitacao VARCHAR(100),
    responsavel_execucao VARCHAR(100),
    custo DECIMAL(10,2),
    observacoes TEXT,
    fotos_antes JSONB DEFAULT '[]',
    fotos_depois JSONB DEFAULT '[]',
    assinatura_digital TEXT,
    localizacao_gps POINT,
    tempo_execucao INTEGER, -- em minutos
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de seguros
CREATE TABLE seguros (
    id SERIAL PRIMARY KEY,
    patrimonio_id INTEGER NOT NULL REFERENCES patrimonios(id),
    seguradora VARCHAR(200) NOT NULL,
    numero_apolice VARCHAR(100) NOT NULL,
    tipo_cobertura VARCHAR(100),
    valor_segurado DECIMAL(15,2) NOT NULL,
    valor_premio DECIMAL(10,2),
    data_inicio DATE,
    data_vencimento DATE,
    status VARCHAR(20) DEFAULT 'Ativo' CHECK (status IN ('Ativo', 'Vencido', 'Cancelado')),
    observacoes TEXT,
    documentos JSONB DEFAULT '[]',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de verificações mobile
CREATE TABLE verificacoes_mobile (
    id SERIAL PRIMARY KEY,
    patrimonio_id INTEGER NOT NULL REFERENCES patrimonios(id),
    usuario_id INTEGER NOT NULL REFERENCES usuarios(id),
    tipo_verificacao VARCHAR(50) NOT NULL CHECK (tipo_verificacao IN ('QR_Scan', 'Visual', 'Localização', 'Estado')),
    resultado VARCHAR(20) NOT NULL CHECK (resultado IN ('OK', 'Problema', 'Não Encontrado')),
    observacoes TEXT,
    foto VARCHAR(255),
    localizacao_gps POINT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de sincronização mobile
CREATE TABLE sync_mobile (
    id SERIAL PRIMARY KEY,
    usuario_id INTEGER NOT NULL REFERENCES usuarios(id),
    tabela VARCHAR(50) NOT NULL,
    registro_id INTEGER NOT NULL,
    acao VARCHAR(20) NOT NULL CHECK (acao IN ('CREATE', 'UPDATE', 'DELETE')),
    dados JSONB,
    sincronizado BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de logs de usuários (expandida)
CREATE TABLE user_logs (
    id SERIAL PRIMARY KEY,
    usuario_id INTEGER REFERENCES usuarios(id),
    acao VARCHAR(50),
    modulo VARCHAR(50),
    detalhes TEXT,
    ip_address INET,
    user_agent TEXT,
    dispositivo VARCHAR(50) DEFAULT 'Web',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de notificações push
CREATE TABLE notificacoes (
    id SERIAL PRIMARY KEY,
    usuario_id INTEGER REFERENCES usuarios(id),
    titulo VARCHAR(200) NOT NULL,
    mensagem TEXT NOT NULL,
    tipo VARCHAR(50) DEFAULT 'info' CHECK (tipo IN ('info', 'warning', 'error', 'success')),
    lida BOOLEAN DEFAULT FALSE,
    enviada_push BOOLEAN DEFAULT FALSE,
    data_envio TIMESTAMP,
    dados_extras JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =======================
-- INSERIR DADOS DE EXEMPLO
-- =======================

-- Usuários (com dados mobile)
INSERT INTO usuarios (nome, usuario, email, senha, telefone, cargo, permissoes, preferencias_mobile) VALUES
('Administrador do Sistema', 'admin', 'admin@sistema.com', 'admin', '(11) 99999-0000', 'Administrador', 
'{"patrimonio": "admin", "relatorios": "admin", "configuracoes": "admin", "usuarios": "admin", "qrcodes": "admin", "localizacao": "admin", "manutencao": "admin", "seguros": "admin"}',
'{"tema": "dark", "notificacoes": true, "sync_automatico": true}'),

('João Silva Santos', 'joao.silva', 'joao@empresa.com', '123456', '(11) 98888-1111', 'Analista de TI', 
'{"patrimonio": "editor", "qrcodes": "editor", "localizacao": "viewer", "manutencao": "editor"}',
'{"tema": "light", "notificacoes": true, "sync_automatico": false}'),

('Maria Costa Oliveira', 'maria.costa', 'maria@empresa.com', '123456', '(11) 97777-2222', 'Assistente Administrativo', 
'{"patrimonio": "viewer", "relatorios": "viewer", "localizacao": "viewer"}',
'{"tema": "light", "notificacoes": false, "sync_automatico": true}'),

('Pedro Ferreira Lima', 'pedro.ferreira', 'pedro@empresa.com', '123456', '(11) 96666-3333', 'Técnico de Manutenção', 
'{"patrimonio": "viewer", "manutencao": "admin", "localizacao": "viewer"}',
'{"tema": "dark", "notificacoes": true, "sync_automatico": true}'),

('Ana Paula Rodrigues', 'ana.paula', 'ana@empresa.com', '123456', '(11) 95555-4444', 'Gerente Financeiro', 
'{"patrimonio": "editor", "relatorios": "admin", "seguros": "admin", "configuracoes": "editor"}',
'{"tema": "light", "notificacoes": true, "sync_automatico": false}');

-- Localizações (com QR codes)
INSERT INTO localizacoes (bloco, andar, setor, sala, descricao, capacidade, responsavel, codigo_qr) VALUES
('A', '1', 'Administração', '101', 'Sala da Diretoria Executiva', 8, 'João Silva Santos', 'QR_LOC_A101'),
('A', '1', 'Administração', '102', 'Sala de Reuniões Principal', 12, 'Maria Costa Oliveira', 'QR_LOC_A102'),
('A', '1', 'Administração', '103', 'Secretaria Geral', 4, 'Ana Paula Rodrigues', 'QR_LOC_A103'),
('A', '2', 'Financeiro', '201', 'Departamento Financeiro', 6, 'Ana Paula Rodrigues', 'QR_LOC_A201'),
('A', '2', 'Financeiro', '202', 'Contabilidade', 4, 'Ana Paula Rodrigues', 'QR_LOC_A202'),
('B', '1', 'TI', '101', 'Datacenter Principal', 2, 'João Silva Santos', 'QR_LOC_B101'),
('B', '1', 'TI', '102', 'Suporte Técnico', 6, 'João Silva Santos', 'QR_LOC_B102'),
('B', '1', 'TI', '103', 'Desenvolvimento', 8, 'João Silva Santos', 'QR_LOC_B103'),
('B', '2', 'Operações', '201', 'Centro de Controle', 4, 'Pedro Ferreira Lima', 'QR_LOC_B201'),
('B', '2', 'Operações', '202', 'Almoxarifado', 2, 'Pedro Ferreira Lima', 'QR_LOC_B202'),
('C', '1', 'RH', '101', 'Recursos Humanos', 6, 'Maria Costa Oliveira', 'QR_LOC_C101'),
('C', '1', 'RH', '102', 'Treinamento', 10, 'Maria Costa Oliveira', 'QR_LOC_C102'),
('C', '2', 'Comercial', '201', 'Vendas', 8, 'Ana Paula Rodrigues', 'QR_LOC_C201'),
('C', '2', 'Comercial', '202', 'Marketing', 6, 'Ana Paula Rodrigues', 'QR_LOC_C202');

-- Patrimônios (com QR codes únicos)
INSERT INTO patrimonios (codigo, nome, descricao, categoria, subcategoria, localizacao_id, responsavel, valor_aquisicao, valor_atual, data_aquisicao, garantia, fornecedor, numero_serie, qr_code, tags) VALUES

-- Informática
('NB-001', 'Notebook Dell Inspiron 15 3000', 'Notebook para uso administrativo', 'Informática', 'Notebooks', 1, 'João Silva Santos', 2500.00, 2000.00, '2024-01-15', '2026-01-15', 'Dell Brasil', 'DL15INS2024001', 'QR_NB_001', '["portatil", "dell", "administrativo"]'),
('NB-002', 'Notebook Lenovo ThinkPad E14', 'Notebook para desenvolvimento', 'Informática', 'Notebooks', 8, 'João Silva Santos', 3800.00, 3200.00, '2024-02-10', '2026-02-10', 'Lenovo', 'LN14TPE2024002', 'QR_NB_002', '["portatil", "lenovo", "desenvolvimento"]'),
('NB-003', 'MacBook Air M2', 'Notebook para design', 'Informática', 'Notebooks', 14, 'Ana Paula Rodrigues', 8500.00, 7800.00, '2024-03-05', '2025-03-05', 'Apple', 'AP13AIR2024003', 'QR_NB_003', '["portatil", "apple", "design"]'),

('PC-001', 'Desktop Dell Optiplex 7090', 'Computador desktop administrativo', 'Informática', 'Desktops', 2, 'Maria Costa Oliveira', 3200.00, 2800.00, '2024-01-20', '2027-01-20', 'Dell Brasil', 'DL90OPT2024001', 'QR_PC_001', '["desktop", "dell", "administrativo"]'),
('PC-002', 'Workstation HP Z240', 'Estação de trabalho para TI', 'Informática', 'Workstations', 7, 'João Silva Santos', 5500.00, 4800.00, '2024-02-15', '2027-02-15', 'HP Brasil', 'HP240WST2024002', 'QR_PC_002', '["workstation", "hp", "ti"]'),

('MON-001', 'Monitor LG 24" Full HD', 'Monitor LED 24 polegadas', 'Informática', 'Monitores', 1, 'João Silva Santos', 650.00, 500.00, '2024-01-15', '2025-07-15', 'LG Electronics', 'LG24FHD2024001', 'QR_MON_001', '["monitor", "lg", "24pol"]'),
('MON-002', 'Monitor Samsung 27" 4K', 'Monitor LED 27 polegadas 4K', 'Informática', 'Monitores', 8, 'João Silva Santos', 1200.00, 1000.00, '2024-02-20', '2025-08-20', 'Samsung', 'SM274K2024002', 'QR_MON_002', '["monitor", "samsung", "4k"]'),

('IMP-001', 'Impressora HP LaserJet Pro M404n', 'Impressora laser monocromática', 'Informática', 'Impressoras', 3, 'Maria Costa Oliveira', 800.00, 650.00, '2024-01-25', '2025-07-25', 'HP Brasil', 'HP404LJ2024001', 'QR_IMP_001', '["impressora", "hp", "laser"]'),

-- Mobiliário
('MESA-001', 'Mesa de Escritório Executiva', 'Mesa em madeira mogno 1,60x0,80m', 'Mobiliário', 'Mesas', 1, 'João Silva Santos', 1200.00, 1000.00, '2024-01-10', NULL, 'Móveis São Carlos', 'MSG160EX2024001', 'QR_MESA_001', '["mesa", "executiva", "madeira"]'),
('CADEIRA-001', 'Cadeira Presidente Couro', 'Cadeira giratória em couro legítimo', 'Mobiliário', 'Cadeiras', 1, 'João Silva Santos', 800.00, 650.00, '2024-01-10', '2025-01-10', 'Flex Cadeiras', 'FLX800PR2024001', 'QR_CADEIRA_001', '["cadeira", "couro", "presidente"]'),

-- Equipamentos
('AR-001', 'Ar Condicionado Split 12000 BTUs', 'Ar condicionado inverter', 'Equipamentos', 'Climatização', 1, 'Pedro Ferreira Lima', 1800.00, 1500.00, '2024-01-30', '2025-07-30', 'Midea', 'MD12INV2024001', 'QR_AR_001', '["ar-condicionado", "split", "12000btu"]'),
('PROJ-001', 'Projetor Epson PowerLite X41+', 'Projetor multimídia 3600 lumens', 'Equipamentos', 'Audiovisual', 2, 'João Silva Santos', 2800.00, 2400.00, '2024-02-12', '2025-08-12', 'Epson Brasil', 'EPX41PW2024001', 'QR_PROJ_001', '["projetor", "epson", "3600lm"]'),

-- Veículos
('VEI-001', 'Fiat Uno Vivace 1.0', 'Veículo para uso administrativo', 'Veículos', 'Automóveis', NULL, 'Pedro Ferreira Lima', 35000.00, 28000.00, '2023-08-15', '2026-08-15', 'Fiat Brasil', 'FIAT1002023001', 'QR_VEI_001', '["veiculo", "fiat", "uno"]'),
('VEI-002', 'Honda Civic LX 2.0', 'Veículo executivo', 'Veículos', 'Automóveis', NULL, 'João Silva Santos', 85000.00, 75000.00, '2023-12-10', '2026-12-10', 'Honda Brasil', 'HON20LX2023002', 'QR_VEI_002', '["veiculo", "honda", "civic"]');

-- Manutenções
INSERT INTO manutencoes (patrimonio_id, tipo, titulo, descricao, prioridade, status, data_solicitacao, data_agendamento, responsavel_solicitacao, responsavel_execucao, custo, tempo_execucao) VALUES
(1, 'Preventiva', 'Limpeza e Atualização Sistema', 'Limpeza interna, troca pasta térmica e atualização do sistema operacional', 'Média', 'Concluída', '2024-06-15', '2024-06-20', 'João Silva Santos', 'Pedro Ferreira Lima', 150.00, 120),
(2, 'Corretiva', 'Reparo Teclado', 'Substituição de teclas danificadas do teclado', 'Alta', 'Concluída', '2024-07-02', '2024-07-05', 'João Silva Santos', 'Pedro Ferreira Lima', 80.00, 45),
(8, 'Corretiva', 'Troca Cartucho Toner', 'Substituição do cartucho de toner', 'Baixa', 'Concluída', '2024-07-08', '2024-07-10', 'Maria Costa Oliveira', 'Pedro Ferreira Lima', 120.00, 15),
(11, 'Preventiva', 'Manutenção Ar Condicionado', 'Limpeza de filtros e verificação gás refrigerante', 'Média', 'Pendente', '2024-07-10', '2024-07-15', 'Pedro Ferreira Lima', 'Pedro Ferreira Lima', 200.00, NULL),
(3, 'Preditiva', 'Verificação Bateria MacBook', 'Análise do estado da bateria e performance', 'Baixa', 'Em Andamento', '2024-07-11', '2024-07-12', 'Ana Paula Rodrigues', 'Pedro Ferreira Lima', 0.00, NULL);

-- Seguros
INSERT INTO seguros (patrimonio_id, seguradora, numero_apolice, tipo_cobertura, valor_segurado, valor_premio, data_inicio, data_vencimento) VALUES
(13, 'Bradesco Seguros', 'APL-VEI-2024-001', 'Compreensivo', 28000.00, 2400.00, '2024-01-01', '2024-12-31'),
(14, 'Porto Seguro', 'APL-VEI-2024-002', 'Compreensivo', 75000.00, 4800.00, '2024-01-01', '2024-12-31'),
(1, 'Tokio Marine', 'APL-EQP-2024-003', 'Roubo e Furto', 2000.00, 180.00, '2024-02-01', '2025-01-31');

-- Verificações mobile de exemplo
INSERT INTO verificacoes_mobile (patrimonio_id, usuario_id, tipo_verificacao, resultado, observacoes) VALUES
(1, 2, 'QR_Scan', 'OK', 'Equipamento em perfeito estado'),
(2, 2, 'Visual', 'OK', 'Funcionando normalmente'),
(8, 3, 'QR_Scan', 'Problema', 'Impressora com problema no papel'),
(11, 4, 'Localização', 'OK', 'Ar condicionado instalado corretamente');

-- Notificações de exemplo
INSERT INTO notificacoes (usuario_id, titulo, mensagem, tipo) VALUES
(2, 'Manutenção Agendada', 'Manutenção do notebook NB-001 agendada para amanhã', 'info'),
(4, 'Urgente: Ar Condicionado', 'Ar condicionado AR-001 necessita manutenção urgente', 'warning'),
(1, 'Relatório Mensal', 'Relatório mensal de patrimônio disponível', 'success');

-- =======================
-- VIEWS E FUNÇÕES
-- =======================

-- View para estatísticas do dashboard (mobile + web)
CREATE OR REPLACE VIEW view_dashboard_stats AS
SELECT
    COUNT(*) as total_patrimonios,
    COUNT(*) FILTER (WHERE status = 'Ativo') as patrimonios_ativos,
    COUNT(*) FILTER (WHERE status = 'Manutenção') as patrimonios_manutencao,
    COUNT(*) FILTER (WHERE status = 'Inativo') as patrimonios_inativos,
    COALESCE(SUM(valor_atual), 0) as valor_total,
    (SELECT COUNT(*) FROM localizacoes) as total_localizacoes,
    (SELECT COUNT(*) FROM manutencoes WHERE status IN ('Pendente', 'Em Andamento')) as manutencoes_pendentes,
    (SELECT COUNT(*) FROM usuarios WHERE status = 'Ativo') as usuarios_ativos,
    (SELECT COUNT(*) FROM seguros WHERE status = 'Ativo') as seguros_ativos,
    (SELECT COUNT(*) FROM verificacoes_mobile WHERE DATE(created_at) = CURRENT_DATE) as verificacoes_hoje
FROM patrimonios;

-- View para patrimônios com QR codes
CREATE OR REPLACE VIEW view_patrimonios_qr AS
SELECT 
    p.id,
    p.codigo,
    p.nome,
    p.categoria,
    p.qr_code,
    p.status,
    l.setor,
    l.sala,
    l.bloco,
    l.andar,
    p.responsavel,
    p.valor_atual,
    p.foto,
    p.thumbnail
FROM patrimonios p
LEFT JOIN localizacoes l ON p.localizacao_id = l.id
WHERE p.qr_code IS NOT NULL;

-- View para manutenções mobile
CREATE OR REPLACE VIEW view_manutencoes_mobile AS
SELECT 
    m.*,
    p.codigo as patrimonio_codigo,
    p.nome as patrimonio_nome,
    p.qr_code,
    l.setor,
    l.sala,
    l.bloco
FROM manutencoes m
JOIN patrimonios p ON m.patrimonio_id = p.id
LEFT JOIN localizacoes l ON p.localizacao_id = l.id
ORDER BY m.created_at DESC;

-- View para verificações recentes
CREATE OR REPLACE VIEW view_verificacoes_recentes AS
SELECT 
    v.*,
    p.codigo as patrimonio_codigo,
    p.nome as patrimonio_nome,
    u.nome as usuario_nome,
    l.setor,
    l.sala
FROM verificacoes_mobile v
JOIN patrimonios p ON v.patrimonio_id = p.id
JOIN usuarios u ON v.usuario_id = u.id
LEFT JOIN localizacoes l ON p.localizacao_id = l.id
WHERE v.created_at >= CURRENT_DATE - INTERVAL '7 days'
ORDER BY v.created_at DESC;

-- Função para gerar QR code único
CREATE OR REPLACE FUNCTION gerar_qr_code(prefixo TEXT DEFAULT 'QR')
RETURNS TEXT AS $$
DECLARE
    novo_codigo TEXT;
    contador INTEGER := 1;
BEGIN
    LOOP
        novo_codigo := prefixo || '_' || LPAD(contador::TEXT, 6, '0');
        
        -- Verificar se já existe em patrimônios ou localizações
        IF NOT EXISTS (
            SELECT 1 FROM patrimonios WHERE qr_code = novo_codigo
            UNION
            SELECT 1 FROM localizacoes WHERE codigo_qr = novo_codigo
        ) THEN
            RETURN novo_codigo;
        END IF;
        
        contador := contador + 1;
    END LOOP;
END;
$$ LANGUAGE plpgsql;

-- =======================
-- ÍNDICES PARA PERFORMANCE
-- =======================

CREATE INDEX idx_patrimonios_codigo ON patrimonios(codigo);
CREATE INDEX idx_patrimonios_categoria ON patrimonios(categoria);
CREATE INDEX idx_patrimonios_status ON patrimonios(status);
CREATE INDEX idx_patrimonios_qr_code ON patrimonios(qr_code);
CREATE INDEX idx_patrimonios_localizacao ON patrimonios(localizacao_id);
CREATE INDEX idx_patrimonios_responsavel ON patrimonios(responsavel);

CREATE INDEX idx_usuarios_usuario ON usuarios(usuario);
CREATE INDEX idx_usuarios_email ON usuarios(email);
CREATE INDEX idx_usuarios_status ON usuarios(status);

CREATE INDEX idx_manutencoes_patrimonio ON manutencoes(patrimonio_id);
CREATE INDEX idx_manutencoes_status ON manutencoes(status);
CREATE INDEX idx_manutencoes_data ON manutencoes(data_solicitacao);

CREATE INDEX idx_verificacoes_patrimonio ON verificacoes_mobile(patrimonio_id);
CREATE INDEX idx_verificacoes_usuario ON verificacoes_mobile(usuario_id);
CREATE INDEX idx_verificacoes_data ON verificacoes_mobile(created_at);

CREATE INDEX idx_sync_usuario ON sync_mobile(usuario_id);
CREATE INDEX idx_sync_sincronizado ON sync_mobile(sincronizado);

CREATE INDEX idx_notificacoes_usuario ON notificacoes(usuario_id);
CREATE INDEX idx_notificacoes_lida ON notificacoes(lida);

CREATE INDEX idx_user_logs_usuario ON user_logs(usuario_id);
CREATE INDEX idx_user_logs_data ON user_logs(created_at);
CREATE INDEX idx_user_logs_dispositivo ON user_logs(dispositivo);

-- =======================
-- TRIGGERS
-- =======================

-- Função para atualizar updated_at automaticamente
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Aplicar trigger em todas as tabelas necessárias
CREATE TRIGGER update_usuarios_updated_at BEFORE UPDATE ON usuarios FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_localizacoes_updated_at BEFORE UPDATE ON localizacoes FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_patrimonios_updated_at BEFORE UPDATE ON patrimonios FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_manutencoes_updated_at BEFORE UPDATE ON manutencoes FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_seguros_updated_at BEFORE UPDATE ON seguros FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Trigger para criar entrada de sincronização quando patrimônio é alterado
CREATE OR REPLACE FUNCTION trigger_sync_mobile()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        INSERT INTO sync_mobile (usuario_id, tabela, registro_id, acao, dados)
        VALUES (1, TG_TABLE_NAME, NEW.id, 'CREATE', row_to_json(NEW));
        RETURN NEW;
    ELSIF TG_OP = 'UPDATE' THEN
        INSERT INTO sync_mobile (usuario_id, tabela, registro_id, acao, dados)
        VALUES (1, TG_TABLE_NAME, NEW.id, 'UPDATE', row_to_json(NEW));
        RETURN NEW;
    ELSIF TG_OP = 'DELETE' THEN
        INSERT INTO sync_mobile (usuario_id, tabela, registro_id, acao, dados)
        VALUES (1, TG_TABLE_NAME, OLD.id, 'DELETE', row_to_json(OLD));
        RETURN OLD;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Aplicar triggers de sync
CREATE TRIGGER trigger_patrimonios_sync AFTER INSERT OR UPDATE OR DELETE ON patrimonios FOR EACH ROW EXECUTE FUNCTION trigger_sync_mobile();
CREATE TRIGGER trigger_localizacoes_sync AFTER INSERT OR UPDATE OR DELETE ON localizacoes FOR EACH ROW EXECUTE FUNCTION trigger_sync_mobile();
CREATE TRIGGER trigger_manutencoes_sync AFTER INSERT OR UPDATE OR DELETE ON manutencoes FOR EACH ROW EXECUTE FUNCTION trigger_sync_mobile();

-- =======================
-- PERMISSÕES E SEGURANÇA
-- =======================

-- Definir última atualização nos usuários para testes
UPDATE usuarios SET ultimo_acesso = CURRENT_TIMESTAMP - INTERVAL '1 day' WHERE id = 2;
UPDATE usuarios SET ultimo_acesso = CURRENT_TIMESTAMP - INTERVAL '2 hours' WHERE id = 3;
UPDATE usuarios SET ultimo_acesso = CURRENT_TIMESTAMP - INTERVAL '3 days' WHERE id = 4;
UPDATE usuarios SET ultimo_acesso = CURRENT_TIMESTAMP - INTERVAL '1 hour' WHERE id = 5;

-- =======================
-- RELATÓRIOS FINAIS
-- =======================

-- Mensagem de conclusão
SELECT 'Banco de dados PatrimônioTech criado com sucesso!' as status;
SELECT 'Sistema integrado Web + Mobile configurado!' as mobile_status;

-- Estatísticas
SELECT 'Total de usuários: ' || COUNT(*) as usuarios FROM usuarios;
SELECT 'Total de patrimônios: ' || COUNT(*) as patrimonios FROM patrimonios;
SELECT 'Total de localizações: ' || COUNT(*) as localizacoes FROM localizacoes;
SELECT 'Total de manutenções: ' || COUNT(*) as manutencoes FROM manutencoes;
SELECT 'Total de seguros: ' || COUNT(*) as seguros FROM seguros;
SELECT 'Total de QR Codes: ' || COUNT(*) as qr_codes FROM patrimonios WHERE qr_code IS NOT NULL;

-- Exibir estatísticas do dashboard
SELECT * FROM view_dashboard_stats;

-- Mostrar patrimônios com QR codes
SELECT 'Patrimônios com QR Codes configurados:' as qr_info;
SELECT codigo, nome, qr_code FROM patrimonios WHERE qr_code IS NOT NULL LIMIT 5;
