
# Backend - Sistema de Gerenciamento de Patrimônio

Backend completo para o sistema de gerenciamento de patrimônio desenvolvido em Node.js, TypeScript, Express e PostgreSQL.

## 🛠️ Tecnologias Utilizadas

- **Node.js** - Runtime JavaScript
- **TypeScript** - Linguagem tipada
- **Express.js** - Framework web
- **PostgreSQL** - Banco de dados relacional
- **JWT** - Autenticação
- **bcryptjs** - Hash de senhas
- **QRCode** - Geração de códigos QR
- **Helmet** - Segurança HTTP
- **Morgan** - Logging de requisições
- **Rate Limiting** - Limitação de taxa

## 📋 Pré-requisitos

- Node.js (versão 18 ou superior)
- PostgreSQL (versão 12 ou superior)
- npm ou yarn

## 🚀 Instalação e Configuração

### 1. Instalar dependências
```bash
cd backend
npm install
```

### 2. Configurar banco de dados PostgreSQL

#### Opção A: Docker (Recomendado)
```bash
# Criar container PostgreSQL
docker run --name patrimonio-postgres \
  -e POSTGRES_DB=patrimonio_db \
  -e POSTGRES_USER=admin \
  -e POSTGRES_PASSWORD=admin123 \
  -p 5432:5432 \
  -d postgres:14

# Verificar se está rodando
docker ps
```

#### Opção B: Instalação local
1. Instale o PostgreSQL
2. Crie um banco de dados chamado `patrimonio_db`
3. Anote as credenciais de acesso

### 3. Configurar variáveis de ambiente
```bash
# Copiar arquivo de exemplo
cp .env.example .env

# Editar .env com suas configurações
# DATABASE_URL=postgresql://admin:admin123@localhost:5432/patrimonio_db
# JWT_SECRET=seu-jwt-secret-super-seguro-aqui
# PORT=3001
```

### 4. Executar scripts do banco de dados
```bash
# Conectar ao PostgreSQL e executar o arquivo database.sql
psql -h localhost -U admin -d patrimonio_db -f database.sql

# Ou usar ferramenta gráfica como pgAdmin, DBeaver, etc.
```

### 5. Executar o servidor
```bash
# Desenvolvimento (com hot reload)
npm run dev

# Produção
npm run build
npm start
```

## 📊 Estrutura do Banco de Dados

### Tabelas Principais:
- **usuarios** - Gerenciamento de usuários e permissões
- **patrimonios** - Cadastro de itens do patrimônio
- **localizacoes** - Setores, salas e localidades
- **manutencoes** - Ordens de serviço e manutenções
- **seguros** - Apólices de seguro
- **user_logs** - Log de atividades dos usuários
- **configuracoes** - Configurações do sistema

### Views:
- **view_patrimonios_completos** - Patrimônios com dados de localização
- **view_dashboard_stats** - Estatísticas para o dashboard

## 🔐 Autenticação

O sistema utiliza JWT (JSON Web Tokens) para autenticação:

1. **Login**: POST `/api/auth/login`
2. **Verificar token**: GET `/api/auth/verify`
3. **Logout**: POST `/api/auth/logout`

### Credenciais padrão:
- **Email**: admin@patrimonio.com
- **Senha**: admin123

## 🛡️ Segurança

- **Helmet**: Headers de segurança HTTP
- **Rate Limiting**: Máximo 100 requests por IP a cada 15 minutos
- **CORS**: Configurado para permitir apenas origens autorizadas
- **Validação**: Validação de entrada usando Joi
- **Hash de senhas**: bcryptjs com salt rounds 10
- **JWT**: Tokens com expiração configurável

## 📚 Endpoints da API

### Autenticação
```
POST /api/auth/login        # Login
GET  /api/auth/verify       # Verificar token
POST /api/auth/logout       # Logout
```

### Usuários
```
GET    /api/usuarios          # Listar usuários
GET    /api/usuarios/:id      # Buscar usuário
POST   /api/usuarios          # Criar usuário
PUT    /api/usuarios/:id      # Atualizar usuário
DELETE /api/usuarios/:id      # Excluir usuário
GET    /api/usuarios/:id/logs # Logs do usuário
PUT    /api/usuarios/:id/senha # Alterar senha
```

### Patrimônios
```
GET    /api/patrimonios             # Listar patrimônios
GET    /api/patrimonios/:id         # Buscar patrimônio
POST   /api/patrimonios             # Criar patrimônio
PUT    /api/patrimonios/:id         # Atualizar patrimônio
DELETE /api/patrimonios/:id         # Excluir patrimônio
GET    /api/patrimonios/stats/dashboard # Estatísticas
```

## 📱 Sistema de Permissões

Cada usuário possui um array de permissões que controla o acesso aos módulos:
- `patrimonio` - Gerenciar patrimônio
- `usuarios` - Gerenciar usuários
- `relatorios` - Visualizar relatórios
- `configuracoes` - Configurações do sistema
- `qrcodes` - Gerar códigos QR
- `localizacao` - Gerenciar localizações
- `manutencao` - Gerenciar manutenções
- `seguros` - Gerenciar seguros

## 📋 Logs de Atividade

O sistema registra automaticamente:
- Criação, edição e exclusão de registros
- Usuário responsável pela ação
- Timestamp da ação
- IP e User-Agent
- Detalhes da operação

## 🔧 Desenvolvimento

### Scripts disponíveis:
```bash
npm run dev      # Servidor com hot reload
npm run build    # Build para produção
npm run start    # Executar produção
npm run setup    # Configurar banco de dados
```

### Estrutura de pastas:
```
backend/
├── src/
│   ├── config/          # Configurações
│   ├── middleware/      # Middlewares
│   ├── routes/          # Rotas da API
│   └── server.ts        # Servidor principal
├── database.sql         # Schema do banco
├── .env.example         # Exemplo de variáveis
└── README.md           # Esta documentação
```

## 🚀 Deploy em Produção

### Variáveis de ambiente para produção:
```bash
NODE_ENV=production
DATABASE_URL=sua-url-de-producao
JWT_SECRET=jwt-secret-super-seguro
ALLOWED_ORIGINS=https://seudominio.com
```

### Recomendações:
1. Use um serviço de banco gerenciado (AWS RDS, Google Cloud SQL)
2. Configure SSL/TLS
3. Use um proxy reverso (Nginx)
4. Configure logs estruturados
5. Monitore performance e erros

## 🆘 Suporte

Para dúvidas ou problemas:
1. Verifique os logs do servidor
2. Confirme se o banco está acessível
3. Verifique as variáveis de ambiente
4. Teste os endpoints via `/health`

## 📄 Licença

Este projeto é privado e proprietário.
