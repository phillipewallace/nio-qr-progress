
import { Pool } from 'pg';
import dotenv from 'dotenv';

dotenv.config();

console.log('🔧 [DB] Configurando PostgreSQL para Web + Mobile...');
console.log('🏠 [DB] HOST:', process.env.DB_HOST);
console.log('📡 [DB] PORT:', process.env.DB_PORT);
console.log('🗄️ [DB] DATABASE:', process.env.DB_NAME);
console.log('👤 [DB] USER:', process.env.DB_USER);

const pool = new Pool({
  user: process.env.DB_USER || 'lipe',
  host: process.env.DB_HOST || 'localhost',
  database: process.env.DB_NAME || 'patrimonio_tech', // Nome atualizado
  password: process.env.DB_PASSWORD || '20087419',
  port: parseInt(process.env.DB_PORT || '5432'),
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
  max: 30, // Aumentado para suportar mobile
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000, // Aumentado para mobile
  statement_timeout: 30000, // Timeout para queries
  query_timeout: 30000
});

pool.on('connect', (client) => {
  console.log('✅ [DB] Nova conexão PostgreSQL estabelecida');
  console.log('📱 [DB] Suporte mobile ativo');
});

pool.on('error', (err, client) => {
  console.error('❌ [DB] Erro inesperado na conexão:', err);
  console.error('🔄 [DB] Tentando reconectar...');
});

pool.on('acquire', (client) => {
  console.log('🔄 [DB] Cliente adquirido do pool');
});

pool.on('remove', (client) => {
  console.log('🗑️ [DB] Cliente removido do pool');
});

// Teste inicial com verificações mobile
(async () => {
  try {
    console.log('🧪 [DB] Executando testes de conexão...');
    
    // Teste básico
    const basicResult = await pool.query('SELECT NOW() as now, version() as version');
    console.log('✅ [DB] Teste básico bem-sucedido');
    console.log('🕐 [DB] Timestamp:', basicResult.rows[0].now);
    console.log('📋 [DB] Versão PostgreSQL:', basicResult.rows[0].version.split(' ')[0]);
    
    // Teste de tabelas mobile
    const tablesResult = await pool.query(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' 
      AND table_name IN ('usuarios', 'patrimonios', 'verificacoes_mobile', 'sync_mobile', 'notificacoes')
      ORDER BY table_name
    `);
    
    console.log('📊 [DB] Tabelas encontradas:', tablesResult.rows.map(r => r.table_name));
    
    // Verificar se as extensões estão instaladas
    const extensionsResult = await pool.query(`
      SELECT extname FROM pg_extension 
      WHERE extname IN ('uuid-ossp', 'pgcrypto')
    `);
    
    console.log('🔧 [DB] Extensões:', extensionsResult.rows.map(r => r.extname));
    
    // Teste de views mobile
    const viewsResult = await pool.query(`
      SELECT viewname 
      FROM pg_views 
      WHERE schemaname = 'public' 
      AND viewname LIKE '%mobile%' OR viewname LIKE '%dashboard%'
    `);
    
    console.log('👁️ [DB] Views disponíveis:', viewsResult.rows.map(r => r.viewname));
    
    // Estatísticas rápidas
    const statsResult = await pool.query(`
      SELECT 
        (SELECT COUNT(*) FROM usuarios) as usuarios,
        (SELECT COUNT(*) FROM patrimonios) as patrimonios,
        (SELECT COUNT(*) FROM verificacoes_mobile) as verificacoes,
        (SELECT COUNT(*) FROM localizacoes) as localizacoes
    `);
    
    const stats = statsResult.rows[0];
    console.log('📈 [DB] Estatísticas:');
    console.log(`  👥 Usuários: ${stats.usuarios}`);
    console.log(`  📦 Patrimônios: ${stats.patrimonios}`);
    console.log(`  ✅ Verificações: ${stats.verificacoes}`);
    console.log(`  📍 Localizações: ${stats.localizacoes}`);
    
    console.log('🎯 [DB] Sistema integrado Web + Mobile pronto!');
    
  } catch (err) {
    console.error('❌ [DB] Erro nos testes de conexão:', err);
    console.error('⚠️ [DB] Verifique se o banco de dados foi criado corretamente');
    console.error('💡 [DB] Execute o script database_complete.sql primeiro');
  }
})();

// Função helper para queries mobile
export const mobileQuery = async (query: string, params: any[] = []) => {
  const start = Date.now();
  try {
    const result = await pool.query(query, params);
    const duration = Date.now() - start;
    
    if (duration > 1000) {
      console.log(`⚠️ [DB] Query lenta detectada: ${duration}ms`);
    }
    
    return result;
  } catch (error) {
    console.error('❌ [DB] Erro na query mobile:', error);
    throw error;
  }
};

// Função para cleanup de dados antigos (mobile)
export const cleanupMobileData = async () => {
  try {
    console.log('🧹 [DB] Limpeza de dados mobile iniciada...');
    
    // Limpar logs antigos (mais de 30 dias)
    await pool.query(`
      DELETE FROM user_logs 
      WHERE created_at < NOW() - INTERVAL '30 days' 
      AND dispositivo = 'Mobile'
    `);
    
    // Limpar sincronizações antigas (mais de 7 dias)
    await pool.query(`
      DELETE FROM sync_mobile 
      WHERE created_at < NOW() - INTERVAL '7 days' 
      AND sincronizado = TRUE
    `);
    
    // Limpar notificações lidas antigas (mais de 15 dias)
    await pool.query(`
      DELETE FROM notificacoes 
      WHERE created_at < NOW() - INTERVAL '15 days' 
      AND lida = TRUE
    `);
    
    console.log('✅ [DB] Limpeza de dados mobile concluída');
    
  } catch (error) {
    console.error('❌ [DB] Erro na limpeza mobile:', error);
  }
};

// Executar limpeza a cada 24 horas
setInterval(cleanupMobileData, 24 * 60 * 60 * 1000);

export default pool;
export { mobileQuery };
