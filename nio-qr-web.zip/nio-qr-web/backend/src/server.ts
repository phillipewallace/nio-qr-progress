
import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import pool from './config/database';

// Importar rotas
import authRoutes from './routes/auth';
import patrimonioRoutes from './routes/patrimonios'; // Corrigido: patrimonios em vez de patrimonio
import localizacaoRoutes from './routes/localizacoes';
import manutencaoRoutes from './routes/manutencoes';
import seguroRoutes from './routes/seguros';
import usuarioRoutes from './routes/usuarios';
import dashboardRoutes from './routes/dashboard';
import relatorioRoutes from './routes/relatorios';
import qrcodeRoutes from './routes/qrcodes';
import mobileRoutes from './routes/mobile';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

console.log('🚀 Iniciando servidor PatrimônioTech...');

// Configuração CORS otimizada para desenvolvimento e mobile
const allowedOrigins = [
  'http://localhost:5173',     // Web (Vite)
  'http://localhost:3000',     // Alternativo web
  'http://localhost:8080',     // Web build
  'http://localhost:8081',     // Mobile (Capacitor)
  'http://127.0.0.1:5173',
  'http://127.0.0.1:8080',
  'http://127.0.0.1:8081',
  'capacitor://localhost',     // iOS Capacitor
  'ionic://localhost',         // Ionic
  'http://192.168.1.100:8081', // IP local mobile
  // Adicionar mais IPs conforme necessário
];

app.use(cors({
  origin: function (origin, callback) {
    console.log('🔍 CORS Origin:', origin);
    
    // Permitir requests sem origin (mobile apps, Postman, etc.)
    if (!origin) return callback(null, true);
    
    // Verificar se origin está na lista de permitidos
    if (allowedOrigins.indexOf(origin) !== -1) {
      callback(null, true);
    } else {
      console.log('❌ CORS blocked origin:', origin);
      callback(new Error('Não permitido pelo CORS'), false);
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'Accept', 'Origin', 'X-Requested-With'],
  exposedHeaders: ['Authorization']
}));

// Middleware para parsing JSON
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Middleware de logging
app.use((req, res, next) => {
  const timestamp = new Date().toISOString();
  console.log(`📡 [${timestamp}] ${req.method} ${req.path} - Origin: ${req.get('Origin') || 'No origin'}`);
  next();
});

// Health check
app.get('/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || 'development'
  });
});

// Rotas da API
app.use('/api/auth', authRoutes);
app.use('/api/patrimonio', patrimonioRoutes); // Corrigido para usar patrimonioRoutes
app.use('/api/localizacoes', localizacaoRoutes);
app.use('/api/manutencoes', manutencaoRoutes);
app.use('/api/seguros', seguroRoutes);
app.use('/api/usuarios', usuarioRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/relatorios', relatorioRoutes);
app.use('/api/qrcodes', qrcodeRoutes);
app.use('/api/mobile', mobileRoutes);

// Middleware de tratamento de erros
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  console.error('❌ Erro no servidor:', err);
  res.status(500).json({ error: 'Erro interno do servidor' });
});

// Iniciar servidor
app.listen(PORT, () => {
  console.log(`✅ Servidor rodando na porta ${PORT}`);
  console.log(`🌐 API disponível em: http://localhost:${PORT}/api`);
  console.log(`📱 Mobile CORS habilitado para porta 8081`);
});

// Teste de conexão com banco
pool.query('SELECT NOW()')
  .then(() => console.log('✅ Conexão com PostgreSQL estabelecida'))
  .catch(err => console.error('❌ Erro na conexão com PostgreSQL:', err));
