
import express, { Request, Response } from 'express';
import pool from '../config/database';
import { authenticateToken, requirePermission } from '../middleware/auth';

const router = express.Router();

// Estatísticas do dashboard
router.get('/stats', 
  authenticateToken, 
  requirePermission('patrimonio'), 
  async (req: Request, res: Response) => {
    console.log('📊 [Dashboard] Buscando estatísticas...');
    
    try {
      // Buscar estatísticas básicas dos patrimônios
      const patrimonioStats = await pool.query(`
        SELECT 
          COUNT(*) as total,
          COUNT(CASE WHEN status = 'Ativo' THEN 1 END) as ativos,
          COUNT(CASE WHEN status = 'Inativo' THEN 1 END) as inativos,
          COUNT(CASE WHEN status = 'Manutenção' THEN 1 END) as manutencao,
          COALESCE(SUM(valor_aquisicao), 0) as valor_total_aquisicao,
          COALESCE(SUM(valor_atual), 0) as valor_total_atual
        FROM patrimonios
      `);

      // Buscar estatísticas por categoria
      const categoriaStats = await pool.query(`
        SELECT 
          categoria,
          COUNT(*) as quantidade,
          COALESCE(SUM(valor_atual), 0) as valor_total
        FROM patrimonios 
        GROUP BY categoria
        ORDER BY quantidade DESC
      `);

      // Buscar estatísticas por status
      const statusStats = await pool.query(`
        SELECT 
          status,
          COUNT(*) as quantidade
        FROM patrimonios 
        GROUP BY status
      `);

      // Buscar próximas manutenções
      const proximasManutencoes = await pool.query(`
        SELECT COUNT(*) as quantidade
        FROM manutencoes m
        WHERE m.status IN ('Pendente', 'Em Andamento')
        AND (m.data_agendamento IS NULL OR m.data_agendamento <= CURRENT_DATE + INTERVAL '7 days')
      `);

      // Buscar seguros próximos do vencimento
      const segurosVencendo = await pool.query(`
        SELECT COUNT(*) as quantidade
        FROM seguros s
        WHERE s.status = 'Ativo'
        AND s.data_vencimento <= CURRENT_DATE + INTERVAL '30 days'
      `);

      const stats = patrimonioStats.rows[0];
      
      const resultado = {
        patrimonio: {
          total: parseInt(stats.total) || 0,
          ativos: parseInt(stats.ativos) || 0,
          inativos: parseInt(stats.inativos) || 0,
          manutencao: parseInt(stats.manutencao) || 0,
          valor_total_aquisicao: parseFloat(stats.valor_total_aquisicao) || 0,
          valor_total_atual: parseFloat(stats.valor_total_atual) || 0
        },
        categorias: categoriaStats.rows.reduce((acc, row) => {
          acc[row.categoria] = {
            quantidade: parseInt(row.quantidade),
            valor_total: parseFloat(row.valor_total) || 0
          };
          return acc;
        }, {}),
        status: statusStats.rows.reduce((acc, row) => {
          acc[row.status] = parseInt(row.quantidade);
          return acc;
        }, {}),
        alertas: {
          manutencoes_pendentes: parseInt(proximasManutencoes.rows[0]?.quantidade) || 0,
          seguros_vencendo: parseInt(segurosVencendo.rows[0]?.quantidade) || 0
        }
      };

      console.log('✅ [Dashboard] Estatísticas obtidas:', resultado);
      res.json(resultado);
    } catch (error) {
      console.error('❌ [Dashboard] Erro ao buscar estatísticas:', error);
      res.status(500).json({ 
        error: 'Erro interno do servidor', 
        details: error.message 
      });
    }
  }
);

// Atividades recentes
router.get('/activity', 
  authenticateToken, 
  requirePermission('patrimonio'), 
  async (req: Request, res: Response) => {
    console.log('📋 [Dashboard] Buscando atividades recentes...');
    
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      
      const result = await pool.query(`
        SELECT 
          id,
          usuario_id,
          acao,
          modulo,
          detalhes,
          created_at,
          ip_address
        FROM user_logs 
        ORDER BY created_at DESC 
        LIMIT $1
      `, [limit]);

      console.log('✅ [Dashboard] Atividades obtidas:', result.rows.length);
      res.json(result.rows);
    } catch (error) {
      console.error('❌ [Dashboard] Erro ao buscar atividades:', error);
      res.status(500).json({ 
        error: 'Erro interno do servidor', 
        details: error.message 
      });
    }
  }
);

export default router;
