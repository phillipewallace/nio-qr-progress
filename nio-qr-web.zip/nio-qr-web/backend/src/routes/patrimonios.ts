import express, { Request, Response } from 'express';
import pool from '../config/database';
import { authenticateToken, requirePermission } from '../middleware/auth';
import { logUserActivity } from '../middleware/logger';

const router = express.Router();

// Listar patrimônios
router.get('/', 
  authenticateToken, 
  requirePermission('patrimonio'),
  async (req: Request, res: Response) => {
    console.log('📦 [Patrimônios] Listando patrimônios...');
    
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 50;
      const offset = (page - 1) * limit;
      const categoria = req.query.categoria as string;
      const status = req.query.status as string;
      const search = req.query.search as string;

      let whereConditions = [];
      let queryParams = [];
      let paramIndex = 1;

      if (categoria) {
        whereConditions.push(`p.categoria = $${paramIndex}`);
        queryParams.push(categoria);
        paramIndex++;
      }

      if (status) {
        whereConditions.push(`p.status = $${paramIndex}`);
        queryParams.push(status);
        paramIndex++;
      }

      if (search) {
        whereConditions.push(`(p.nome ILIKE $${paramIndex} OR p.codigo ILIKE $${paramIndex} OR p.descricao ILIKE $${paramIndex})`);
        queryParams.push(`%${search}%`);
        paramIndex++;
      }

      const whereClause = whereConditions.length > 0 ? `WHERE ${whereConditions.join(' AND ')}` : '';

      // Query principal para listar patrimônios
      const patrimoniosQuery = `
        SELECT 
          p.id, p.codigo, p.nome, p.descricao, p.categoria, p.subcategoria,
          p.responsavel, p.valor_aquisicao, p.valor_atual, p.data_aquisicao,
          p.garantia, p.fornecedor, p.numero_serie, p.status, p.observacoes,
          p.foto, p.qr_code, p.created_at, p.updated_at,
          l.setor as localizacao_setor, l.sala as localizacao_sala,
          l.bloco as localizacao_bloco, l.andar as localizacao_andar
        FROM patrimonios p
        LEFT JOIN localizacoes l ON p.localizacao_id = l.id
        ${whereClause}
        ORDER BY p.created_at DESC
        LIMIT $${paramIndex} OFFSET $${paramIndex + 1}
      `;

      queryParams.push(limit, offset);

      const patrimoniosResult = await pool.query(patrimoniosQuery, queryParams);

      // Query para contar total de registros
      const countQuery = `
        SELECT COUNT(*) as total
        FROM patrimonios p
        LEFT JOIN localizacoes l ON p.localizacao_id = l.id
        ${whereClause}
      `;

      const countResult = await pool.query(countQuery, queryParams.slice(0, -2));

      // Query para calcular valor total (CORRIGIDO para somar números, não concatenar strings)
      const totalValueQuery = `
        SELECT COALESCE(SUM(CAST(valor_atual AS DECIMAL)), 0) as valor_total
        FROM patrimonios p
        ${whereClause}
      `;

      const totalValueResult = await pool.query(totalValueQuery, queryParams.slice(0, -2));

      console.log('✅ [Patrimônios] Listagem concluída:', {
        total: countResult.rows[0].total,
        valorTotal: totalValueResult.rows[0].valor_total,
        registros: patrimoniosResult.rows.length
      });

      res.json({
        data: patrimoniosResult.rows,
        pagination: {
          page,
          limit,
          total: parseInt(countResult.rows[0].total),
          pages: Math.ceil(countResult.rows[0].total / limit)
        },
        valorTotal: parseFloat(totalValueResult.rows[0].valor_total) || 0
      });

    } catch (error) {
      console.error('❌ [Patrimônios] Erro ao listar:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
);

// Buscar patrimônio por ID
router.get('/:id', 
  authenticateToken, 
  requirePermission('patrimonio'),
  async (req: Request, res: Response) => {
    console.log('🔍 [Patrimônios] Buscando patrimônio por ID:', req.params.id);
    
    try {
      const { id } = req.params;

      const query = `
        SELECT 
          p.id, p.codigo, p.nome, p.descricao, p.categoria, p.subcategoria,
          p.responsavel, p.valor_aquisicao, p.valor_atual, p.data_aquisicao,
          p.garantia, p.fornecedor, p.numero_serie, p.status, p.observacoes,
          p.foto, p.qr_code, p.created_at, p.updated_at,
          l.setor as localizacao_setor, l.sala as localizacao_sala,
          l.bloco as localizacao_bloco, l.andar as localizacao_andar
        FROM patrimonios p
        LEFT JOIN localizacoes l ON p.localizacao_id = l.id
        WHERE p.id = $1
      `;

      const result = await pool.query(query, [id]);

      if (result.rows.length === 0) {
        console.log('❌ [Patrimônios] Patrimônio não encontrado');
        return res.status(404).json({ error: 'Patrimônio não encontrado' });
      }

      console.log('✅ [Patrimônios] Patrimônio encontrado:', result.rows[0].nome);
      res.json(result.rows[0]);

    } catch (error) {
      console.error('❌ [Patrimônios] Erro ao buscar patrimônio:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
);

// Criar novo patrimônio
router.post('/', 
  authenticateToken, 
  requirePermission('patrimonio', 'editor'),
  logUserActivity('Criou', 'Patrimônios'),
  async (req: Request, res: Response) => {
    console.log('➕ [Patrimônios] Criando novo patrimônio...');
    
    try {
      const {
        codigo, nome, descricao, categoria, subcategoria, localizacao_id,
        responsavel, valor_aquisicao, valor_atual, data_aquisicao, garantia,
        fornecedor, numero_serie, status, observacoes, qr_code, foto
      } = req.body;

      if (!codigo || !nome || !categoria || !valor_aquisicao || !data_aquisicao) {
        console.log('❌ [Patrimônios] Campos obrigatórios em falta');
        return res.status(400).json({ error: 'Código, nome, categoria, valor de aquisição e data de aquisição são obrigatórios' });
      }

      const query = `
        INSERT INTO patrimonios (
          codigo, nome, descricao, categoria, subcategoria, localizacao_id,
          responsavel, valor_aquisicao, valor_atual, data_aquisicao, garantia,
          fornecedor, numero_serie, status, observacoes, qr_code, foto
        ) VALUES (
          $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17
        )
        RETURNING *
      `;

      const values = [
        codigo, nome, descricao, categoria, subcategoria, localizacao_id,
        responsavel, valor_aquisicao, valor_atual, data_aquisicao, garantia,
        fornecedor, numero_serie, status, observacoes, qr_code, foto
      ];

      const result = await pool.query(query, values);

      console.log('✅ [Patrimônios] Patrimônio criado:', result.rows[0].nome);
      res.status(201).json(result.rows[0]);

    } catch (error) {
      console.error('❌ [Patrimônios] Erro ao criar patrimônio:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
);

// Atualizar patrimônio existente
router.put('/:id', 
  authenticateToken, 
  requirePermission('patrimonio', 'editor'),
  logUserActivity('Editou', 'Patrimônios'),
  async (req: Request, res: Response) => {
    console.log('✏️ [Patrimônios] Atualizando patrimônio:', req.params.id);
    
    try {
      const { id } = req.params;
      const {
        codigo, nome, descricao, categoria, subcategoria, localizacao_id,
        responsavel, valor_aquisicao, valor_atual, data_aquisicao, garantia,
        fornecedor, numero_serie, status, observacoes, qr_code, foto
      } = req.body;

      const query = `
        UPDATE patrimonios SET
          codigo = $1, nome = $2, descricao = $3, categoria = $4,
          subcategoria = $5, localizacao_id = $6, responsavel = $7,
          valor_aquisicao = $8, valor_atual = $9, data_aquisicao = $10,
          garantia = $11, fornecedor = $12, numero_serie = $13,
          status = $14, observacoes = $15, qr_code = $16, foto = $17,
          updated_at = CURRENT_TIMESTAMP
        WHERE id = $18
        RETURNING *
      `;

      const values = [
        codigo, nome, descricao, categoria, subcategoria, localizacao_id,
        responsavel, valor_aquisicao, valor_atual, data_aquisicao, garantia,
        fornecedor, numero_serie, status, observacoes, qr_code, foto, id
      ];

      const result = await pool.query(query, values);

      if (result.rows.length === 0) {
        console.log('❌ [Patrimônios] Patrimônio não encontrado para atualização');
        return res.status(404).json({ error: 'Patrimônio não encontrado' });
      }

      console.log('✅ [Patrimônios] Patrimônio atualizado:', result.rows[0].nome);
      res.json(result.rows[0]);

    } catch (error) {
      console.error('❌ [Patrimônios] Erro ao atualizar patrimônio:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
);

// Excluir patrimônio
router.delete('/:id', 
  authenticateToken, 
  requirePermission('patrimonio', 'admin'),
  logUserActivity('Excluiu', 'Patrimônios'),
  async (req: Request, res: Response) => {
    console.log('🗑️ [Patrimônios] Excluindo patrimônio:', req.params.id);
    
    try {
      const { id } = req.params;

      const result = await pool.query('DELETE FROM patrimonios WHERE id = $1 RETURNING id', [id]);

      if (result.rows.length === 0) {
        console.log('❌ [Patrimônios] Patrimônio não encontrado para exclusão');
        return res.status(404).json({ error: 'Patrimônio não encontrado' });
      }

      console.log('✅ [Patrimônios] Patrimônio excluído com sucesso');
      res.json({ message: 'Patrimônio excluído com sucesso' });

    } catch (error) {
      console.error('❌ [Patrimônios] Erro ao excluir patrimônio:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
);

export default router;
