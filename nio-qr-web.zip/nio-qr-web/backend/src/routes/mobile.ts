
import express, { Request, Response } from 'express';
import pool from '../config/database';
import { authenticateToken } from '../middleware/auth';

const router = express.Router();

interface AuthRequest extends Request {
  user?: any;
}

// =======================
// DASHBOARD MOBILE
// =======================
router.get('/dashboard', 
  authenticateToken,
  async (req: AuthRequest, res: Response) => {
    console.log('📱 [MOBILE] Dashboard solicitado para usuário:', req.user.id);
    
    try {
      // Estatísticas gerais
      const statsQuery = `
        SELECT 
          COUNT(*) as total_patrimonios,
          COALESCE(SUM(valor_atual), 0) as valor_total,
          COUNT(CASE WHEN status = 'Ativo' THEN 1 END) as ativos,
          COUNT(CASE WHEN status = 'Manutenção' THEN 1 END) as em_manutencao
        FROM patrimonios
      `;
      
      const statsResult = await pool.query(statsQuery);
      const stats = statsResult.rows[0];

      // Verificações recentes do usuário
      const verificacoesQuery = `
        SELECT 
          v.id,
          v.tipo_verificacao,
          v.resultado,
          v.created_at,
          p.nome as patrimonio_nome,
          p.codigo as patrimonio_codigo
        FROM verificacoes_mobile v
        JOIN patrimonios p ON v.patrimonio_id = p.id
        WHERE v.usuario_id = $1
        ORDER BY v.created_at DESC
        LIMIT 5
      `;
      
      const verificacoesResult = await pool.query(verificacoesQuery, [req.user.id]);

      // Manutenções pendentes
      const manutencoesQuery = `
        SELECT 
          m.id,
          m.tipo,
          m.status,
          m.data_prevista,
          p.nome as patrimonio_nome,
          p.codigo as patrimonio_codigo
        FROM manutencoes m
        JOIN patrimonios p ON m.patrimonio_id = p.id
        WHERE m.status IN ('Agendada', 'Em Andamento')
        ORDER BY m.data_prevista ASC
        LIMIT 3
      `;
      
      const manutencoesResult = await pool.query(manutencoesQuery);

      // Notificações não lidas
      const notificacoesQuery = `
        SELECT COUNT(*) as nao_lidas
        FROM notificacoes
        WHERE usuario_id = $1 AND lida = FALSE
      `;
      
      const notificacoesResult = await pool.query(notificacoesQuery, [req.user.id]);

      res.json({
        estatisticas: {
          total_patrimonios: parseInt(stats.total_patrimonios),
          valor_total: parseFloat(stats.valor_total),
          ativos: parseInt(stats.ativos),
          em_manutencao: parseInt(stats.em_manutencao)
        },
        verificacoes_recentes: verificacoesResult.rows,
        manutencoes_pendentes: manutencoesResult.rows,
        notificacoes_nao_lidas: parseInt(notificacoesResult.rows[0].nao_lidas)
      });
      
    } catch (error) {
      console.error('❌ [MOBILE] Erro no dashboard:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
);

// =======================
// PATRIMÔNIOS MOBILE
// =======================
router.get('/patrimonios', 
  authenticateToken,
  async (req: Request, res: Response) => {
    console.log('📱 [MOBILE] Lista de patrimônios solicitada');
    
    try {
      const { search, categoria, status, page = 1, limit = 20 } = req.query;
      
      let whereConditions = ['1=1'];
      let params: any[] = [];
      let paramCount = 0;

      if (search) {
        paramCount++;
        whereConditions.push(`(p.nome ILIKE $${paramCount} OR p.codigo ILIKE $${paramCount})`);
        params.push(`%${search}%`);
      }

      if (categoria) {
        paramCount++;
        whereConditions.push(`p.categoria = $${paramCount}`);
        params.push(categoria);
      }

      if (status) {
        paramCount++;
        whereConditions.push(`p.status = $${paramCount}`);
        params.push(status);
      }

      const whereClause = whereConditions.join(' AND ');
      const offset = (Number(page) - 1) * Number(limit);

      const query = `
        SELECT 
          p.id,
          p.codigo,
          p.nome,
          p.categoria,
          p.status,
          p.valor_atual,
          p.qr_code,
          p.data_aquisicao,
          l.setor,
          l.sala,
          l.bloco,
          l.andar
        FROM patrimonios p
        LEFT JOIN localizacoes l ON p.localizacao_id = l.id
        WHERE ${whereClause}
        ORDER BY p.created_at DESC
        LIMIT $${paramCount + 1} OFFSET $${paramCount + 2}
      `;

      params.push(Number(limit), offset);
      const result = await pool.query(query, params);

      // Contar total
      const countQuery = `
        SELECT COUNT(*) as total
        FROM patrimonios p
        WHERE ${whereClause}
      `;
      const countResult = await pool.query(countQuery, params.slice(0, -2));

      res.json({
        patrimonios: result.rows,
        pagination: {
          page: Number(page),
          limit: Number(limit),
          total: Number(countResult.rows[0].total),
          total_pages: Math.ceil(Number(countResult.rows[0].total) / Number(limit))
        }
      });
      
    } catch (error) {
      console.error('❌ [MOBILE] Erro ao listar patrimônios:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
);

// Buscar patrimônio por ID
router.get('/patrimonios/:id', 
  authenticateToken,
  async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      
      const query = `
        SELECT 
          p.*,
          l.setor,
          l.sala,
          l.bloco,
          l.andar,
          l.descricao as localizacao_descricao,
          u.nome as responsavel_nome
        FROM patrimonios p
        LEFT JOIN localizacoes l ON p.localizacao_id = l.id
        LEFT JOIN usuarios u ON p.responsavel = u.nome
        WHERE p.id = $1
      `;
      
      const result = await pool.query(query, [id]);
      
      if (result.rows.length === 0) {
        return res.status(404).json({ error: 'Patrimônio não encontrado' });
      }

      res.json(result.rows[0]);
      
    } catch (error) {
      console.error('❌ [MOBILE] Erro ao buscar patrimônio:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
);

// =======================
// QR CODE
// =======================
router.get('/qr/:codigo', 
  authenticateToken,
  async (req: Request, res: Response) => {
    console.log('📱 [MOBILE] Busca por QR Code:', req.params.codigo);
    
    try {
      const { codigo } = req.params;
      
      const query = `
        SELECT 
          p.*,
          l.setor,
          l.sala,
          l.bloco,
          l.andar
        FROM patrimonios p
        LEFT JOIN localizacoes l ON p.localizacao_id = l.id
        WHERE p.qr_code = $1 OR p.codigo = $1
      `;
      
      const result = await pool.query(query, [codigo]);

      if (result.rows.length === 0) {
        return res.status(404).json({ error: 'Patrimônio não encontrado' });
      }

      res.json(result.rows[0]);
      
    } catch (error) {
      console.error('❌ [MOBILE] Erro ao buscar QR Code:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
);

// Registrar verificação
router.post('/verificacao', 
  authenticateToken,
  async (req: AuthRequest, res: Response) => {
    console.log('📱 [MOBILE] Nova verificação registrada');
    
    try {
      const { 
        patrimonio_id, 
        tipo_verificacao, 
        resultado, 
        observacoes,
        localizacao_gps
      } = req.body;
      
      const usuario_id = req.user.id;

      const query = `
        INSERT INTO verificacoes_mobile 
        (patrimonio_id, usuario_id, tipo_verificacao, resultado, observacoes, localizacao_gps)
        VALUES ($1, $2, $3, $4, $5, $6)
        RETURNING *
      `;
      
      const result = await pool.query(query, [
        patrimonio_id, 
        usuario_id, 
        tipo_verificacao, 
        resultado, 
        observacoes,
        localizacao_gps ? JSON.stringify(localizacao_gps) : null
      ]);

      // Atualizar última verificação do patrimônio
      await pool.query(`
        UPDATE patrimonios 
        SET ultima_verificacao = CURRENT_TIMESTAMP
        WHERE id = $1
      `, [patrimonio_id]);

      res.status(201).json(result.rows[0]);
      
    } catch (error) {
      console.error('❌ [MOBILE] Erro ao registrar verificação:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
);

// =======================
// SINCRONIZAÇÃO
// =======================
router.post('/sync', 
  authenticateToken,
  async (req: AuthRequest, res: Response) => {
    console.log('📱 [MOBILE] Sincronização solicitada');
    
    try {
      const { dados_offline } = req.body;
      const usuario_id = req.user.id;
      
      if (!dados_offline || !Array.isArray(dados_offline)) {
        return res.status(400).json({ error: 'Dados de sincronização inválidos' });
      }

      const resultados = [];
      
      for (const item of dados_offline) {
        try {
          const { tipo, dados, timestamp_offline } = item;
          
          // Processar diferentes tipos de dados offline
          switch (tipo) {
            case 'verificacao':
              const verificacaoQuery = `
                INSERT INTO verificacoes_mobile 
                (patrimonio_id, usuario_id, tipo_verificacao, resultado, observacoes, created_at)
                VALUES ($1, $2, $3, $4, $5, $6)
                RETURNING id
              `;
              
              const verificacaoResult = await pool.query(verificacaoQuery, [
                dados.patrimonio_id,
                usuario_id,
                dados.tipo_verificacao,
                dados.resultado,
                dados.observacoes,
                timestamp_offline
              ]);
              
              resultados.push({
                tipo: 'verificacao',
                status: 'sincronizado',
                id: verificacaoResult.rows[0].id
              });
              break;
              
            default:
              resultados.push({
                tipo: item.tipo,
                status: 'tipo_nao_suportado'
              });
          }
          
        } catch (error) {
          console.error('❌ [MOBILE] Erro ao sincronizar item:', error);
          resultados.push({
            tipo: item.tipo,
            status: 'erro',
            erro: (error as Error).message
          });
        }
      }

      res.json({
        sincronizados: resultados.filter(r => r.status === 'sincronizado').length,
        erros: resultados.filter(r => r.status === 'erro').length,
        detalhes: resultados
      });
      
    } catch (error) {
      console.error('❌ [MOBILE] Erro na sincronização:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
);

// =======================
// NOTIFICAÇÕES
// =======================
router.get('/notificacoes', 
  authenticateToken,
  async (req: AuthRequest, res: Response) => {
    try {
      const usuario_id = req.user.id;
      
      const query = `
        SELECT * FROM notificacoes
        WHERE usuario_id = $1
        ORDER BY created_at DESC
        LIMIT 50
      `;
      
      const result = await pool.query(query, [usuario_id]);
      res.json(result.rows);
      
    } catch (error) {
      console.error('❌ [MOBILE] Erro ao buscar notificações:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
);

router.put('/notificacoes/:id/lida', 
  authenticateToken,
  async (req: AuthRequest, res: Response) => {
    try {
      const { id } = req.params;
      const usuario_id = req.user.id;

      await pool.query(`
        UPDATE notificacoes 
        SET lida = TRUE 
        WHERE id = $1 AND usuario_id = $2
      `, [id, usuario_id]);

      res.json({ message: 'Notificação marcada como lida' });
      
    } catch (error) {
      console.error('❌ [MOBILE] Erro ao marcar notificação:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
);

export default router;
