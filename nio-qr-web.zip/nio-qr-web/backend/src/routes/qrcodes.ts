
import express, { Request, Response } from 'express';
import QRCode from 'qrcode';
import pool from '../config/database';
import { authenticateToken, requirePermission } from '../middleware/auth';

const router = express.Router();

// Listar todos os patrimônios para geração de QR Codes
router.get('/', 
  authenticateToken, 
  requirePermission('qrcodes'),
  async (req: Request, res: Response) => {
    console.log('🏷️ [QRCodes] Listando patrimônios para QR Codes...');
    
    try {
      const search = req.query.search as string;
      const categoria = req.query.categoria as string;
      
      let whereConditions = ['p.status = $1'];
      let queryParams: any[] = ['Ativo'];
      let paramIndex = 2;

      if (search) {
        whereConditions.push(`(p.nome ILIKE $${paramIndex} OR p.codigo ILIKE $${paramIndex})`);
        queryParams.push(`%${search}%`);
        paramIndex++;
      }

      if (categoria) {
        whereConditions.push(`p.categoria = $${paramIndex}`);
        queryParams.push(categoria);
        paramIndex++;
      }

      const whereClause = `WHERE ${whereConditions.join(' AND ')}`;

      const query = `
        SELECT 
          p.id, p.codigo, p.nome, p.categoria, p.status,
          p.valor_atual, p.responsavel, p.qr_code,
          l.setor as localizacao_setor, l.sala as localizacao_sala,
          l.bloco as localizacao_bloco, l.andar as localizacao_andar
        FROM patrimonios p
        LEFT JOIN localizacoes l ON p.localizacao_id = l.id
        ${whereClause}
        ORDER BY p.codigo ASC
      `;

      console.log('🔍 [QRCodes] Executando query:', query);
      console.log('📋 [QRCodes] Parâmetros:', queryParams);

      const result = await pool.query(query, queryParams);

      // Gerar QR codes para itens que não possuem
      for (const item of result.rows) {
        if (!item.qr_code) {
          const qrData = {
            id: item.id,
            codigo: item.codigo,
            nome: item.nome,
            url: `${process.env.FRONTEND_URL || 'http://localhost:5173'}/patrimonio/${item.id}`
          };
          
          try {
            const qrCodeDataURL = await QRCode.toDataURL(JSON.stringify(qrData), {
              width: 256,
              margin: 2,
              color: {
                dark: '#000000',
                light: '#FFFFFF'
              }
            });
            
            // Salvar QR code no banco
            await pool.query(
              'UPDATE patrimonios SET qr_code = $1 WHERE id = $2',
              [qrCodeDataURL, item.id]
            );
            
            item.qr_code = qrCodeDataURL;
          } catch (qrError) {
            console.error(`❌ Erro ao gerar QR code para ${item.codigo}:`, qrError);
          }
        }
      }

      console.log('✅ [QRCodes] Patrimônios encontrados:', result.rows.length);

      res.json({
        data: result.rows,
        total: result.rows.length
      });

    } catch (error) {
      console.error('❌ [QRCodes] Erro ao listar patrimônios:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
);

// Gerar QR Code para patrimônio específico
router.get('/:id', 
  authenticateToken, 
  requirePermission('qrcodes'),
  async (req: Request, res: Response) => {
    console.log('🏷️ [QRCodes] Buscando patrimônio para QR Code:', req.params.id);
    
    try {
      const { id } = req.params;

      const query = `
        SELECT 
          p.id, p.codigo, p.nome, p.categoria, p.status,
          p.valor_atual, p.responsavel, p.qr_code,
          l.setor as localizacao_setor, l.sala as localizacao_sala,
          l.bloco as localizacao_bloco, l.andar as localizacao_andar
        FROM patrimonios p
        LEFT JOIN localizacoes l ON p.localizacao_id = l.id
        WHERE p.id = $1
      `;

      const result = await pool.query(query, [id]);

      if (result.rows.length === 0) {
        console.log('❌ [QRCodes] Patrimônio não encontrado');
        return res.status(404).json({ error: 'Patrimônio não encontrado' });
      }

      const item = result.rows[0];

      // Gerar QR code se não existir
      if (!item.qr_code) {
        const qrData = {
          id: item.id,
          codigo: item.codigo,
          nome: item.nome,
          url: `${process.env.FRONTEND_URL || 'http://localhost:5173'}/patrimonio/${item.id}`
        };
        
        try {
          const qrCodeDataURL = await QRCode.toDataURL(JSON.stringify(qrData), {
            width: 256,
            margin: 2,
            color: {
              dark: '#000000',
              light: '#FFFFFF'
            }
          });
          
          // Salvar QR code no banco
          await pool.query(
            'UPDATE patrimonios SET qr_code = $1 WHERE id = $2',
            [qrCodeDataURL, item.id]
          );
          
          item.qr_code = qrCodeDataURL;
        } catch (qrError) {
          console.error(`❌ Erro ao gerar QR code:`, qrError);
        }
      }

      console.log('✅ [QRCodes] Patrimônio encontrado:', result.rows[0].codigo);
      res.json(item);

    } catch (error) {
      console.error('❌ [QRCodes] Erro ao buscar patrimônio:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
);

// Endpoint para mobile - verificar QR Code escaneado
router.post('/verify', 
  authenticateToken,
  async (req: Request, res: Response) => {
    console.log('📱 [QRCodes] Verificando QR Code escaneado...');
    
    try {
      const { qrData } = req.body;
      
      let patrimonioId: string;
      
      // Tentar fazer parse do QR como JSON
      try {
        const parsed = JSON.parse(qrData);
        patrimonioId = parsed.id;
      } catch {
        // Se não for JSON, assume que é o ID direto
        patrimonioId = qrData;
      }
      
      const query = `
        SELECT 
          p.id, p.codigo, p.nome, p.categoria, p.status,
          p.valor_atual, p.responsavel, p.descricao,
          l.setor as localizacao_setor, l.sala as localizacao_sala,
          l.bloco as localizacao_bloco, l.andar as localizacao_andar
        FROM patrimonios p
        LEFT JOIN localizacoes l ON p.localizacao_id = l.id
        WHERE p.id = $1
      `;

      const result = await pool.query(query, [patrimonioId]);

      if (result.rows.length === 0) {
        console.log('❌ [QRCodes] Patrimônio não encontrado para QR');
        return res.status(404).json({ error: 'Patrimônio não encontrado' });
      }

      console.log('✅ [QRCodes] QR Code verificado:', result.rows[0].codigo);
      res.json({
        success: true,
        patrimonio: result.rows[0]
      });

    } catch (error) {
      console.error('❌ [QRCodes] Erro ao verificar QR Code:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
);

export default router;
