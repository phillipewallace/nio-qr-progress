import express, { Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import pool from '../config/database';
import { authenticateToken, requirePermission } from '../middleware/auth';
import { logUserActivity } from '../middleware/logger';

const router = express.Router();

interface AuthRequest extends Request {
  user?: any;
}

// Listar usuários
router.get('/', 
  authenticateToken, 
  requirePermission('usuarios'), 
  async (req: Request, res: Response) => {
    console.log('👥 Listando usuários...');
    
    try {
      const result = await pool.query(`
        SELECT id, nome, usuario, email, telefone, cargo, status, permissoes, 
               ultimo_acesso, created_at
        FROM usuarios 
        ORDER BY created_at DESC
      `);

      console.log('✅ Usuários listados:', result.rows.length, 'registros');
      res.json(result.rows);
    } catch (error) {
      console.error('❌ Erro ao listar usuários:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
);

// Buscar usuário por ID
router.get('/:id', 
  authenticateToken, 
  requirePermission('usuarios'), 
  async (req: Request, res: Response) => {
    console.log('👤 Buscando usuário por ID:', req.params.id);
    
    try {
      const { id } = req.params;
      
      const result = await pool.query(`
        SELECT id, nome, usuario, email, telefone, cargo, status, permissoes, 
               ultimo_acesso, created_at
        FROM usuarios 
        WHERE id = $1
      `, [id]);

      if (result.rows.length === 0) {
        console.log('❌ Usuário não encontrado');
        return res.status(404).json({ error: 'Usuário não encontrado' });
      }

      console.log('✅ Usuário encontrado:', result.rows[0].nome);
      res.json(result.rows[0]);
    } catch (error) {
      console.error('❌ Erro ao buscar usuário:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
);

// Criar usuário
router.post('/', 
  authenticateToken, 
  requirePermission('usuarios', 'editor'),
  logUserActivity('Criou', 'Usuários'),
  async (req: Request, res: Response) => {
    console.log('➕ Criando novo usuário...');
    
    try {
      const { nome, usuario, email, senha, telefone, cargo, permissoes } = req.body;

      if (!nome || !usuario || !senha) {
        console.log('❌ Campos obrigatórios em falta');
        return res.status(400).json({ error: 'Nome, usuário e senha são obrigatórios' });
      }

      // Verificar se usuário já existe
      const existingUser = await pool.query(
        'SELECT id FROM usuarios WHERE usuario = $1 OR email = $2',
        [usuario, email]
      );

      if (existingUser.rows.length > 0) {
        console.log('❌ Usuário ou email já está em uso');
        return res.status(400).json({ error: 'Usuário ou email já está em uso' });
      }

      const result = await pool.query(`
        INSERT INTO usuarios (nome, usuario, email, senha, telefone, cargo, permissoes)
        VALUES ($1, $2, $3, $4, $5, $6, $7)
        RETURNING id, nome, usuario, email, telefone, cargo, status, permissoes, created_at
      `, [nome, usuario, email, senha, telefone, cargo, JSON.stringify(permissoes || {})]);

      console.log('✅ Usuário criado:', result.rows[0].nome);
      res.status(201).json(result.rows[0]);
    } catch (error) {
      console.error('❌ Erro ao criar usuário:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
);

// Atualizar usuário
router.put('/:id', 
  authenticateToken, 
  requirePermission('usuarios', 'editor'),
  logUserActivity('Editou', 'Usuários'),
  async (req: Request, res: Response) => {
    console.log('✏️ Atualizando usuário:', req.params.id);
    
    try {
      const { id } = req.params;
      const { nome, usuario, email, telefone, cargo, permissoes, status } = req.body;

      const result = await pool.query(`
        UPDATE usuarios 
        SET nome = $1, usuario = $2, email = $3, telefone = $4, cargo = $5, 
            permissoes = $6, status = $7, updated_at = CURRENT_TIMESTAMP
        WHERE id = $8
        RETURNING id, nome, usuario, email, telefone, cargo, status, permissoes, updated_at
      `, [nome, usuario, email, telefone, cargo, JSON.stringify(permissoes || {}), status, id]);

      if (result.rows.length === 0) {
        console.log('❌ Usuário não encontrado para atualização');
        return res.status(404).json({ error: 'Usuário não encontrado' });
      }

      console.log('✅ Usuário atualizado:', result.rows[0].nome);
      res.json(result.rows[0]);
    } catch (error) {
      console.error('❌ Erro ao atualizar usuário:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
);

// Deletar usuário
router.delete('/:id', 
  authenticateToken, 
  requirePermission('usuarios', 'admin'),
  logUserActivity('Excluiu', 'Usuários'),
  async (req: AuthRequest, res: Response) => {
    console.log('🗑️ Excluindo usuário:', req.params.id);
    
    try {
      const { id } = req.params;

      // Não permitir exclusão do próprio usuário
      if (id === req.user.id.toString()) {
        console.log('❌ Tentativa de auto-exclusão bloqueada');
        return res.status(400).json({ error: 'Não é possível excluir seu próprio usuário' });
      }

      const result = await pool.query('DELETE FROM usuarios WHERE id = $1 RETURNING id', [id]);

      if (result.rows.length === 0) {
        console.log('❌ Usuário não encontrado para exclusão');
        return res.status(404).json({ error: 'Usuário não encontrado' });
      }

      console.log('✅ Usuário excluído com sucesso');
      res.json({ message: 'Usuário excluído com sucesso' });
    } catch (error) {
      console.error('❌ Erro ao excluir usuário:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
);

// Listar logs de um usuário (NOVA FUNCIONALIDADE)
router.get('/:id/logs', 
  authenticateToken, 
  requirePermission('usuarios'), 
  async (req: Request, res: Response) => {
    console.log('📋 Buscando logs do usuário:', req.params.id);
    
    try {
      const { id } = req.params;
      const limit = parseInt(req.query.limit as string) || 50;
      
      const result = await pool.query(`
        SELECT acao, modulo, detalhes, ip_address, user_agent, created_at
        FROM user_logs 
        WHERE usuario_id = $1
        ORDER BY created_at DESC
        LIMIT $2
      `, [id, limit]);

      console.log('✅ Logs do usuário obtidos:', result.rows.length, 'registros');
      res.json(result.rows);
    } catch (error) {
      console.error('❌ Erro ao buscar logs do usuário:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
);

// Alterar senha
router.put('/:id/senha', 
  authenticateToken, 
  async (req: AuthRequest, res: Response) => {
    console.log('🔐 Alterando senha do usuário:', req.params.id);
    
    try {
      const { id } = req.params;
      const { senhaAtual, novaSenha } = req.body;

      // Verificar se é o próprio usuário ou tem permissão de usuários
      const hasPermission = id === req.user.id.toString() || req.user.permissoes?.usuarios;
      
      if (!hasPermission) {
        console.log('❌ Sem permissão para alterar senha');
        return res.status(403).json({ error: 'Sem permissão para alterar senha de outros usuários' });
      }

      if (!novaSenha) {
        return res.status(400).json({ error: 'Nova senha é obrigatória' });
      }

      // Se for o próprio usuário, verificar senha atual
      if (id === req.user.id.toString() && !senhaAtual) {
        return res.status(400).json({ error: 'Senha atual é obrigatória' });
      }

      // Buscar usuário atual
      const userResult = await pool.query(
        'SELECT senha FROM usuarios WHERE id = $1',
        [id]
      );

      if (userResult.rows.length === 0) {
        return res.status(404).json({ error: 'Usuário não encontrado' });
      }

      // Verificar senha atual se for o próprio usuário
      if (id === req.user.id.toString()) {
        const senhaValida = await bcrypt.compare(senhaAtual, userResult.rows[0].senha);
        if (!senhaValida) {
          console.log('❌ Senha atual incorreta');
          return res.status(400).json({ error: 'Senha atual incorreta' });
        }
      }

      // Hash da nova senha
      const novaSenhaHash = await bcrypt.hash(novaSenha, 12);

      await pool.query(
        'UPDATE usuarios SET senha = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
        [novaSenhaHash, id]
      );

      console.log('✅ Senha alterada com sucesso');
      res.json({ message: 'Senha alterada com sucesso' });
    } catch (error) {
      console.error('❌ Erro ao alterar senha:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
);

export default router;
