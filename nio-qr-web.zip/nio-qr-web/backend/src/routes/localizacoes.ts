
import express, { Request, Response } from 'express';
import pool from '../config/database';
import { authenticateToken, requirePermission } from '../middleware/auth';
import { logUserActivity } from '../middleware/logger';

const router = express.Router();

interface AuthRequest extends Request {
  user?: any;
}

// Listar localizações
router.get('/', 
  authenticateToken, 
  requirePermission('localizacao'), 
  async (req: Request, res: Response) => {
    try {
      const result = await pool.query(`
        SELECT * FROM localizacoes
        ORDER BY bloco, andar, setor, sala
      `);

      res.json(result.rows);
    } catch (error) {
      console.error('Erro ao listar localizações:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
);

// Buscar localização por ID
router.get('/:id', 
  authenticateToken, 
  requirePermission('localizacao'), 
  async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      
      const result = await pool.query('SELECT * FROM localizacoes WHERE id = $1', [id]);

      if (result.rows.length === 0) {
        return res.status(404).json({ error: 'Localização não encontrada' });
      }

      res.json(result.rows[0]);
    } catch (error) {
      console.error('Erro ao buscar localização:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
);

// Criar localização
router.post('/', 
  authenticateToken, 
  requirePermission('localizacao'),
  logUserActivity('Criou', 'Localização'),
  async (req: Request, res: Response) => {
    try {
      const { bloco, andar, setor, sala, descricao, capacidade, responsavel, observacoes } = req.body;

      if (!setor || !sala) {
        return res.status(400).json({ error: 'Setor e sala são obrigatórios' });
      }

      const result = await pool.query(`
        INSERT INTO localizacoes (bloco, andar, setor, sala, descricao, capacidade, responsavel, observacoes)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
        RETURNING *
      `, [bloco, andar, setor, sala, descricao, capacidade, responsavel, observacoes]);

      res.status(201).json(result.rows[0]);
    } catch (error) {
      console.error('Erro ao criar localização:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
);

// Atualizar localização
router.put('/:id', 
  authenticateToken, 
  requirePermission('localizacao'),
  logUserActivity('Editou', 'Localização'),
  async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const { bloco, andar, setor, sala, descricao, capacidade, responsavel, observacoes } = req.body;

      const result = await pool.query(`
        UPDATE localizacoes 
        SET bloco = $1, andar = $2, setor = $3, sala = $4, descricao = $5, 
            capacidade = $6, responsavel = $7, observacoes = $8, updated_at = CURRENT_TIMESTAMP
        WHERE id = $9
        RETURNING *
      `, [bloco, andar, setor, sala, descricao, capacidade, responsavel, observacoes, id]);

      if (result.rows.length === 0) {
        return res.status(404).json({ error: 'Localização não encontrada' });
      }

      res.json(result.rows[0]);
    } catch (error) {
      console.error('Erro ao atualizar localização:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
);

// Deletar localização
router.delete('/:id', 
  authenticateToken, 
  requirePermission('localizacao'),
  logUserActivity('Excluiu', 'Localização'),
  async (req: Request, res: Response) => {
    try {
      const { id } = req.params;

      const result = await pool.query('DELETE FROM localizacoes WHERE id = $1 RETURNING id', [id]);

      if (result.rows.length === 0) {
        return res.status(404).json({ error: 'Localização não encontrada' });
      }

      res.json({ message: 'Localização excluída com sucesso' });
    } catch (error) {
      console.error('Erro ao excluir localização:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
);

export default router;
