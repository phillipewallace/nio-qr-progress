
import express, { Request, Response } from 'express';
import pool from '../config/database';
import { authenticateToken, requirePermission } from '../middleware/auth';
import { logUserActivity } from '../middleware/logger';

const router = express.Router();

interface AuthRequest extends Request {
  user?: any;
}

// Listar seguros
router.get('/', 
  authenticateToken, 
  requirePermission('seguros'), 
  async (req: Request, res: Response) => {
    try {
      const result = await pool.query(`
        SELECT s.*, p.nome as patrimonio_nome, p.codigo as patrimonio_codigo
        FROM seguros s
        LEFT JOIN patrimonios p ON s.patrimonio_id = p.id
        ORDER BY s.created_at DESC
      `);

      res.json(result.rows);
    } catch (error) {
      console.error('Erro ao listar seguros:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
);

// Buscar seguro por ID
router.get('/:id', 
  authenticateToken, 
  requirePermission('seguros'), 
  async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      
      const result = await pool.query(`
        SELECT s.*, p.nome as patrimonio_nome, p.codigo as patrimonio_codigo
        FROM seguros s
        LEFT JOIN patrimonios p ON s.patrimonio_id = p.id
        WHERE s.id = $1
      `, [id]);

      if (result.rows.length === 0) {
        return res.status(404).json({ error: 'Seguro não encontrado' });
      }

      res.json(result.rows[0]);
    } catch (error) {
      console.error('Erro ao buscar seguro:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
);

// Criar seguro
router.post('/', 
  authenticateToken, 
  requirePermission('seguros'),
  logUserActivity('Criou', 'Seguro'),
  async (req: Request, res: Response) => {
    try {
      const { 
        patrimonio_id, seguradora, numero_apolice, tipo_cobertura, valor_segurado,
        valor_premio, data_inicio, data_vencimento, status, observacoes 
      } = req.body;

      if (!patrimonio_id || !seguradora || !numero_apolice || !valor_segurado) {
        return res.status(400).json({ 
          error: 'Patrimônio, seguradora, número da apólice e valor segurado são obrigatórios' 
        });
      }

      const result = await pool.query(`
        INSERT INTO seguros (
          patrimonio_id, seguradora, numero_apolice, tipo_cobertura, valor_segurado,
          valor_premio, data_inicio, data_vencimento, status, observacoes
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
        RETURNING *
      `, [
        patrimonio_id, seguradora, numero_apolice, tipo_cobertura, valor_segurado,
        valor_premio, data_inicio, data_vencimento, status || 'Ativo', observacoes
      ]);

      res.status(201).json(result.rows[0]);
    } catch (error) {
      console.error('Erro ao criar seguro:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
);

// Atualizar seguro
router.put('/:id', 
  authenticateToken, 
  requirePermission('seguros'),
  logUserActivity('Editou', 'Seguro'),
  async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const { 
        patrimonio_id, seguradora, numero_apolice, tipo_cobertura, valor_segurado,
        valor_premio, data_inicio, data_vencimento, status, observacoes 
      } = req.body;

      const result = await pool.query(`
        UPDATE seguros 
        SET patrimonio_id = $1, seguradora = $2, numero_apolice = $3, tipo_cobertura = $4,
            valor_segurado = $5, valor_premio = $6, data_inicio = $7, data_vencimento = $8,
            status = $9, observacoes = $10, updated_at = CURRENT_TIMESTAMP
        WHERE id = $11
        RETURNING *
      `, [
        patrimonio_id, seguradora, numero_apolice, tipo_cobertura, valor_segurado,
        valor_premio, data_inicio, data_vencimento, status, observacoes, id
      ]);

      if (result.rows.length === 0) {
        return res.status(404).json({ error: 'Seguro não encontrado' });
      }

      res.json(result.rows[0]);
    } catch (error) {
      console.error('Erro ao atualizar seguro:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
);

// Deletar seguro
router.delete('/:id', 
  authenticateToken, 
  requirePermission('seguros'),
  logUserActivity('Excluiu', 'Seguro'),
  async (req: Request, res: Response) => {
    try {
      const { id } = req.params;

      const result = await pool.query('DELETE FROM seguros WHERE id = $1 RETURNING id', [id]);

      if (result.rows.length === 0) {
        return res.status(404).json({ error: 'Seguro não encontrado' });
      }

      res.json({ message: 'Seguro excluído com sucesso' });
    } catch (error) {
      console.error('Erro ao excluir seguro:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
);

export default router;
