
import express, { Request, Response } from 'express';
import pool from '../config/database';
import { authenticateToken, requirePermission } from '../middleware/auth';
import { logUserActivity } from '../middleware/logger';

const router = express.Router();

interface AuthRequest extends Request {
  user?: any;
}

// Listar manutenções
router.get('/', 
  authenticateToken, 
  requirePermission('manutencao'), 
  async (req: Request, res: Response) => {
    try {
      const result = await pool.query(`
        SELECT m.*, p.nome as patrimonio_nome, p.codigo as patrimonio_codigo
        FROM manutencoes m
        LEFT JOIN patrimonios p ON m.patrimonio_id = p.id
        ORDER BY m.created_at DESC
      `);

      res.json(result.rows);
    } catch (error) {
      console.error('Erro ao listar manutenções:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
);

// Buscar manutenção por ID
router.get('/:id', 
  authenticateToken, 
  requirePermission('manutencao'), 
  async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      
      const result = await pool.query(`
        SELECT m.*, p.nome as patrimonio_nome, p.codigo as patrimonio_codigo
        FROM manutencoes m
        LEFT JOIN patrimonios p ON m.patrimonio_id = p.id
        WHERE m.id = $1
      `, [id]);

      if (result.rows.length === 0) {
        return res.status(404).json({ error: 'Manutenção não encontrada' });
      }

      res.json(result.rows[0]);
    } catch (error) {
      console.error('Erro ao buscar manutenção:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
);

// Criar manutenção
router.post('/', 
  authenticateToken, 
  requirePermission('manutencao'),
  logUserActivity('Criou', 'Manutenção'),
  async (req: Request, res: Response) => {
    try {
      const { 
        patrimonio_id, tipo, titulo, descricao, prioridade, status, 
        data_solicitacao, data_agendamento, data_conclusao, responsavel_solicitacao,
        responsavel_execucao, custo, observacoes 
      } = req.body;

      if (!patrimonio_id || !tipo || !titulo || !descricao) {
        return res.status(400).json({ 
          error: 'Patrimônio, tipo, título e descrição são obrigatórios' 
        });
      }

      const result = await pool.query(`
        INSERT INTO manutencoes (
          patrimonio_id, tipo, titulo, descricao, prioridade, status,
          data_solicitacao, data_agendamento, data_conclusao, responsavel_solicitacao,
          responsavel_execucao, custo, observacoes
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
        RETURNING *
      `, [
        patrimonio_id, tipo, titulo, descricao, prioridade || 'Média', status || 'Pendente',
        data_solicitacao, data_agendamento, data_conclusao, responsavel_solicitacao,
        responsavel_execucao, custo, observacoes
      ]);

      res.status(201).json(result.rows[0]);
    } catch (error) {
      console.error('Erro ao criar manutenção:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
);

// Atualizar manutenção
router.put('/:id', 
  authenticateToken, 
  requirePermission('manutencao'),
  logUserActivity('Editou', 'Manutenção'),
  async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const { 
        patrimonio_id, tipo, titulo, descricao, prioridade, status, 
        data_solicitacao, data_agendamento, data_conclusao, responsavel_solicitacao,
        responsavel_execucao, custo, observacoes 
      } = req.body;

      const result = await pool.query(`
        UPDATE manutencoes 
        SET patrimonio_id = $1, tipo = $2, titulo = $3, descricao = $4, prioridade = $5,
            status = $6, data_solicitacao = $7, data_agendamento = $8, data_conclusao = $9,
            responsavel_solicitacao = $10, responsavel_execucao = $11, custo = $12, 
            observacoes = $13, updated_at = CURRENT_TIMESTAMP
        WHERE id = $14
        RETURNING *
      `, [
        patrimonio_id, tipo, titulo, descricao, prioridade, status,
        data_solicitacao, data_agendamento, data_conclusao, responsavel_solicitacao,
        responsavel_execucao, custo, observacoes, id
      ]);

      if (result.rows.length === 0) {
        return res.status(404).json({ error: 'Manutenção não encontrada' });
      }

      res.json(result.rows[0]);
    } catch (error) {
      console.error('Erro ao atualizar manutenção:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
);

// Deletar manutenção
router.delete('/:id', 
  authenticateToken, 
  requirePermission('manutencao'),
  logUserActivity('Excluiu', 'Manutenção'),
  async (req: Request, res: Response) => {
    try {
      const { id } = req.params;

      const result = await pool.query('DELETE FROM manutencoes WHERE id = $1 RETURNING id', [id]);

      if (result.rows.length === 0) {
        return res.status(404).json({ error: 'Manutenção não encontrada' });
      }

      res.json({ message: 'Manutenção excluída com sucesso' });
    } catch (error) {
      console.error('Erro ao excluir manutenção:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
);

export default router;
