
import express, { Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import pool from '../config/database';
import { authenticateToken } from '../middleware/auth';

const router = express.Router();

interface AuthRequest extends Request {
  user?: any;
}

router.post('/login', async (req: Request, res: Response) => {
  console.log('🔐 [AUTH] Tentativa de login');
  console.log('📝 [AUTH] Body:', req.body);
  
  try {
    const { usuario, senha } = req.body;

    if (!usuario || !senha) {
      console.log('❌ [AUTH] Campos obrigatórios em falta');
      return res.status(400).json({ error: 'Usuário e senha são obrigatórios' });
    }

    console.log('🔍 [AUTH] Buscando usuário:', usuario);
    
    const result = await pool.query(
      'SELECT id, nome, usuario, senha, permissoes, status FROM usuarios WHERE usuario = $1',
      [usuario]
    );

    console.log('📊 [AUTH] Resultado da consulta:', result.rowCount, 'linha(s)');

    if (result.rows.length === 0) {
      console.log('❌ [AUTH] Usuário não encontrado');
      return res.status(401).json({ error: 'Credenciais inválidas' });
    }

    const user = result.rows[0];
    console.log('👤 [AUTH] Usuário encontrado:', user.nome, '- Status:', user.status);
    console.log('🔍 [AUTH] Senha no banco:', user.senha);
    console.log('🔍 [AUTH] Senha enviada:', senha);

    if (user.status !== 'Ativo') {
      console.log('❌ [AUTH] Usuário inativo');
      return res.status(401).json({ error: 'Usuário inativo' });
    }

    // Verificar senha - primeiro tenta texto plano, depois bcrypt
    let senhaValida = false;
    
    // Verificação de texto plano (para senhas não hasheadas)
    if (senha === user.senha) {
      senhaValida = true;
      console.log('✅ [AUTH] Verificação texto plano: VÁLIDA');
    } else {
      // Tentar bcrypt caso seja uma senha hasheada
      try {
        senhaValida = await bcrypt.compare(senha, user.senha);
        console.log('🔐 [AUTH] Verificação bcrypt:', senhaValida);
      } catch (error) {
        console.log('⚠️ [AUTH] Erro na verificação bcrypt:', error);
        senhaValida = false;
      }
    }

    if (!senhaValida) {
      console.log('❌ [AUTH] Senha incorreta');
      return res.status(401).json({ error: 'Credenciais inválidas' });
    }

    // Atualizar último acesso
    await pool.query(
      'UPDATE usuarios SET ultimo_acesso = CURRENT_TIMESTAMP WHERE id = $1',
      [user.id]
    );

    // Gerar token
    const token = jwt.sign(
      { 
        id: user.id, 
        usuario: user.usuario,
        nome: user.nome 
      },
      process.env.JWT_SECRET || 'fallback-secret',
      { expiresIn: process.env.JWT_EXPIRES_IN || '24h' }
    );

    console.log('✅ [AUTH] Login realizado com sucesso:', user.nome);

    // Log da atividade
    try {
      await pool.query(
        `INSERT INTO user_logs (usuario_id, acao, modulo, detalhes, ip_address, user_agent) 
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [
          user.id,
          'Login',
          'Autenticação',
          'Usuário fez login no sistema',
          req.ip || 'unknown',
          req.get('User-Agent') || 'unknown'
        ]
      );
    } catch (logError) {
      console.error('⚠️ [AUTH] Erro ao salvar log:', logError);
    }

    res.json({
      token,
      usuario: {
        id: user.id,
        nome: user.nome,
        usuario: user.usuario,
        permissoes: user.permissoes
      }
    });
  } catch (error) {
    console.error('❌ [AUTH] Erro interno:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

router.get('/verify', authenticateToken, async (req: AuthRequest, res: Response) => {
  console.log('🔍 [AUTH] Verificação de token:', req.user?.nome);
  res.json({ usuario: req.user });
});

router.post('/logout', authenticateToken, async (req: AuthRequest, res: Response) => {
  console.log('👋 [AUTH] Logout:', req.user?.nome);
  
  try {
    await pool.query(
      `INSERT INTO user_logs (usuario_id, acao, modulo, detalhes, ip_address, user_agent) 
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [
        req.user.id,
        'Logout',
        'Autenticação',
        'Usuário fez logout do sistema',
        req.ip || 'unknown',
        req.get('User-Agent') || 'unknown'
      ]
    );
  } catch (logError) {
    console.error('⚠️ [AUTH] Erro ao salvar log de logout:', logError);
  }

  res.json({ message: 'Logout realizado com sucesso' });
});

export default router;
