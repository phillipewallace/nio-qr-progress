
import { Request, Response, NextFunction } from 'express';
import pool from '../config/database';

interface AuthRequest extends Request {
  user?: any;
}

export const logUserActivity = (action: string, module: string) => {
  return async (req: AuthRequest, res: Response, next: NextFunction) => {
    // Execute the route handler first
    next();
    
    // Log after the response is sent
    res.on('finish', async () => {
      try {
        if (req.user && res.statusCode < 400) {
          console.log(`📝 [LOG] Registrando atividade: ${action} ${module}`);
          
          const details = `${action} ${module} - Status: ${res.statusCode}`;
          
          await pool.query(
            `INSERT INTO user_logs (usuario_id, acao, modulo, detalhes, ip_address) 
             VALUES ($1, $2, $3, $4, $5)`,
            [
              req.user.id,
              action,
              module,
              details,
              req.ip || 'unknown'
            ]
          );
          
          console.log(`✅ [LOG] Atividade registrada com sucesso`);
        }
      } catch (error) {
        console.error('⚠️ [LOG] Erro ao salvar log de atividade:', error);
      }
    });
  };
};
