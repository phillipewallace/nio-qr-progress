
import jwt from 'jsonwebtoken';
import { Request, Response, NextFunction } from 'express';
import pool from '../config/database';

interface AuthRequest extends Request {
  user?: any;
}

export const authenticateToken = async (req: AuthRequest, res: Response, next: NextFunction) => {
  console.log('🔐 Verificando autenticação...');
  console.log('📋 Headers da requisição:', req.headers);
  
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  console.log('🎫 Token presente:', !!token);

  if (!token) {
    console.log('❌ Token não fornecido');
    return res.status(401).json({ error: 'Token de acesso requerido' });
  }

  try {
    console.log('🔍 Verificando token JWT...');
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'fallback-secret') as any;
    console.log('✅ Token decodificado:', { id: decoded.id, usuario: decoded.usuario });

    // Buscar dados atualizados do usuário
    const result = await pool.query(
      'SELECT id, nome, usuario, permissoes, status FROM usuarios WHERE id = $1',
      [decoded.id]
    );

    if (result.rows.length === 0) {
      console.log('❌ Usuário não encontrado no banco');
      return res.status(401).json({ error: 'Usuário não encontrado' });
    }

    const user = result.rows[0];
    
    if (user.status !== 'Ativo') {
      console.log('❌ Usuário inativo');
      return res.status(401).json({ error: 'Usuário inativo' });
    }

    req.user = user;
    console.log('✅ Usuário autenticado:', user.nome);
    next();
  } catch (error) {
    console.error('❌ Erro na verificação do token:', error);
    return res.status(403).json({ error: 'Token inválido' });
  }
};

export const requirePermission = (module: string, level: string = 'viewer') => {
  return (req: AuthRequest, res: Response, next: NextFunction) => {
    console.log(`🔒 Verificando permissão: ${module} (${level})`);
    
    if (!req.user) {
      console.log('❌ Usuário não autenticado');
      return res.status(401).json({ error: 'Usuário não autenticado' });
    }

    const userPermissions = req.user.permissoes || {};
    const userPermission = userPermissions[module];

    console.log('👤 Permissões do usuário:', userPermissions);
    console.log(`🔍 Permissão para ${module}:`, userPermission);

    // Hierarquia: admin > editor > viewer
    const permissionLevels = { 'viewer': 1, 'editor': 2, 'admin': 3 };
    const requiredLevel = permissionLevels[level as keyof typeof permissionLevels] || 1;
    const userLevel = permissionLevels[userPermission as keyof typeof permissionLevels] || 0;

    if (userLevel >= requiredLevel) {
      console.log('✅ Permissão concedida');
      next();
    } else {
      console.log('❌ Permissão negada');
      res.status(403).json({ error: 'Permissão insuficiente' });
    }
  };
};
