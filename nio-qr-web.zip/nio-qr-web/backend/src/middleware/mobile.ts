
import { Request, Response, NextFunction } from 'express';
import pool from '../config/database';

interface MobileRequest extends Request {
  user?: any;
  deviceInfo?: {
    type: string;
    model?: string;
    version?: string;
  };
}

// Middleware para detectar dispositivo mobile
export const detectMobileDevice = (req: MobileRequest, res: Response, next: NextFunction) => {
  const userAgent = req.headers['user-agent'] || '';
  const deviceType = req.headers['x-device-type'] as string || 'web';
  
  console.log('📱 [MOBILE] Detectando dispositivo...');
  console.log('🔍 [MOBILE] User-Agent:', userAgent);
  console.log('📋 [MOBILE] Device-Type Header:', deviceType);
  
  // Detectar se é mobile pelo user agent ou header customizado
  const isMobile = deviceType === 'mobile' || 
                   /Mobile|Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(userAgent);
  
  req.deviceInfo = {
    type: isMobile ? 'mobile' : 'web',
    model: req.headers['x-device-model'] as string,
    version: req.headers['x-app-version'] as string
  };
  
  console.log('📱 [MOBILE] Dispositivo detectado:', req.deviceInfo);
  
  // Adicionar headers de resposta para mobile
  if (isMobile) {
    res.setHeader('X-Mobile-API', 'true');
    res.setHeader('X-Sync-Available', 'true');
  }
  
  next();
};

// Middleware para validar dados específicos do mobile
export const validateMobileData = (req: MobileRequest, res: Response, next: NextFunction) => {
  if (req.deviceInfo?.type === 'mobile') {
    console.log('📱 [MOBILE] Validando dados mobile...');
    
    // Validações específicas para mobile
    if (req.body && req.body.localizacao_gps) {
      const gps = req.body.localizacao_gps;
      if (typeof gps === 'string') {
        try {
          req.body.localizacao_gps = JSON.parse(gps);
        } catch (error) {
          console.error('❌ [MOBILE] Erro ao parsear GPS:', error);
          return res.status(400).json({ 
            error: 'Formato de localização GPS inválido',
            mobile: true 
          });
        }
      }
    }
    
    // Validar se foto está em base64 (para upload mobile)
    if (req.body && req.body.foto && req.body.foto.startsWith('data:image/')) {
      console.log('📸 [MOBILE] Foto em base64 detectada');
      // Aqui poderia haver processamento da imagem se necessário
    }
  }
  
  next();
};

// Middleware para registrar atividade mobile
export const logMobileActivity = async (req: MobileRequest, res: Response, next: NextFunction) => {
  if (req.deviceInfo?.type === 'mobile' && req.user) {
    try {
      await pool.query(`
        INSERT INTO user_logs (usuario_id, acao, modulo, detalhes, ip_address, user_agent, dispositivo)
        VALUES ($1, $2, $3, $4, $5, $6, $7)
      `, [
        req.user.id,
        req.method,
        'Mobile API',
        `${req.method} ${req.path}`,
        req.ip || 'unknown',
        req.headers['user-agent'] || 'unknown',
        'Mobile'
      ]);
      
      console.log('📱 [MOBILE] Atividade registrada para usuário:', req.user.nome);
    } catch (error) {
      console.error('⚠️ [MOBILE] Erro ao registrar atividade:', error);
      // Não bloquear a requisição por erro de log
    }
  }
  
  next();
};

// Middleware para otimizar resposta mobile
export const optimizeMobileResponse = (req: MobileRequest, res: Response, next: NextFunction) => {
  if (req.deviceInfo?.type === 'mobile') {
    // Interceptar res.json para otimizar dados para mobile
    const originalJson = res.json;
    
    res.json = function(body: any) {
      console.log('📱 [MOBILE] Otimizando resposta para mobile...');
      
      // Adicionar metadados móveis
      const mobileResponse = {
        ...body,
        _mobile: {
          timestamp: new Date().toISOString(),
          sync_available: true,
          device_type: req.deviceInfo?.type,
          app_version: req.deviceInfo?.version
        }
      };
      
      // Remover campos desnecessários em arrays grandes
      if (Array.isArray(body) && body.length > 10) {
        console.log('📱 [MOBILE] Lista grande detectada, otimizando...');
        // Manter apenas campos essenciais para listas
      }
      
      return originalJson.call(this, mobileResponse);
    };
  }
  
  next();
};

// Middleware para verificar conectividade e sync
export const checkSyncStatus = async (req: MobileRequest, res: Response, next: NextFunction) => {
  if (req.deviceInfo?.type === 'mobile' && req.user) {
    try {
      // Verificar se há dados pendentes de sincronização
      const syncResult = await pool.query(`
        SELECT COUNT(*) as pendente
        FROM sync_mobile 
        WHERE usuario_id = $1 AND sincronizado = FALSE
      `, [req.user.id]);
      
      const pendente = parseInt(syncResult.rows[0].pendente);
      
      if (pendente > 0) {
        res.setHeader('X-Sync-Pending', pendente.toString());
        console.log(`📱 [MOBILE] ${pendente} itens pendentes de sincronização`);
      }
      
    } catch (error) {
      console.error('⚠️ [MOBILE] Erro ao verificar sync:', error);
    }
  }
  
  next();
};

export default {
  detectMobileDevice,
  validateMobileData,
  logMobileActivity,
  optimizeMobileResponse,
  checkSyncStatus
};
