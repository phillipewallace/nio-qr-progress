
import React from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  ArrowLeft, 
  Package, 
  MapPin, 
  User, 
  Calendar,
  DollarSign,
  Camera,
  QrCode,
  Edit
} from 'lucide-react';

// Mock data - will be replaced with API call
const mockPatrimonio = {
  id: '1',
  codigo: 'PAT-001',
  nome: 'Notebook Dell Latitude',
  descricao: 'Notebook para uso administrativo com Windows 11 Pro',
  categoria: 'Informática',
  subcategoria: 'Computadores',
  marca: 'Dell',
  modelo: 'Latitude 5520',
  numeroSerie: 'DL123456789',
  status: 'Ativo',
  condicao: 'Seminovo',
  valorCompra: 2500.00,
  valorAtual: 2000.00,
  dataCompra: '2024-01-15',
  dataVencimentoGarantia: '2025-01-15',
  fornecedor: 'TechSupply Ltda',
  garantia: '12 meses',
  localizacao: {
    setor: 'TI',
    andar: '2º andar',
    sala: '201',
    detalhes: 'Mesa 3'
  },
  responsavel: {
    nome: 'João Silva',
    cargo: 'Analista de TI',
    email: 'joao.silva@empresa.com',
    telefone: '(11) 99999-9999'
  },
  observacoes: 'Equipamento em perfeito estado de funcionamento.',
  foto: null
};

export default function PatrimonioDetails() {
  const navigate = useNavigate();
  const { id } = useParams();

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Ativo': return 'bg-green-100 text-green-800';
      case 'Inativo': return 'bg-gray-100 text-gray-800';
      case 'Manutenção': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getCondicaoColor = (condicao: string) => {
    switch (condicao) {
      case 'Novo': return 'bg-blue-100 text-blue-800';
      case 'Seminovo': return 'bg-green-100 text-green-800';
      case 'Usado': return 'bg-yellow-100 text-yellow-800';
      case 'Danificado': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="p-4 space-y-6">
      <div className="flex items-center gap-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => navigate('/patrimonio')}
        >
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div className="flex-1">
          <h2 className="text-xl font-bold text-gray-900">{mockPatrimonio.nome}</h2>
          <p className="text-sm text-gray-500">{mockPatrimonio.codigo}</p>
        </div>
        <Button variant="outline" size="icon">
          <Edit className="h-4 w-4" />
        </Button>
      </div>

      {/* Photo Section */}
      <Card>
        <CardContent className="p-4">
          <div className="aspect-video bg-gray-100 rounded-lg flex items-center justify-center mb-4">
            {mockPatrimonio.foto ? (
              <img 
                src={mockPatrimonio.foto} 
                alt={mockPatrimonio.nome}
                className="w-full h-full object-cover rounded-lg"
              />
            ) : (
              <div className="text-center">
                <Camera className="h-12 w-12 text-gray-400 mx-auto mb-2" />
                <p className="text-sm text-gray-500">Nenhuma foto disponível</p>
              </div>
            )}
          </div>
          <Button variant="outline" className="w-full gap-2">
            <Camera className="h-4 w-4" />
            {mockPatrimonio.foto ? 'Atualizar Foto' : 'Adicionar Foto'}
          </Button>
        </CardContent>
      </Card>

      {/* Status and Basic Info */}
      <Card>
        <CardHeader>
          <CardTitle>Informações Gerais</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Badge className={getStatusColor(mockPatrimonio.status)}>
              {mockPatrimonio.status}
            </Badge>
            <Badge className={getCondicaoColor(mockPatrimonio.condicao)}>
              {mockPatrimonio.condicao}
            </Badge>
          </div>

          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-gray-600">Categoria</p>
              <p className="font-medium">{mockPatrimonio.categoria}</p>
            </div>
            <div>
              <p className="text-gray-600">Subcategoria</p>
              <p className="font-medium">{mockPatrimonio.subcategoria}</p>
            </div>
            <div>
              <p className="text-gray-600">Marca</p>
              <p className="font-medium">{mockPatrimonio.marca}</p>
            </div>
            <div>
              <p className="text-gray-600">Modelo</p>
              <p className="font-medium">{mockPatrimonio.modelo}</p>
            </div>
          </div>

          {mockPatrimonio.descricao && (
            <div>
              <p className="text-gray-600 text-sm">Descrição</p>
              <p className="text-sm">{mockPatrimonio.descricao}</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Financial Info */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="h-5 w-5" />
            Informações Financeiras
          </CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <p className="text-gray-600">Valor de Compra</p>
            <p className="font-medium text-lg">
              R$ {mockPatrimonio.valorCompra.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
            </p>
          </div>
          <div>
            <p className="text-gray-600">Valor Atual</p>
            <p className="font-medium text-lg">
              R$ {mockPatrimonio.valorAtual.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
            </p>
          </div>
          <div>
            <p className="text-gray-600">Data de Compra</p>
            <p className="font-medium">
              {new Date(mockPatrimonio.dataCompra).toLocaleDateString('pt-BR')}
            </p>
          </div>
          <div>
            <p className="text-gray-600">Fornecedor</p>
            <p className="font-medium">{mockPatrimonio.fornecedor}</p>
          </div>
        </CardContent>
      </Card>

      {/* Location */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MapPin className="h-5 w-5" />
            Localização
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-gray-600">Setor:</span>
            <span className="font-medium">{mockPatrimonio.localizacao.setor}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Andar:</span>
            <span className="font-medium">{mockPatrimonio.localizacao.andar}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Sala:</span>
            <span className="font-medium">{mockPatrimonio.localizacao.sala}</span>
          </div>
          {mockPatrimonio.localizacao.detalhes && (
            <div className="flex justify-between">
              <span className="text-gray-600">Detalhes:</span>
              <span className="font-medium">{mockPatrimonio.localizacao.detalhes}</span>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Responsible */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            Responsável
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-gray-600">Nome:</span>
            <span className="font-medium">{mockPatrimonio.responsavel.nome}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Cargo:</span>
            <span className="font-medium">{mockPatrimonio.responsavel.cargo}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Email:</span>
            <span className="font-medium">{mockPatrimonio.responsavel.email}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Telefone:</span>
            <span className="font-medium">{mockPatrimonio.responsavel.telefone}</span>
          </div>
        </CardContent>
      </Card>

      {/* Actions */}
      <div className="grid grid-cols-2 gap-4">
        <Button variant="outline" className="gap-2">
          <QrCode className="h-4 w-4" />
          Ver QR Code
        </Button>
        <Button className="gap-2">
          <Edit className="h-4 w-4" />
          Editar
        </Button>
      </div>
    </div>
  );
}
