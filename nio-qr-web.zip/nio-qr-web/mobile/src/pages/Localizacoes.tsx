
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  MapPin, 
  Search, 
  Plus, 
  Building,
  Users,
  Package
} from 'lucide-react';

const mockLocalizacoes = [
  {
    id: '1',
    setor: 'Tecnologia da Informação',
    andar: '2º andar',
    sala: '201',
    bloco: 'A',
    responsavel: 'João Silva',
    capacidade: 15,
    ocupacao: 12,
    patrimonios: 8
  },
  {
    id: '2',
    setor: 'Recursos Humanos',
    andar: '1º andar',
    sala: '105',
    bloco: 'A',
    responsavel: 'Maria Santos',
    capacidade: 8,
    ocupacao: 6,
    patrimonios: 12
  },
  {
    id: '3',
    setor: 'Financeiro',
    andar: '3º andar',
    sala: '301',
    bloco: 'B',
    responsavel: 'Carlos Oliveira',
    capacidade: 20,
    ocupacao: 18,
    patrimonios: 15
  }
];

export default function Localizacoes() {
  const [searchTerm, setSearchTerm] = useState('');
  const [localizacoes] = useState(mockLocalizacoes);

  const filteredLocalizacoes = localizacoes.filter(local =>
    local.setor.toLowerCase().includes(searchTerm.toLowerCase()) ||
    local.sala.toLowerCase().includes(searchTerm.toLowerCase()) ||
    local.responsavel.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getOcupacaoColor = (ocupacao: number, capacidade: number) => {
    const percentual = (ocupacao / capacidade) * 100;
    if (percentual >= 90) return 'bg-red-100 text-red-800';
    if (percentual >= 70) return 'bg-yellow-100 text-yellow-800';
    return 'bg-green-100 text-green-800';
  };

  return (
    <div className="p-4 space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Localizações</h2>
        <Button className="gap-2">
          <Plus className="h-4 w-4" />
          Nova
        </Button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
        <Input
          placeholder="Buscar localização..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10"
        />
      </div>

      <div className="grid gap-4">
        {filteredLocalizacoes.map((local) => (
          <Card key={local.id} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Building className="h-5 w-5 text-blue-600" />
                    {local.setor}
                  </CardTitle>
                  <p className="text-sm text-gray-500 mt-1">
                    {local.andar} - Sala {local.sala} - Bloco {local.bloco}
                  </p>
                </div>
                <Badge className={getOcupacaoColor(local.ocupacao, local.capacidade)}>
                  {Math.round((local.ocupacao / local.capacidade) * 100)}%
                </Badge>
              </div>
            </CardHeader>
            
            <CardContent className="space-y-4">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Users className="h-4 w-4" />
                <span>Responsável: {local.responsavel}</span>
              </div>

              <div className="grid grid-cols-3 gap-4 text-center">
                <div className="bg-blue-50 p-3 rounded-lg">
                  <div className="flex items-center justify-center gap-1 mb-1">
                    <Users className="h-4 w-4 text-blue-600" />
                  </div>
                  <p className="text-xs text-gray-600">Capacidade</p>
                  <p className="font-semibold text-blue-600">{local.capacidade}</p>
                </div>
                
                <div className="bg-green-50 p-3 rounded-lg">
                  <div className="flex items-center justify-center gap-1 mb-1">
                    <Users className="h-4 w-4 text-green-600" />
                  </div>
                  <p className="text-xs text-gray-600">Ocupação</p>
                  <p className="font-semibold text-green-600">{local.ocupacao}</p>
                </div>
                
                <div className="bg-purple-50 p-3 rounded-lg">
                  <div className="flex items-center justify-center gap-1 mb-1">
                    <Package className="h-4 w-4 text-purple-600" />
                  </div>
                  <p className="text-xs text-gray-600">Patrimônios</p>
                  <p className="font-semibold text-purple-600">{local.patrimonios}</p>
                </div>
              </div>

              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="flex-1">
                  Ver Detalhes
                </Button>
                <Button variant="outline" size="sm" className="flex-1">
                  Ver Itens
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredLocalizacoes.length === 0 && (
        <div className="text-center py-12">
          <MapPin className="h-12 w-12 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            Nenhuma localização encontrada
          </h3>
          <p className="text-gray-500">
            Tente ajustar os termos de busca
          </p>
        </div>
      )}
    </div>
  );
}
