
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Smartphone, Eye, EyeOff, Shield, Wifi, WifiOff } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { useAuth } from '../contexts/AuthContext';
import { Haptics, ImpactStyle } from '@capacitor/haptics';

export default function MobileLogin() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });

  React.useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const handleHapticFeedback = async () => {
    try {
      await Haptics.impact({ style: ImpactStyle.Light });
    } catch (error) {
      // Haptics não disponível no navegador
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!isOnline) {
      await handleHapticFeedback();
      toast({
        title: 'Sem conexão',
        description: 'Verifique sua conexão com a internet.',
        variant: 'destructive',
      });
      return;
    }

    if (!formData.email || !formData.password) {
      await handleHapticFeedback();
      toast({
        title: 'Campos obrigatórios',
        description: 'Preencha email e senha.',
        variant: 'destructive',
      });
      return;
    }

    setLoading(true);
    
    try {
      await login(formData.email, formData.password);
      
      toast({
        title: 'Login realizado!',
        description: 'Bem-vindo ao PatrimônioTech Mobile.',
      });
      
      navigate('/');
    } catch (error) {
      await handleHapticFeedback();
      toast({
        title: 'Erro no login',
        description: 'Verifique suas credenciais.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-600 via-blue-700 to-purple-800 flex flex-col items-center justify-center p-4 relative overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_50%_50%,rgba(255,255,255,0.1)_0%,transparent_70%)]"></div>
        <div className="absolute top-1/4 left-1/4 w-32 h-32 bg-white/20 rounded-full animate-pulse"></div>
        <div className="absolute top-3/4 right-1/4 w-24 h-24 bg-purple-300/30 rounded-full animate-pulse delay-1000"></div>
        <div className="absolute bottom-1/4 left-1/3 w-20 h-20 bg-pink-300/30 rounded-full animate-pulse delay-2000"></div>
      </div>

      {/* Status de conexão */}
      <div className="absolute top-4 right-4 z-20">
        <div className={`flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium ${
          isOnline 
            ? 'bg-green-500/20 text-green-100 border border-green-400/30' 
            : 'bg-red-500/20 text-red-100 border border-red-400/30'
        }`}>
          {isOnline ? <Wifi className="h-3 w-3" /> : <WifiOff className="h-3 w-3" />}
          {isOnline ? 'Online' : 'Offline'}
        </div>
      </div>

      {/* Header Mobile */}
      <div className="text-center mb-8 z-10">
        <div className="bg-white/20 backdrop-blur-sm p-6 rounded-3xl mb-6 mx-auto w-24 h-24 flex items-center justify-center shadow-xl">
          <Smartphone className="h-12 w-12 text-white" />
        </div>
        <h1 className="text-4xl font-bold text-white mb-3 tracking-tight">PatrimônioTech</h1>
        <p className="text-blue-100 text-lg font-medium">Mobile App</p>
        <p className="text-blue-200 text-sm opacity-80 mt-1">Gestão patrimonial em suas mãos</p>
      </div>

      {/* Login Card Mobile-Optimized */}
      <Card className="w-full max-w-sm bg-white/95 backdrop-blur-sm border-0 shadow-2xl z-10 rounded-3xl">
        <CardHeader className="text-center pb-6 pt-8">
          <CardTitle className="text-2xl font-bold text-gray-900 mb-2">
            Acesso Mobile
          </CardTitle>
          <p className="text-gray-600 text-sm">
            Entre com suas credenciais
          </p>
        </CardHeader>
        
        <CardContent className="px-8 pb-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-3">
              <Label htmlFor="email" className="text-sm font-semibold text-gray-700">
                Email
              </Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData(prev => ({
                  ...prev,
                  email: e.target.value
                }))}
                placeholder="seu@email.com"
                required
                className="h-14 text-base border-gray-300 focus:border-blue-500 focus:ring-blue-500 rounded-xl"
              />
            </div>

            <div className="space-y-3">
              <Label htmlFor="password" className="text-sm font-semibold text-gray-700">
                Senha
              </Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  value={formData.password}
                  onChange={(e) => setFormData(prev => ({
                    ...prev,
                    password: e.target.value
                  }))}
                  placeholder="Sua senha"
                  required
                  className="h-14 text-base pr-14 border-gray-300 focus:border-blue-500 focus:ring-blue-500 rounded-xl"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="absolute right-0 top-0 h-14 px-4 hover:bg-transparent rounded-xl"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? (
                    <EyeOff className="h-5 w-5 text-gray-400" />
                  ) : (
                    <Eye className="h-5 w-5 text-gray-400" />
                  )}
                </Button>
              </div>
            </div>

            <Button
              type="submit"
              disabled={loading || !isOnline}
              className="w-full h-14 text-base font-semibold bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 shadow-lg rounded-xl"
            >
              {loading ? (
                <div className="flex items-center gap-3">
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  Entrando...
                </div>
              ) : (
                <div className="flex items-center gap-3">
                  <Shield className="h-5 w-5" />
                  Entrar no App
                </div>
              )}
            </Button>
          </form>

          {/* Demo credentials */}
          <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-xl">
            <p className="text-xs text-blue-800 text-center font-medium">
              <strong>Credenciais de teste:</strong><br />
              Email: admin@exemplo.com<br />
              Senha: admin123
            </p>
          </div>

          {/* Mobile Features */}
          <div className="mt-6 grid grid-cols-3 gap-4 text-center">
            <div className="p-3 bg-gray-50 rounded-xl">
              <div className="w-8 h-8 bg-blue-100 rounded-lg mx-auto mb-2 flex items-center justify-center">
                <span className="text-blue-600 text-xs">📱</span>
              </div>
              <p className="text-xs text-gray-600 font-medium">Touch ID</p>
            </div>
            <div className="p-3 bg-gray-50 rounded-xl">
              <div className="w-8 h-8 bg-green-100 rounded-lg mx-auto mb-2 flex items-center justify-center">
                <span className="text-green-600 text-xs">📴</span>
              </div>
              <p className="text-xs text-gray-600 font-medium">Offline</p>
            </div>
            <div className="p-3 bg-gray-50 rounded-xl">
              <div className="w-8 h-8 bg-purple-100 rounded-lg mx-auto mb-2 flex items-center justify-center">
                <span className="text-purple-600 text-xs">🔄</span>
              </div>
              <p className="text-xs text-gray-600 font-medium">Sync</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Footer Mobile */}
      <div className="mt-8 text-center z-10">
        <p className="text-blue-100 text-sm font-medium">
          Versão Mobile • Seguro e Offline
        </p>
        <p className="text-blue-200 text-xs opacity-75 mt-1">
          v1.0.0 • PatrimônioTech Mobile
        </p>
      </div>
    </div>
  );
}
