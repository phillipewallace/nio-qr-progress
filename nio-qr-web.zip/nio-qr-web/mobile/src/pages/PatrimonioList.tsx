
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  Package, 
  Search, 
  Plus, 
  Eye, 
  MapPin,
  Calendar,
  DollarSign
} from 'lucide-react';

// Mock data for now - will be replaced with API calls
const mockPatrimonios = [
  {
    id: '1',
    codigo: 'PAT-001',
    nome: 'Notebook Dell Latitude',
    categoria: 'Informática',
    status: 'Ativo',
    valor: 2500.00,
    localizacao: { setor: 'TI', sala: '101' },
    dataAquisicao: '2024-01-15'
  },
  {
    id: '2',
    codigo: 'PAT-002',
    nome: 'Mesa de Escritório',
    categoria: 'Móveis',
    status: 'Ativo',
    valor: 450.00,
    localizacao: { setor: 'Administrativo', sala: '205' },
    dataAquisicao: '2024-02-10'
  }
];

export default function PatrimonioList() {
  const [searchTerm, setSearchTerm] = useState('');
  const [patrimonios] = useState(mockPatrimonios);
  const navigate = useNavigate();

  const filteredPatrimonios = patrimonios.filter(item =>
    item.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.codigo.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Ativo': return 'bg-green-100 text-green-800';
      case 'Inativo': return 'bg-gray-100 text-gray-800';
      case 'Manutenção': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="p-4 space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Patrimônio</h2>
        <Button 
          onClick={() => navigate('/patrimonio/novo')}
          className="gap-2"
        >
          <Plus className="h-4 w-4" />
          Novo
        </Button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
        <Input
          placeholder="Buscar patrimônio..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10"
        />
      </div>

      <div className="grid gap-4">
        {filteredPatrimonios.map((item) => (
          <Card key={item.id} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <CardTitle className="text-lg">{item.nome}</CardTitle>
                  <p className="text-sm text-gray-500 mt-1">{item.codigo}</p>
                </div>
                <Badge className={getStatusColor(item.status)}>
                  {item.status}
                </Badge>
              </div>
            </CardHeader>
            
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Package className="h-4 w-4" />
                <span>{item.categoria}</span>
              </div>
              
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <MapPin className="h-4 w-4" />
                <span>{item.localizacao.setor} - Sala {item.localizacao.sala}</span>
              </div>
              
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <DollarSign className="h-4 w-4" />
                <span>R$ {item.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
              </div>
              
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Calendar className="h-4 w-4" />
                <span>{new Date(item.dataAquisicao).toLocaleDateString('pt-BR')}</span>
              </div>

              <div className="flex gap-2 pt-2">
                <Button
                  onClick={() => navigate(`/patrimonio/${item.id}`)}
                  variant="outline"
                  size="sm"
                  className="flex-1 gap-2"
                >
                  <Eye className="h-4 w-4" />
                  Ver Detalhes
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredPatrimonios.length === 0 && (
        <div className="text-center py-12">
          <Package className="h-12 w-12 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            Nenhum patrimônio encontrado
          </h3>
          <p className="text-gray-500">
            Tente ajustar os termos de busca
          </p>
        </div>
      )}
    </div>
  );
}
