
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  Wrench, 
  Search, 
  Plus, 
  Calendar,
  DollarSign,
  User,
  AlertTriangle,
  CheckCircle,
  Clock
} from 'lucide-react';

const mockManutencoes = [
  {
    id: '1',
    patrimonio: {
      codigo: 'PAT-001',
      nome: 'Notebook Dell Latitude'
    },
    tipo: 'Corretiva',
    status: 'Em Andamento',
    prioridade: 'Alta',
    dataInicio: '2024-01-20',
    dataPrevista: '2024-01-25',
    tecnico: 'Carlos Tech',
    empresa: 'TechSupport Ltda',
    valor: 350.00,
    descricao: 'Substituição de HD danificado'
  },
  {
    id: '2',
    patrimonio: {
      codigo: 'PAT-005',
      nome: 'Impressora HP LaserJet'
    },
    tipo: 'Preventiva',
    status: 'Agendada',
    prioridade: 'Normal',
    dataInicio: '2024-01-30',
    dataPrevista: '2024-01-30',
    tecnico: 'Ana Santos',
    empresa: 'PrintService',
    valor: 120.00,
    descricao: 'Limpeza e calibração preventiva'
  },
  {
    id: '3',
    patrimonio: {
      codigo: 'PAT-012',
      nome: 'Ar Condicionado Split'
    },
    tipo: 'Preventiva',
    status: 'Concluída',
    prioridade: 'Normal',
    dataInicio: '2024-01-15',
    dataPrevista: '2024-01-15',
    tecnico: 'Roberto Clima',
    empresa: 'ClimaTech',
    valor: 200.00,
    descricao: 'Manutenção preventiva semestral'
  }
];

export default function Manutencoes() {
  const [searchTerm, setSearchTerm] = useState('');
  const [manutencoes] = useState(mockManutencoes);

  const filteredManutencoes = manutencoes.filter(manutencao =>
    manutencao.patrimonio.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
    manutencao.patrimonio.codigo.toLowerCase().includes(searchTerm.toLowerCase()) ||
    manutencao.tecnico.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Agendada': return 'bg-blue-100 text-blue-800';
      case 'Em Andamento': return 'bg-yellow-100 text-yellow-800';
      case 'Concluída': return 'bg-green-100 text-green-800';
      case 'Cancelada': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPrioridadeColor = (prioridade: string) => {
    switch (prioridade) {
      case 'Crítica': return 'bg-red-100 text-red-800';
      case 'Alta': return 'bg-orange-100 text-orange-800';
      case 'Normal': return 'bg-blue-100 text-blue-800';
      case 'Baixa': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getTipoIcon = (tipo: string) => {
    switch (tipo) {
      case 'Preventiva': return <CheckCircle className="h-4 w-4" />;
      case 'Corretiva': return <AlertTriangle className="h-4 w-4" />;
      case 'Preditiva': return <Clock className="h-4 w-4" />;
      default: return <Wrench className="h-4 w-4" />;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Concluída': return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'Em Andamento': return <Clock className="h-4 w-4 text-yellow-600" />;
      default: return <Calendar className="h-4 w-4 text-blue-600" />;
    }
  };

  return (
    <div className="p-4 space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Manutenções</h2>
        <Button className="gap-2">
          <Plus className="h-4 w-4" />
          Nova
        </Button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
        <Input
          placeholder="Buscar manutenção..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10"
        />
      </div>

      <div className="grid gap-4">
        {filteredManutencoes.map((manutencao) => (
          <Card key={manutencao.id} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <CardTitle className="text-lg flex items-center gap-2">
                    {getTipoIcon(manutencao.tipo)}
                    {manutencao.patrimonio.nome}
                  </CardTitle>
                  <p className="text-sm text-gray-500 mt-1">
                    {manutencao.patrimonio.codigo} • {manutencao.tipo}
                  </p>
                </div>
                <div className="flex flex-col gap-1">
                  <Badge className={getStatusColor(manutencao.status)}>
                    {manutencao.status}
                  </Badge>
                  <Badge className={getPrioridadeColor(manutencao.prioridade)}>
                    {manutencao.prioridade}
                  </Badge>
                </div>
              </div>
            </CardHeader>
            
            <CardContent className="space-y-4">
              <p className="text-sm text-gray-700">{manutencao.descricao}</p>

              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="flex items-center gap-2 text-gray-600">
                  <Calendar className="h-4 w-4" />
                  <div>
                    <p className="text-xs">Início</p>
                    <p className="font-medium">
                      {new Date(manutencao.dataInicio).toLocaleDateString('pt-BR')}
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center gap-2 text-gray-600">
                  <Calendar className="h-4 w-4" />
                  <div>
                    <p className="text-xs">Previsão</p>
                    <p className="font-medium">
                      {new Date(manutencao.dataPrevista).toLocaleDateString('pt-BR')}
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 text-sm text-gray-600">
                <User className="h-4 w-4" />
                <span>{manutencao.tecnico} • {manutencao.empresa}</span>
              </div>

              <div className="flex items-center gap-2 text-sm">
                <DollarSign className="h-4 w-4 text-green-600" />
                <span className="font-medium text-green-600">
                  R$ {manutencao.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </span>
              </div>

              <div className="flex gap-2 pt-2">
                <Button variant="outline" size="sm" className="flex-1 gap-2">
                  {getStatusIcon(manutencao.status)}
                  Ver Detalhes
                </Button>
                {manutencao.status !== 'Concluída' && (
                  <Button size="sm" className="flex-1">
                    Atualizar
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredManutencoes.length === 0 && (
        <div className="text-center py-12">
          <Wrench className="h-12 w-12 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            Nenhuma manutenção encontrada
          </h3>
          <p className="text-gray-500">
            Tente ajustar os termos de busca
          </p>
        </div>
      )}
    </div>
  );
}
