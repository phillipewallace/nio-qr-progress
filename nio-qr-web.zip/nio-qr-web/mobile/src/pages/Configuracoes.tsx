
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { 
  Bell, 
  Vibrate, 
  Download, 
  Trash2, 
  Info,
  Shield,
  Smartphone,
  Database
} from 'lucide-react';
import { useDevice } from '../contexts/DeviceContext';
import { toast } from '@/hooks/use-toast';

export default function Configuracoes() {
  const { deviceInfo, triggerHaptic, isNativeApp } = useDevice();
  const [notifications, setNotifications] = useState(true);
  const [haptics, setHaptics] = useState(true);
  const [autoSync, setAutoSync] = useState(true);

  const handleToggle = (type: 'notifications' | 'haptics' | 'autoSync', value: boolean) => {
    triggerHaptic();
    
    switch (type) {
      case 'notifications':
        setNotifications(value);
        break;
      case 'haptics':
        setHaptics(value);
        break;
      case 'autoSync':
        setAutoSync(value);
        break;
    }
    
    toast({
      title: 'Configuração atualizada',
      description: 'Suas preferências foram salvas.',
    });
  };

  const clearCache = () => {
    triggerHaptic();
    toast({
      title: 'Cache limpo',
      description: 'Dados temporários foram removidos.',
    });
  };

  const forceSync = () => {
    triggerHaptic();
    toast({
      title: 'Sincronização iniciada',
      description: 'Atualizando dados com o servidor...',
    });
  };

  return (
    <div className="p-4 space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-1">Configurações</h2>
        <p className="text-gray-600">Personalize seu aplicativo</p>
      </div>

      {/* Notificações */}
      <Card className="mobile-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="h-5 w-5 text-blue-600" />
            Notificações
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Notificações Push</p>
              <p className="text-sm text-gray-600">Receber alertas do sistema</p>
            </div>
            <Switch
              checked={notifications}
              onCheckedChange={(value) => handleToggle('notifications', value)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Experiência */}
      <Card className="mobile-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Smartphone className="h-5 w-5 text-blue-600" />
            Experiência
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Vibração</p>
              <p className="text-sm text-gray-600">Feedback tátil ao tocar</p>
            </div>
            <Switch
              checked={haptics}
              onCheckedChange={(value) => handleToggle('haptics', value)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Dados */}
      <Card className="mobile-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5 text-blue-600" />
            Dados e Sincronização
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Sincronização Automática</p>
              <p className="text-sm text-gray-600">Atualizar dados automaticamente</p>
            </div>
            <Switch
              checked={autoSync}
              onCheckedChange={(value) => handleToggle('autoSync', value)}
            />
          </div>
          
          <div className="pt-2 space-y-2">
            <Button
              onClick={forceSync}
              className="w-full mobile-button"
              variant="outline"
            >
              <Download className="h-4 w-4 mr-2" />
              Sincronizar Agora
            </Button>
            
            <Button
              onClick={clearCache}
              className="w-full mobile-button"
              variant="outline"
            >
              <Trash2 className="h-4 w-4 mr-2" />
              Limpar Cache
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Informações do Dispositivo */}
      <Card className="mobile-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Info className="h-5 w-5 text-blue-600" />
            Informações do Aplicativo
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex justify-between">
            <span className="text-gray-600">Versão do App</span>
            <span className="font-medium">1.0.0</span>
          </div>
          
          {deviceInfo && (
            <>
              <div className="flex justify-between">
                <span className="text-gray-600">Plataforma</span>
                <span className="font-medium">{deviceInfo.platform}</span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-gray-600">Modelo</span>
                <span className="font-medium">{deviceInfo.model}</span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-gray-600">Sistema</span>
                <span className="font-medium">{deviceInfo.operatingSystem} {deviceInfo.osVersion}</span>
              </div>
            </>
          )}
          
          <div className="flex justify-between">
            <span className="text-gray-600">Modo</span>
            <span className="font-medium">{isNativeApp ? 'App Nativo' : 'Web App'}</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
