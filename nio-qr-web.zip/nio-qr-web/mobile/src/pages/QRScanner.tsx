
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { QrCode, Camera, FileText, ArrowLeft, Flashlight, FlashlightOff } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

export default function QRScanner() {
  const [isScanning, setIsScanning] = useState(false);
  const [scannedData, setScannedData] = useState<string | null>(null);
  const [flashOn, setFlashOn] = useState(false);
  const navigate = useNavigate();

  const handleScan = async () => {
    try {
      setIsScanning(true);
      
      // Simular escaneamento do QR Code
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const simulatedPatrimonioId = 'PAT-' + Math.floor(Math.random() * 1000).toString().padStart(3, '0');
      setScannedData(simulatedPatrimonioId);
      
      toast({
        title: 'QR Code detectado!',
        description: `Item encontrado: ${simulatedPatrimonioId}`,
      });

      setTimeout(() => {
        navigate(`/patrimonio/${simulatedPatrimonioId}`);
      }, 1500);

    } catch (error) {
      console.error('Erro ao escanear:', error);
      toast({
        title: 'Erro ao escanear',
        description: 'Não foi possível escanear o QR Code.',
        variant: 'destructive',
      });
    } finally {
      setIsScanning(false);
    }
  };

  const toggleFlash = () => {
    setFlashOn(!flashOn);
    toast({
      title: flashOn ? 'Flash desligado' : 'Flash ligado',
      description: `Flash da câmera ${flashOn ? 'desativado' : 'ativado'}.`,
    });
  };

  return (
    <div className="p-4 space-y-6 animate-fade-in min-h-screen bg-gray-50">
      <div className="flex items-center gap-4 mb-6">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate(-1)}
          className="shrink-0"
        >
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Scanner QR Code</h1>
          <p className="text-gray-600">Escaneie códigos dos patrimônios</p>
        </div>
      </div>

      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-center justify-center">
            <Camera className="h-5 w-5 text-blue-600" />
            Câmera do Scanner
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-center">
            <div className="relative w-80 h-80 mx-auto border-4 border-dashed border-blue-300 rounded-2xl flex items-center justify-center mb-6 bg-gradient-to-br from-blue-50 to-indigo-50">
              {isScanning ? (
                <div className="text-center">
                  <div className="relative">
                    <div className="animate-spin rounded-full h-16 w-16 border-4 border-blue-600 border-t-transparent mx-auto mb-4"></div>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <QrCode className="h-8 w-8 text-blue-600" />
                    </div>
                  </div>
                  <p className="text-blue-700 font-medium">Escaneando...</p>
                  <p className="text-sm text-gray-500 mt-1">Mantenha o código QR centralizado</p>
                </div>
              ) : (
                <div className="text-center">
                  <div className="bg-white rounded-full p-4 mb-4 shadow-lg">
                    <QrCode className="h-16 w-16 text-blue-500 mx-auto" />
                  </div>
                  <p className="text-gray-700 font-medium">Posicione o QR Code aqui</p>
                  <p className="text-sm text-gray-500 mt-1">Centralize o código na câmera</p>
                </div>
              )}
              
              {/* Scanner frame overlay */}
              <div className="absolute inset-8 border-2 border-blue-500 rounded-lg">
                <div className="absolute top-0 left-0 w-6 h-6 border-t-4 border-l-4 border-blue-500 rounded-tl-lg"></div>
                <div className="absolute top-0 right-0 w-6 h-6 border-t-4 border-r-4 border-blue-500 rounded-tr-lg"></div>
                <div className="absolute bottom-0 left-0 w-6 h-6 border-b-4 border-l-4 border-blue-500 rounded-bl-lg"></div>
                <div className="absolute bottom-0 right-0 w-6 h-6 border-b-4 border-r-4 border-blue-500 rounded-br-lg"></div>
              </div>
            </div>

            <div className="flex gap-3 justify-center">
              <Button 
                onClick={handleScan} 
                disabled={isScanning}
                className="flex-1 max-w-sm h-12 text-lg font-semibold bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
              >
                {isScanning ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    Escaneando...
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <Camera className="h-5 w-5" />
                    Iniciar Scanner
                  </div>
                )}
              </Button>
              
              <Button
                variant="outline"
                size="icon"
                onClick={toggleFlash}
                className="h-12 w-12 border-2"
              >
                {flashOn ? (
                  <FlashlightOff className="h-5 w-5" />
                ) : (
                  <Flashlight className="h-5 w-5" />
                )}
              </Button>
            </div>
          </div>

          {scannedData && (
            <div className="mt-6 p-4 bg-green-50 border-2 border-green-200 rounded-xl">
              <div className="flex items-center gap-3">
                <div className="bg-green-500 rounded-full p-2">
                  <FileText className="h-5 w-5 text-white" />
                </div>
                <div>
                  <p className="font-semibold text-green-800">
                    Código Detectado!
                  </p>
                  <p className="text-green-700 font-mono text-lg">
                    {scannedData}
                  </p>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle className="text-lg">Instruções de Uso</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 gap-4">
            <div className="flex items-start gap-3">
              <div className="bg-blue-100 rounded-full p-2 mt-0.5">
                <span className="text-blue-600 font-bold text-sm">1</span>
              </div>
              <div>
                <p className="font-medium text-gray-900">Posicione o código</p>
                <p className="text-sm text-gray-600">Centralize o QR code dentro da área de escaneamento</p>
              </div>
            </div>
            
            <div className="flex items-start gap-3">
              <div className="bg-blue-100 rounded-full p-2 mt-0.5">
                <span className="text-blue-600 font-bold text-sm">2</span>
              </div>
              <div>
                <p className="font-medium text-gray-900">Mantenha estável</p>
                <p className="text-sm text-gray-600">Evite mover o dispositivo durante o escaneamento</p>
              </div>
            </div>
            
            <div className="flex items-start gap-3">
              <div className="bg-blue-100 rounded-full p-2 mt-0.5">
                <span className="text-blue-600 font-bold text-sm">3</span>
              </div>
              <div>
                <p className="font-medium text-gray-900">Boa iluminação</p>
                <p className="text-sm text-gray-600">Use o flash se necessário para melhor leitura</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
