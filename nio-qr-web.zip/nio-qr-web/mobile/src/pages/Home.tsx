
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Package, QrCode, Plus, MapPin, Wrench, TrendingUp } from 'lucide-react';

export default function Home() {
  const navigate = useNavigate();

  const stats = [
    { title: 'Total de Itens', value: '1,234', icon: Package, color: 'text-blue-600' },
    { title: 'Ativos', value: '1,180', icon: TrendingUp, color: 'text-green-600' },
    { title: 'Manutenção', value: '23', icon: Wrench, color: 'text-yellow-600' },
    { title: 'Localizações', value: '45', icon: MapPin, color: 'text-purple-600' },
  ];

  const quickActions = [
    {
      title: 'Adicionar Item',
      description: 'Cadastrar novo patrimônio',
      icon: Plus,
      action: () => navigate('/patrimonio/novo'),
      color: 'bg-green-500'
    },
    {
      title: 'Escanear QR Code',
      description: 'Ler código QR do item',
      icon: QrCode,
      action: () => navigate('/scanner'),
      color: 'bg-blue-500'
    },
    {
      title: 'Ver Patrimônios',
      description: 'Lista completa de itens',
      icon: Package,
      action: () => navigate('/patrimonio'),
      color: 'bg-purple-500'
    },
  ];

  return (
    <div className="p-4 space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-1">Dashboard</h2>
        <p className="text-gray-600">Visão geral do patrimônio</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-4">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">{stat.title}</p>
                    <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                  </div>
                  <Icon className={`h-8 w-8 ${stat.color}`} />
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Quick Actions */}
      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Ações Rápidas</h3>
        <div className="space-y-3">
          {quickActions.map((action, index) => {
            const Icon = action.icon;
            return (
              <Card key={index} className="cursor-pointer" onClick={action.action}>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-4">
                    <div className={`p-3 rounded-full ${action.color}`}>
                      <Icon className="h-6 w-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-900">{action.title}</h4>
                      <p className="text-sm text-gray-600">{action.description}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}
