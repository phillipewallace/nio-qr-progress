
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  User, 
  Mail, 
  Shield, 
  Settings, 
  LogOut,
  Phone,
  Calendar,
  Award
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useDevice } from '../contexts/DeviceContext';
import { useNavigate } from 'react-router-dom';
import { toast } from '@/hooks/use-toast';

export default function Perfil() {
  const { user, logout } = useAuth();
  const { triggerHaptic } = useDevice();
  const navigate = useNavigate();

  const handleLogout = async () => {
    triggerHaptic();
    try {
      await logout();
      toast({
        title: 'Logout realizado',
        description: 'Você foi desconectado com sucesso.',
      });
      navigate('/login');
    } catch (error) {
      toast({
        title: 'Erro',
        description: 'Erro ao fazer logout.',
        variant: 'destructive',
      });
    }
  };

  const handleConfigPress = () => {
    triggerHaptic();
    navigate('/configuracoes');
  };

  const getNivelColor = (nivel: string) => {
    switch (nivel?.toLowerCase()) {
      case 'admin': return 'bg-red-100 text-red-800';
      case 'gestor': return 'bg-blue-100 text-blue-800';
      case 'usuario': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="p-4 space-y-6">
      {/* Header do Perfil */}
      <Card className="mobile-card">
        <CardContent className="p-6 text-center">
          <div className="bg-blue-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
            <User className="h-10 w-10 text-blue-600" />
          </div>
          <h2 className="text-xl font-bold text-gray-900 mb-1">
            {user?.nome || 'Usuário'}
          </h2>
          <p className="text-gray-600 mb-3">{user?.email}</p>
          <Badge className={getNivelColor(user?.nivel || '')}>
            {user?.nivel?.toUpperCase() || 'USUÁRIO'}
          </Badge>
        </CardContent>
      </Card>

      {/* Informações do Usuário */}
      <Card className="mobile-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Award className="h-5 w-5 text-blue-600" />
            Informações do Perfil
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-3 py-2">
            <Mail className="h-5 w-5 text-gray-400" />
            <div>
              <p className="text-sm text-gray-500">Email</p>
              <p className="font-medium">{user?.email || 'Não informado'}</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3 py-2">
            <Shield className="h-5 w-5 text-gray-400" />
            <div>
              <p className="text-sm text-gray-500">Nível de Acesso</p>
              <p className="font-medium">{user?.nivel || 'Usuário'}</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3 py-2">
            <Calendar className="h-5 w-5 text-gray-400" />
            <div>
              <p className="text-sm text-gray-500">Último Acesso</p>
              <p className="font-medium">Hoje, {new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Estatísticas Rápidas */}
      <div className="grid grid-cols-2 gap-4">
        <Card className="mobile-card">
          <CardContent className="p-4 text-center">
            <Package className="h-8 w-8 text-blue-600 mx-auto mb-2" />
            <p className="text-2xl font-bold text-gray-900">25</p>
            <p className="text-sm text-gray-600">Itens Verificados</p>
          </CardContent>
        </Card>
        
        <Card className="mobile-card">
          <CardContent className="p-4 text-center">
            <QrCode className="h-8 w-8 text-green-600 mx-auto mb-2" />
            <p className="text-2xl font-bold text-gray-900">12</p>
            <p className="text-sm text-gray-600">QR Codes Lidos</p>
          </CardContent>
        </Card>
      </div>

      {/* Ações */}
      <div className="space-y-3">
        <Button
          onClick={handleConfigPress}
          className="w-full mobile-button justify-start"
          variant="outline"
        >
          <Settings className="h-5 w-5 mr-3" />
          Configurações
        </Button>
        
        <Button
          onClick={handleLogout}
          className="w-full mobile-button justify-start"
          variant="destructive"
        >
          <LogOut className="h-5 w-5 mr-3" />
          Sair do App
        </Button>
      </div>
    </div>
  );
}
