
import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Toaster } from '@/components/ui/sonner';
import { StatusBar, Style } from '@capacitor/status-bar';
import { Keyboard } from '@capacitor/keyboard';
import { Device } from '@capacitor/device';
import { App as CapacitorApp } from '@capacitor/app';
import Layout from './components/Layout';
import Home from './pages/Home';
import PatrimonioList from './pages/PatrimonioList';
import PatrimonioForm from './pages/PatrimonioForm';
import PatrimonioDetails from './pages/PatrimonioDetails';
import QRScanner from './pages/QRScanner';
import Localizacoes from './pages/Localizacoes';
import Manutencoes from './pages/Manutencoes';
import MobileLogin from './pages/MobileLogin'; // Nova tela de login mobile
import Perfil from './pages/Perfil';
import Configuracoes from './pages/Configuracoes';
import { AuthProvider } from './contexts/AuthContext';
import { DeviceProvider } from './contexts/DeviceContext';
import './styles/mobile.css';

function App() {
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    const initializeApp = async () => {
      try {
        // Configurar StatusBar para Android
        await StatusBar.setStyle({ style: Style.Light });
        await StatusBar.setBackgroundColor({ color: '#2563eb' });
        
        // Configurar teclado
        Keyboard.addListener('keyboardWillShow', () => {
          document.body.classList.add('keyboard-is-open');
        });
        
        Keyboard.addListener('keyboardWillHide', () => {
          document.body.classList.remove('keyboard-is-open');
        });

        // Listener para back button no Android
        CapacitorApp.addListener('backButton', ({ canGoBack }) => {
          if (!canGoBack) {
            CapacitorApp.exitApp();
          } else {
            window.history.back();
          }
        });

        setIsReady(true);
      } catch (error) {
        console.error('Erro ao inicializar app:', error);
        setIsReady(true); // Continue mesmo com erro
      }
    };

    initializeApp();
  }, []);

  if (!isReady) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-blue-600 to-purple-800">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white mx-auto mb-4"></div>
          <p className="text-white font-medium">Carregando PatrimônioTech Mobile...</p>
        </div>
      </div>
    );
  }

  return (
    <DeviceProvider>
      <AuthProvider>
        <Router>
          <div className="mobile-app">
            <Routes>
              <Route path="/login" element={<MobileLogin />} />
              <Route path="/" element={<Layout />}>
                <Route index element={<Home />} />
                <Route path="patrimonio" element={<PatrimonioList />} />
                <Route path="patrimonio/novo" element={<PatrimonioForm />} />
                <Route path="patrimonio/:id" element={<PatrimonioDetails />} />
                <Route path="scanner" element={<QRScanner />} />
                <Route path="localizacoes" element={<Localizacoes />} />
                <Route path="manutencoes" element={<Manutencoes />} />
                <Route path="perfil" element={<Perfil />} />
                <Route path="configuracoes" element={<Configuracoes />} />
              </Route>
            </Routes>
            <Toaster 
              position="bottom-center"
              toastOptions={{
                duration: 3000,
                style: {
                  marginBottom: '80px'
                }
              }}
            />
          </div>
        </Router>
      </AuthProvider>
    </DeviceProvider>
  );
}

export default App;
