
import React, { createContext, useContext, useState, useEffect } from 'react';
import { Preferences } from '@capacitor/preferences';

interface User {
  id: string;
  nome: string;
  email: string;
  nivel: string;
}

interface AuthContextType {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const API_BASE_URL = 'http://localhost:3001/api';

  useEffect(() => {
    const loadStoredAuth = async () => {
      try {
        const storedToken = await Preferences.get({ key: 'auth_token' });
        const storedUser = await Preferences.get({ key: 'auth_user' });
        
        if (storedToken.value && storedUser.value) {
          setToken(storedToken.value);
          setUser(JSON.parse(storedUser.value));
        }
      } catch (error) {
        console.error('Erro ao carregar dados de autenticação:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadStoredAuth();
  }, []);

  const login = async (email: string, password: string) => {
    try {
      console.log('📱 [MOBILE AUTH] Tentando login:', email);
      
      const response = await fetch(`${API_BASE_URL}/auth/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ usuario: email, senha: password }),
      });

      console.log('📱 [MOBILE AUTH] Response status:', response.status);

      if (!response.ok) {
        throw new Error('Credenciais inválidas');
      }

      const data = await response.json();
      console.log('📱 [MOBILE AUTH] Login success:', data.usuario?.nome);
      
      setToken(data.token);
      setUser(data.usuario);

      // Salvar no Capacitor Preferences
      await Preferences.set({ key: 'auth_token', value: data.token });
      await Preferences.set({ key: 'auth_user', value: JSON.stringify(data.usuario) });

    } catch (error) {
      console.error('❌ [MOBILE AUTH] Erro no login:', error);
      throw error;
    }
  };

  const logout = async () => {
    try {
      setUser(null);
      setToken(null);
      
      await Preferences.remove({ key: 'auth_token' });
      await Preferences.remove({ key: 'auth_user' });
    } catch (error) {
      console.error('Erro no logout:', error);
    }
  };

  return (
    <AuthContext.Provider 
      value={{
        user,
        token,
        isAuthenticated: !!user && !!token,
        isLoading,
        login,
        logout
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
