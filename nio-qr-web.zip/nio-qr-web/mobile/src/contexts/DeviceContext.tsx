
import React, { createContext, useContext, useEffect, useState } from 'react';
import { Device, DeviceInfo } from '@capacitor/device';
import { Network, ConnectionStatus } from '@capacitor/network';
import { Haptics, ImpactStyle } from '@capacitor/haptics';

interface DeviceContextType {
  deviceInfo: DeviceInfo | null;
  isOnline: boolean;
  triggerHaptic: (style?: ImpactStyle) => void;
  isNativeApp: boolean;
}

const DeviceContext = createContext<DeviceContextType | undefined>(undefined);

export const useDevice = () => {
  const context = useContext(DeviceContext);
  if (!context) {
    throw new Error('useDevice must be used within a DeviceProvider');
  }
  return context;
};

export const DeviceProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [deviceInfo, setDeviceInfo] = useState<DeviceInfo | null>(null);
  const [isOnline, setIsOnline] = useState(true);

  const isNativeApp = window.location.protocol === 'capacitor:' || window.location.hostname === 'localhost';

  useEffect(() => {
    const initDevice = async () => {
      try {
        const info = await Device.getInfo();
        setDeviceInfo(info);

        const status = await Network.getStatus();
        setIsOnline(status.connected);

        // Listen for network changes
        Network.addListener('networkStatusChange', status => {
          setIsOnline(status.connected);
        });

      } catch (error) {
        console.warn('Device capabilities not available:', error);
      }
    };

    initDevice();
  }, []);

  const triggerHaptic = async (style: ImpactStyle = ImpactStyle.Light) => {
    try {
      if (isNativeApp) {
        await Haptics.impact({ style });
      } else {
        // Fallback para web
        if (navigator.vibrate) {
          navigator.vibrate(50);
        }
      }
    } catch (error) {
      console.warn('Haptics not supported:', error);
    }
  };

  return (
    <DeviceContext.Provider 
      value={{
        deviceInfo,
        isOnline,
        triggerHaptic,
        isNativeApp
      }}
    >
      {children}
    </DeviceContext.Provider>
  );
};
