
import React from 'react';
import { Bell, User, Wifi, WifiOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '../contexts/AuthContext';
import { useDevice } from '../contexts/DeviceContext';
import { useNavigate } from 'react-router-dom';

export default function Header() {
  const { user } = useAuth();
  const { isOnline, triggerHaptic } = useDevice();
  const navigate = useNavigate();

  const handleNotificationPress = () => {
    triggerHaptic();
    // Implementar notificações
  };

  const handleProfilePress = () => {
    triggerHaptic();
    navigate('/perfil');
  };

  return (
    <header className="bg-blue-600 text-white px-4 py-3 flex items-center justify-between shadow-lg">
      <div className="flex items-center space-x-3">
        <div className="bg-white bg-opacity-20 p-2 rounded-full">
          <div className="w-6 h-6 bg-white rounded-sm flex items-center justify-center">
            <span className="text-blue-600 font-bold text-sm">P</span>
          </div>
        </div>
        <div>
          <h1 className="text-lg font-bold">PatrimônioTech</h1>
          <p className="text-blue-100 text-xs">
            Olá, {user?.nome?.split(' ')[0] || 'Usuário'}
          </p>
        </div>
      </div>
      
      <div className="flex items-center space-x-2">
        {/* Indicador de conectividade */}
        <div className="flex items-center">
          {isOnline ? (
            <Wifi className="h-4 w-4 text-green-300" />
          ) : (
            <WifiOff className="h-4 w-4 text-red-300" />
          )}
        </div>

        {/* Notificações */}
        <Button 
          variant="ghost" 
          size="icon" 
          className="h-8 w-8 text-white hover:bg-white hover:bg-opacity-20 relative mobile-button"
          onClick={handleNotificationPress}
        >
          <Bell className="h-4 w-4" />
          <Badge className="absolute -top-1 -right-1 h-4 w-4 p-0 bg-red-500 text-white text-xs">
            3
          </Badge>
        </Button>

        {/* Perfil */}
        <Button 
          variant="ghost" 
          size="icon" 
          className="h-8 w-8 text-white hover:bg-white hover:bg-opacity-20 mobile-button"
          onClick={handleProfilePress}
        >
          <User className="h-4 w-4" />
        </Button>
      </div>
    </header>
  );
}
