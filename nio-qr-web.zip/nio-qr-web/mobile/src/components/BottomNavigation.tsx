
import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Home, Package, QrCode, MapPin, Wrench } from 'lucide-react';
import { useDevice } from '../contexts/DeviceContext';

const navigationItems = [
  { id: 'home', label: 'Início', icon: Home, path: '/' },
  { id: 'patrimonio', label: 'Itens', icon: Package, path: '/patrimonio' },
  { id: 'scanner', label: 'Scanner', icon: QrCode, path: '/scanner' },
  { id: 'localizacoes', label: 'Locais', icon: MapPin, path: '/localizacoes' },
  { id: 'manutencoes', label: 'Manutenção', icon: Wrench, path: '/manutencoes' },
];

export default function BottomNavigation() {
  const location = useLocation();
  const navigate = useNavigate();
  const { triggerHaptic } = useDevice();

  const handleNavigation = (path: string) => {
    triggerHaptic();
    navigate(path);
  };

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 safe-area-bottom bottom-nav">
      <div className="flex">
        {navigationItems.map((item) => {
          const isActive = location.pathname === item.path;
          const Icon = item.icon;
          
          return (
            <button
              key={item.id}
              onClick={() => handleNavigation(item.path)}
              className={`flex-1 py-2 px-1 flex flex-col items-center justify-center min-h-[64px] transition-all duration-200 touch-action-manipulation ${
                isActive
                  ? 'text-blue-600 bg-blue-50'
                  : 'text-gray-600'
              }`}
            >
              <div className={`p-1 rounded-lg transition-all duration-200 ${
                isActive ? 'bg-blue-100' : ''
              }`}>
                <Icon className={`h-5 w-5 ${isActive ? 'text-blue-600' : 'text-gray-600'}`} />
              </div>
              <span className={`text-xs mt-1 font-medium ${
                isActive ? 'text-blue-600' : 'text-gray-600'
              }`}>
                {item.label}
              </span>
              {isActive && (
                <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-8 h-0.5 bg-blue-600 rounded-full"></div>
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
