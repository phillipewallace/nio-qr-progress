
import { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Package, Eye, EyeOff, Shield, Users, BarChart3 } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';

export default function Login() {
  const navigate = useNavigate();
  const location = useLocation();
  const { login, isAuthenticated } = useAuth();
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    usuario: '',
    senha: ''
  });

  const from = location.state?.from?.pathname || '/';

  console.log('\n🔐 [LOGIN] === COMPONENTE LOGIN CARREGADO ===');
  console.log(`🔍 [LOGIN] Rota anterior: ${from}`);
  console.log(`👤 [LOGIN] Já autenticado: ${isAuthenticated}`);

  useEffect(() => {
    if (isAuthenticated) {
      console.log('✅ [LOGIN] Usuário já autenticado, redirecionando...');
      console.log(`🔄 [LOGIN] Redirecionando para: ${from}`);
      navigate(from, { replace: true });
    }
  }, [isAuthenticated, navigate, from]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    console.log('\n📝 [LOGIN] === SUBMETENDO FORMULÁRIO ===');
    console.log(`👤 [LOGIN] Usuário: ${formData.usuario}`);
    console.log(`🔒 [LOGIN] Senha: ${'*'.repeat(formData.senha.length)}`);
    
    if (!formData.usuario || !formData.senha) {
      console.log('❌ [LOGIN] Campos obrigatórios em falta');
      toast({
        title: 'Campos obrigatórios',
        description: 'Preencha usuário e senha.',
        variant: 'destructive',
      });
      return;
    }

    setLoading(true);
    console.log('⏳ [LOGIN] Iniciando processo de login...');
    
    try {
      const success = await login(formData.usuario, formData.senha);
      
      if (success) {
        console.log('✅ [LOGIN] Login realizado com sucesso!');
        toast({
          title: 'Login realizado!',
          description: 'Bem-vindo ao PatrimônioTech.',
        });
        
        console.log(`🔄 [LOGIN] Redirecionando para: ${from}`);
        navigate(from, { replace: true });
      } else {
        console.log('❌ [LOGIN] Falha no login');
      }
    } catch (error) {
      console.error('❌ [LOGIN] Erro no processo de login:', error);
      toast({
        title: 'Erro no login',
        description: 'Ocorreu um erro durante o login. Tente novamente.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
      console.log('🏁 [LOGIN] Processo de login finalizado');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-indigo-900 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-20 left-20 w-72 h-72 bg-white rounded-full mix-blend-multiply filter blur-xl animate-pulse"></div>
        <div className="absolute top-40 right-20 w-72 h-72 bg-purple-300 rounded-full mix-blend-multiply filter blur-xl animate-pulse" style={{ animationDelay: '2s' }}></div>
        <div className="absolute -bottom-8 left-40 w-72 h-72 bg-pink-300 rounded-full mix-blend-multiply filter blur-xl animate-pulse" style={{ animationDelay: '4s' }}></div>
      </div>

      <div className="w-full max-w-6xl grid grid-cols-1 lg:grid-cols-2 gap-8 items-center relative">
        {/* Left Side - Info */}
        <div className="text-white space-y-8 p-8">
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="bg-white/20 p-3 rounded-xl backdrop-blur-sm">
                <Package className="h-8 w-8 text-white" />
              </div>
              <h1 className="text-4xl font-bold">PatrimônioTech</h1>
            </div>
            <p className="text-xl text-blue-100">
              Sistema completo de gestão patrimonial para sua empresa
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
              <Shield className="h-8 w-8 text-blue-200 mb-3" />
              <h3 className="font-semibold text-lg mb-2">Seguro</h3>
              <p className="text-blue-100 text-sm">Controle total com autenticação robusta</p>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
              <Users className="h-8 w-8 text-blue-200 mb-3" />
              <h3 className="font-semibold text-lg mb-2">Colaborativo</h3>
              <p className="text-blue-100 text-sm">Múltiplos usuários com permissões específicas</p>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
              <BarChart3 className="h-8 w-8 text-blue-200 mb-3" />
              <h3 className="font-semibold text-lg mb-2">Inteligente</h3>
              <p className="text-blue-100 text-sm">Relatórios e dashboards em tempo real</p>
            </div>
          </div>

          <div className="space-y-3">
            <h3 className="text-lg font-semibold">Principais funcionalidades:</h3>
            <ul className="space-y-2 text-blue-100">
              <li className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 bg-blue-300 rounded-full"></div>
                Cadastro e controle de patrimônio
              </li>
              <li className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 bg-blue-300 rounded-full"></div>
                Geração de QR Codes automática
              </li>
              <li className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 bg-blue-300 rounded-full"></div>
                Gestão de manutenções e seguros
              </li>
              <li className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 bg-blue-300 rounded-full"></div>
                Controle de localizações
              </li>
            </ul>
          </div>
        </div>

        {/* Right Side - Login Form */}
        <div className="flex justify-center">
          <Card className="w-full max-w-md shadow-2xl bg-white/95 backdrop-blur-sm border-0">
            <CardHeader className="text-center pb-8">
              <div className="flex justify-center mb-6">
                <div className="bg-gradient-to-br from-blue-600 to-indigo-600 p-4 rounded-2xl shadow-lg">
                  <Package className="h-10 w-10 text-white" />
                </div>
              </div>
              <CardTitle className="text-3xl font-bold text-gray-900 mb-2">
                Fazer Login
              </CardTitle>
              <p className="text-gray-600">
                Entre com suas credenciais para acessar o sistema
              </p>
            </CardHeader>
            
            <CardContent className="space-y-6">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="usuario" className="text-sm font-medium text-gray-700">
                    Usuário
                  </Label>
                  <Input
                    id="usuario"
                    type="text"
                    value={formData.usuario}
                    onChange={(e) => {
                      const value = e.target.value;
                      console.log(`📝 [LOGIN] Campo usuário alterado: ${value}`);
                      setFormData(prev => ({
                        ...prev,
                        usuario: value
                      }));
                    }}
                    placeholder="Digite seu usuário"
                    required
                    className="h-12 text-base border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="senha" className="text-sm font-medium text-gray-700">
                    Senha
                  </Label>
                  <div className="relative">
                    <Input
                      id="senha"
                      type={showPassword ? 'text' : 'password'}
                      value={formData.senha}
                      onChange={(e) => {
                        const value = e.target.value;
                        console.log(`📝 [LOGIN] Campo senha alterado: ${'*'.repeat(value.length)}`);
                        setFormData(prev => ({
                          ...prev,
                          senha: value
                        }));
                      }}
                      placeholder="Digite sua senha"
                      required
                      className="h-12 text-base pr-12 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="absolute right-0 top-0 h-12 px-4 hover:bg-transparent"
                      onClick={() => {
                        console.log(`👁️ [LOGIN] Alternando visibilidade da senha`);
                        setShowPassword(!showPassword);
                      }}
                    >
                      {showPassword ? (
                        <EyeOff className="h-5 w-5 text-gray-400" />
                      ) : (
                        <Eye className="h-5 w-5 text-gray-400" />
                      )}
                    </Button>
                  </div>
                </div>

                <Button
                  type="submit"
                  disabled={loading}
                  className="w-full h-12 text-base font-semibold bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 shadow-lg"
                >
                  {loading ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      Entrando...
                    </div>
                  ) : (
                    'Entrar'
                  )}
                </Button>
              </form>

              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t border-gray-200" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-white px-2 text-gray-500">Acesse o sistema</span>
                </div>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-blue-800 text-center">
                  <strong>Credenciais de teste:</strong><br />
                  Usuário: <code>admin</code> | Senha: <code>admin</code><br />
                  Ou use credenciais do banco de dados
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
