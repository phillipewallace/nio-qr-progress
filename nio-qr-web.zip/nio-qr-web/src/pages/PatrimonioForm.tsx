
import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Calendar } from '@/components/ui/calendar';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { format } from 'date-fns';
import { CalendarIcon, Save, ArrowLeft, Upload, X, Image as ImageIcon } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { useApi } from '@/hooks/useApi';

const patrimonioSchema = z.object({
  nome: z.string().min(1, 'Nome é obrigatório'),
  codigo: z.string().min(1, 'Código é obrigatório'),
  categoria: z.string().min(1, 'Categoria é obrigatória'),
  subcategoria: z.string().optional(),
  descricao: z.string().optional(),
  valor_aquisicao: z.number().min(0, 'Valor deve ser positivo'),
  valor_atual: z.number().min(0, 'Valor deve ser positivo').optional(),
  data_aquisicao: z.date(),
  fornecedor: z.string().optional(),
  garantia: z.string().optional(),
  numero_serie: z.string().optional(),
  status: z.string().min(1, 'Status é obrigatório'),
  foto: z.string().optional(),
  localizacao_setor: z.string().optional(),
  localizacao_sala: z.string().optional(),
  localizacao_bloco: z.string().optional(),
  localizacao_andar: z.string().optional(),
  responsavel: z.string().optional(),
  observacoes: z.string().optional(),
});

type PatrimonioFormData = z.infer<typeof patrimonioSchema>;

// Dados estáticos para os selects
const categorias = [
  { id: 1, nome: 'Informática' },
  { id: 2, nome: 'Móveis' },
  { id: 3, nome: 'Equipamentos' },
  { id: 4, nome: 'Veículos' },
  { id: 5, nome: 'Outros' },
];

const setores = [
  { id: 1, nome: 'Administração' },
  { id: 2, nome: 'Financeiro' },
  { id: 3, nome: 'Recursos Humanos' },
  { id: 4, nome: 'TI' },
  { id: 5, nome: 'Operações' },
];

const fornecedores = [
  { id: 1, nome: 'Dell' },
  { id: 2, nome: 'HP' },
  { id: 3, nome: 'Lenovo' },
  { id: 4, nome: 'Microsoft' },
  { id: 5, nome: 'Outros' },
];

export default function PatrimonioForm() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { get, post, put } = useApi();
  const [loading, setLoading] = useState(false);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const isEditing = Boolean(id);

  const form = useForm<PatrimonioFormData>({
    resolver: zodResolver(patrimonioSchema),
    defaultValues: {
      nome: '',
      codigo: '',
      categoria: '',
      subcategoria: '',
      descricao: '',
      valor_aquisicao: 0,
      valor_atual: 0,
      data_aquisicao: new Date(),
      fornecedor: '',
      garantia: '',
      numero_serie: '',
      status: 'Ativo',
      foto: '',
      localizacao_setor: '',
      localizacao_sala: '',
      localizacao_bloco: '',
      localizacao_andar: '',
      responsavel: '',
      observacoes: '',
    },
  });

  const handlePhotoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        toast({
          title: "Arquivo muito grande",
          description: "A imagem deve ter no máximo 5MB.",
          variant: "destructive",
        });
        return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setPhotoPreview(result);
        form.setValue('foto', result);
      };
      reader.readAsDataURL(file);
    }
  };

  const removePhoto = () => {
    setPhotoPreview(null);
    form.setValue('foto', '');
  };

  useEffect(() => {
    if (isEditing && id) {
      fetchPatrimonio();
    }
  }, [id, isEditing]);

  const fetchPatrimonio = async () => {
    if (!id) return;
    
    try {
      console.log('🔍 [PatrimonioForm] Carregando patrimônio para edição:', id);
      const response = await get(`/patrimonios/${id}`);
      const item = await response.json();
      
      const formData: PatrimonioFormData = {
        nome: item.nome || '',
        codigo: item.codigo || '',
        categoria: item.categoria || '',
        subcategoria: item.subcategoria || '',
        descricao: item.descricao || '',
        valor_aquisicao: item.valor_aquisicao || 0,
        valor_atual: item.valor_atual || 0,
        data_aquisicao: new Date(item.data_aquisicao),
        fornecedor: item.fornecedor || '',
        garantia: item.garantia || '',
        numero_serie: item.numero_serie || '',
        status: item.status || 'Ativo',
        foto: item.foto || '',
        localizacao_setor: item.localizacao_setor || '',
        localizacao_sala: item.localizacao_sala || '',
        localizacao_bloco: item.localizacao_bloco || '',
        localizacao_andar: item.localizacao_andar || '',
        responsavel: item.responsavel || '',
        observacoes: item.observacoes || '',
      };
      
      form.reset(formData);
      
      // Set photo preview if exists
      if (item.foto) {
        setPhotoPreview(item.foto);
      }
      
      console.log('✅ [PatrimonioForm] Patrimônio carregado para edição');
    } catch (error) {
      console.error('❌ [PatrimonioForm] Erro ao carregar patrimônio:', error);
      toast({
        title: "Erro ao carregar",
        description: "Não foi possível carregar os dados do patrimônio.",
        variant: "destructive",
      });
    }
  };

  const onSubmit = async (data: PatrimonioFormData) => {
    setLoading(true);
    try {
      console.log(`${isEditing ? '✏️' : '➕'} [PatrimonioForm] Salvando patrimônio:`, data);
      
      const payload = {
        ...data,
        data_aquisicao: data.data_aquisicao.toISOString().split('T')[0], // Format date
      };

      let response;
      if (isEditing && id) {
        response = await put(`/patrimonios/${id}`, payload);
      } else {
        response = await post('/patrimonios', payload);
      }

      const result = await response.json();
      
      toast({
        title: isEditing ? "Item atualizado!" : "Item cadastrado!",
        description: `${data.nome} foi ${isEditing ? 'atualizado' : 'cadastrado'} com sucesso.`,
      });
      
      console.log(`✅ [PatrimonioForm] Patrimônio ${isEditing ? 'atualizado' : 'cadastrado'}:`, result);
      navigate('/patrimonio');
    } catch (error) {
      console.error(`❌ [PatrimonioForm] Erro ao ${isEditing ? 'atualizar' : 'cadastrar'}:`, error);
      toast({
        title: "Erro ao salvar",
        description: "Não foi possível salvar o item. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center gap-4">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate('/patrimonio')}
        >
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-gray-900">
            {isEditing ? 'Editar Item' : 'Novo Item'}
          </h1>
          <p className="text-gray-600 mt-1">
            {isEditing ? 'Atualize as informações do item' : 'Cadastre um novo item no patrimônio'}
          </p>
        </div>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <Tabs defaultValue="basico" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="basico">Básico</TabsTrigger>
              <TabsTrigger value="foto">Foto</TabsTrigger>
              <TabsTrigger value="financeiro">Financeiro</TabsTrigger>
              <TabsTrigger value="localizacao">Localização</TabsTrigger>
            </TabsList>

            <TabsContent value="basico" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Informações Básicas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="nome"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nome do Item *</FormLabel>
                          <FormControl>
                            <Input placeholder="Ex: Notebook Dell" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="codigo"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Código *</FormLabel>
                          <FormControl>
                            <Input placeholder="Ex: NB001" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="categoria"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Categoria *</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Selecione..." />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {categorias.map((categoria) => (
                                <SelectItem key={categoria.id} value={categoria.nome}>
                                  {categoria.nome}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="subcategoria"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Subcategoria</FormLabel>
                          <FormControl>
                            <Input placeholder="Ex: Notebook, Desktop, Monitor..." {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="numero_serie"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Número de Série</FormLabel>
                          <FormControl>
                            <Input placeholder="Ex: SN123456789" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="status"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Status *</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Selecione..." />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="Ativo">Ativo</SelectItem>
                              <SelectItem value="Inativo">Inativo</SelectItem>
                              <SelectItem value="Manutenção">Manutenção</SelectItem>
                              <SelectItem value="Descartado">Descartado</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="descricao"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Descrição</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Descrição detalhada do item..."
                            className="resize-none"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="responsavel"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Responsável</FormLabel>
                        <FormControl>
                          <Input placeholder="Ex: João Silva" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="foto" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Foto do Patrimônio</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-center">
                    {photoPreview ? (
                      <div className="relative inline-block">
                        <img 
                          src={photoPreview} 
                          alt="Preview" 
                          className="w-64 h-64 object-cover rounded-lg border"
                        />
                        <Button
                          type="button"
                          variant="destructive"
                          size="icon"
                          className="absolute top-2 right-2"
                          onClick={removePhoto}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    ) : (
                      <div className="w-64 h-64 mx-auto border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center">
                        <div className="text-center">
                          <ImageIcon className="h-12 w-12 text-gray-400 mx-auto mb-2" />
                          <p className="text-sm text-gray-500">Nenhuma foto selecionada</p>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="flex justify-center">
                    <label htmlFor="photo-upload">
                      <Button type="button" variant="outline" className="cursor-pointer" asChild>
                        <div>
                          <Upload className="h-4 w-4 mr-2" />
                          Selecionar Foto
                        </div>
                      </Button>
                      <input
                        id="photo-upload"
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={handlePhotoUpload}
                      />
                    </label>
                  </div>

                  <p className="text-sm text-gray-500 text-center">
                    Formatos suportados: JPG, PNG, WebP<br />
                    Tamanho máximo: 5MB
                  </p>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="financeiro" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Dados Financeiros</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="valor_aquisicao"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Valor de Aquisição *</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              step="0.01"
                              placeholder="0.00"
                              {...field}
                              onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="valor_atual"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Valor Atual</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              step="0.01"
                              placeholder="0.00"
                              {...field}
                              onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="data_aquisicao"
                      render={({ field }) => (
                        <FormItem className="flex flex-col">
                          <FormLabel>Data de Aquisição *</FormLabel>
                          <Popover>
                            <PopoverTrigger asChild>
                              <FormControl>
                                <Button
                                  variant="outline"
                                  className="w-full pl-3 text-left font-normal"
                                >
                                  {field.value ? (
                                    format(field.value, "dd/MM/yyyy")
                                  ) : (
                                    <span>Selecione uma data</span>
                                  )}
                                  <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                </Button>
                              </FormControl>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                              <Calendar
                                mode="single"
                                selected={field.value}
                                onSelect={field.onChange}
                                disabled={(date) =>
                                  date > new Date() || date < new Date("1900-01-01")
                                }
                                initialFocus
                              />
                            </PopoverContent>
                          </Popover>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="fornecedor"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Fornecedor</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Selecione..." />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {fornecedores.map((fornecedor) => (
                                <SelectItem key={fornecedor.id} value={fornecedor.nome}>
                                  {fornecedor.nome}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="garantia"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Garantia</FormLabel>
                        <FormControl>
                          <Input placeholder="Ex: 12 meses" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="localizacao" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Localização</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="localizacao_setor"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Setor</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Selecione..." />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {setores.map((setor) => (
                                <SelectItem key={setor.id} value={setor.nome}>
                                  {setor.nome}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="localizacao_sala"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Sala</FormLabel>
                          <FormControl>
                            <Input placeholder="Ex: Sala 101" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="localizacao_bloco"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Bloco</FormLabel>
                          <FormControl>
                            <Input placeholder="Ex: Bloco A" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="localizacao_andar"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Andar</FormLabel>
                          <FormControl>
                            <Input placeholder="Ex: 2º Andar" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="observacoes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Observações</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Observações adicionais sobre o item..."
                            className="resize-none"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          <div className="flex justify-end gap-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => navigate('/patrimonio')}
              disabled={loading}
            >
              Cancelar
            </Button>
            <Button type="submit" disabled={loading} className="gap-2">
              <Save className="h-4 w-4" />
              {loading ? 'Salvando...' : isEditing ? 'Atualizar' : 'Salvar'}
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}
