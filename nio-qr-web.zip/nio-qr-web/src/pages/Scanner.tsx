
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { QrCode, Camera, FileText, ArrowLeft } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

export default function Scanner() {
  const [isScanning, setIsScanning] = useState(false);
  const [scannedData, setScannedData] = useState<string | null>(null);
  const navigate = useNavigate();

  const handleScan = async () => {
    try {
      setIsScanning(true);
      
      // Simular escaneamento do QR Code
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const simulatedPatrimonioId = 'patrimonio-' + Math.floor(Math.random() * 1000);
      setScannedData(simulatedPatrimonioId);
      
      toast({
        title: 'QR Code detectado!',
        description: 'Redirecionando para os detalhes do item...',
      });

      setTimeout(() => {
        navigate(`/patrimonio`);
      }, 1500);

    } catch (error) {
      console.error('Erro ao escanear:', error);
      toast({
        title: 'Erro ao escanear',
        description: 'Não foi possível escanear o QR Code.',
        variant: 'destructive',
      });
    } finally {
      setIsScanning(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center gap-4">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate(-1)}
        >
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Scanner QR Code</h1>
          <p className="text-gray-600 mt-1">Escaneie códigos QR dos patrimônios</p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Camera className="h-5 w-5" />
            Escanear Código
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-center">
            <div className="w-64 h-64 mx-auto border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center mb-4">
              {isScanning ? (
                <div className="text-center">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
                  <p className="text-gray-600">Escaneando...</p>
                </div>
              ) : (
                <div className="text-center">
                  <QrCode className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">Posicione o QR Code aqui</p>
                </div>
              )}
            </div>

            <Button 
              onClick={handleScan} 
              disabled={isScanning}
              className="w-full max-w-md"
              size="lg"
            >
              {isScanning ? 'Escaneando...' : 'Iniciar Escaneamento'}
            </Button>
          </div>

          {scannedData && (
            <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-md">
              <div className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-green-600" />
                <p className="text-green-800">
                  <strong>Código detectado:</strong> {scannedData}
                </p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Instruções</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2 text-sm text-gray-600">
            <li>• Posicione o código QR dentro da área de escaneamento</li>
            <li>• Mantenha o dispositivo estável</li>
            <li>• Certifique-se de ter boa iluminação</li>
            <li>• O redirecionamento será automático após a detecção</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
