
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { 
  Wrench, 
  Plus, 
  Search, 
  MoreHorizontal, 
  Eye,
  Edit,
  Trash2,
  Calendar,
  DollarSign,
  User,
  AlertTriangle,
  CheckCircle,
  Clock
} from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { useApi } from '@/hooks/useApi';
import ManutencaoFormModal from '@/components/modals/ManutencaoFormModal';

interface Manutencao {
  id: string;
  protocolo: string;
  patrimonio_id: string;
  patrimonio_nome: string;
  patrimonio_codigo: string;
  tipo: 'Preventiva' | 'Corretiva' | 'Preditiva';
  status: 'Agendada' | 'Em Andamento' | 'Concluída' | 'Cancelada';
  prioridade: 'Baixa' | 'Normal' | 'Alta' | 'Crítica';
  descricao: string;
  tecnico: string;
  data_agendada: string;
  data_inicio?: string;
  data_fim?: string;
  custo?: number;
  observacoes?: string;
  created_at: string;
}

export default function Manutencao() {
  const [manutencoes, setManutencoes] = useState<Manutencao[]>([]);
  const [filteredManutencoes, setFilteredManutencoes] = useState<Manutencao[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [selectedManutencao, setSelectedManutencao] = useState<Manutencao | null>(null);

  const { get, post, put, delete: del } = useApi();

  useEffect(() => {
    fetchManutencoes();
  }, []);

  useEffect(() => {
    filterManutencoes();
  }, [searchTerm, manutencoes]);

  const fetchManutencoes = async () => {
    console.log('🔧 [Manutencao] Buscando manutenções...');
    try {
      const response = await get('/manutencoes');
      const data = await response.json();
      
      console.log('✅ [Manutencao] Manutenções recebidas:', data);
      setManutencoes(data);
    } catch (error) {
      console.error('❌ [Manutencao] Erro ao buscar manutenções:', error);
      toast({
        title: 'Erro',
        description: 'Erro ao carregar manutenções',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const filterManutencoes = () => {
    if (!searchTerm) {
      setFilteredManutencoes(manutencoes);
      return;
    }

    const filtered = manutencoes.filter(manutencao =>
      manutencao.patrimonio_nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
      manutencao.patrimonio_codigo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      manutencao.protocolo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      manutencao.tecnico.toLowerCase().includes(searchTerm.toLowerCase())
    );

    setFilteredManutencoes(filtered);
  };

  const handleSave = async (data: Omit<Manutencao, 'id' | 'created_at'>) => {
    try {
      if (selectedManutencao) {
        await put(`/manutencoes/${selectedManutencao.id}`, data);
        toast({
          title: 'Sucesso',
          description: 'Manutenção atualizada com sucesso',
        });
      } else {
        await post('/manutencoes', data);
        toast({
          title: 'Sucesso',
          description: 'Manutenção criada com sucesso',
        });
      }
      
      setShowModal(false);
      setSelectedManutencao(null);
      fetchManutencoes();
    } catch (error) {
      console.error('Erro ao salvar manutenção:', error);
      toast({
        title: 'Erro',
        description: 'Erro ao salvar manutenção',
        variant: 'destructive',
      });
    }
  };

  const handleEdit = (manutencao: Manutencao) => {
    setSelectedManutencao(manutencao);
    setShowModal(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Tem certeza que deseja excluir esta manutenção?')) {
      return;
    }

    try {
      await del(`/manutencoes/${id}`);
      toast({
        title: 'Sucesso',
        description: 'Manutenção excluída com sucesso',
      });
      fetchManutencoes();
    } catch (error) {
      console.error('Erro ao excluir manutenção:', error);
      toast({
        title: 'Erro',
        description: 'Erro ao excluir manutenção',
        variant: 'destructive',
      });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Agendada': return 'bg-blue-100 text-blue-800';
      case 'Em Andamento': return 'bg-yellow-100 text-yellow-800';
      case 'Concluída': return 'bg-green-100 text-green-800';
      case 'Cancelada': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPrioridadeColor = (prioridade: string) => {
    switch (prioridade) {
      case 'Crítica': return 'bg-red-100 text-red-800';
      case 'Alta': return 'bg-orange-100 text-orange-800';
      case 'Normal': return 'bg-blue-100 text-blue-800';
      case 'Baixa': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getTipoIcon = (tipo: string) => {
    switch (tipo) {
      case 'Preventiva': return <CheckCircle className="h-4 w-4" />;
      case 'Corretiva': return <AlertTriangle className="h-4 w-4" />;
      case 'Preditiva': return <Clock className="h-4 w-4" />;
      default: return <Wrench className="h-4 w-4" />;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-2">
            <Wrench className="h-8 w-8" />
            Manutenções
          </h1>
          <p className="text-gray-600 mt-1">Gerencie manutenções preventivas e corretivas</p>
        </div>
        <Button onClick={() => setShowModal(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Nova Manutenção
        </Button>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <CardTitle>Lista de Manutenções</CardTitle>
            <div className="relative w-full sm:w-80">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Buscar manutenções..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Protocolo</TableHead>
                <TableHead>Patrimônio</TableHead>
                <TableHead>Tipo</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Prioridade</TableHead>
                <TableHead>Técnico</TableHead>
                <TableHead>Data Agendada</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredManutencoes.map((manutencao) => (
                <TableRow key={manutencao.id}>
                  <TableCell className="font-medium">{manutencao.protocolo}</TableCell>
                  <TableCell>
                    <div>
                      <p className="font-medium">{manutencao.patrimonio_codigo}</p>
                      <p className="text-sm text-gray-500">{manutencao.patrimonio_nome}</p>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      {getTipoIcon(manutencao.tipo)}
                      {manutencao.tipo}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge className={getStatusColor(manutencao.status)}>
                      {manutencao.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge className={getPrioridadeColor(manutencao.prioridade)}>
                      {manutencao.prioridade}
                    </Badge>
                  </TableCell>
                  <TableCell>{manutencao.tecnico}</TableCell>
                  <TableCell>
                    {new Date(manutencao.data_agendada).toLocaleDateString('pt-BR')}
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Ações</DropdownMenuLabel>
                        <DropdownMenuItem>
                          <Eye className="h-4 w-4 mr-2" />
                          Ver Detalhes
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleEdit(manutencao)}>
                          <Edit className="h-4 w-4 mr-2" />
                          Editar
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem 
                          onClick={() => handleDelete(manutencao.id)}
                          className="text-red-600"
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Excluir
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          {filteredManutencoes.length === 0 && (
            <div className="text-center py-8">
              <Wrench className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">
                {searchTerm ? 'Nenhuma manutenção encontrada' : 'Nenhuma manutenção cadastrada'}
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      <ManutencaoFormModal
        manutencao={selectedManutencao}
        open={showModal}
        onOpenChange={(open) => {
          setShowModal(open);
          if (!open) setSelectedManutencao(null);
        }}
        onSave={handleSave}
      />
    </div>
  );
}
