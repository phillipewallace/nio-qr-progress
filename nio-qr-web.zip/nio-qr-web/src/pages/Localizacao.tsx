import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { 
  MapPin, 
  Plus, 
  Search, 
  MoreHorizontal,
  Edit,
  Trash2,
  Building
} from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { useApi } from '@/hooks/useApi';
import LocalizacaoFormModal from '@/components/modals/LocalizacaoFormModal';

interface Localizacao {
  id: string;
  bloco?: string;
  andar?: string;
  setor: string;
  sala: string;
  descricao?: string;
  capacidade?: number;
  responsavel?: string;
  observacoes?: string;
  created_at: string;
  updated_at: string;
}

export default function Localizacao() {
  const [localizacoes, setLocalizacoes] = useState<Localizacao[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [selectedLocalizacao, setSelectedLocalizacao] = useState<Localizacao | null>(null);

  const { get, delete: del } = useApi();

  useEffect(() => {
    fetchLocalizacoes();
  }, []);

  const fetchLocalizacoes = async () => {
    console.log('🏢 [Localizacao] Buscando localizações...');
    try {
      const response = await get('/localizacoes');
      const data = await response.json();
      
      console.log('✅ [Localizacao] Localizações recebidas:', data);
      setLocalizacoes(data);
    } catch (error) {
      console.error('❌ [Localizacao] Erro ao buscar localizações:', error);
      toast({
        title: 'Erro',
        description: 'Erro ao carregar localizações',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (localizacao: Localizacao) => {
    setSelectedLocalizacao(localizacao);
    setShowModal(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Tem certeza que deseja excluir esta localização?')) {
      return;
    }

    try {
      await del(`/localizacoes/${id}`);
      toast({
        title: 'Sucesso',
        description: 'Localização excluída com sucesso',
      });
      fetchLocalizacoes();
    } catch (error) {
      console.error('❌ [Localizacao] Erro ao excluir localização:', error);
      toast({
        title: 'Erro',
        description: 'Erro ao excluir localização',
        variant: 'destructive',
      });
    }
  };

  const filteredLocalizacoes = localizacoes.filter(loc =>
    loc.setor.toLowerCase().includes(searchTerm.toLowerCase()) ||
    loc.sala.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (loc.bloco && loc.bloco.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-2">
            <MapPin className="h-8 w-8" />
            Localizações
          </h1>
          <p className="text-gray-600 mt-1">Gerencie os locais e espaços físicos</p>
        </div>
        <Button onClick={() => {
          setSelectedLocalizacao(null);
          setShowModal(true);
        }}>
          <Plus className="h-4 w-4 mr-2" />
          Nova Localização
        </Button>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <CardTitle>Lista de Localizações</CardTitle>
            <div className="relative w-full sm:w-80">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Buscar localizações..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Setor</TableHead>
                <TableHead>Sala</TableHead>
                <TableHead>Bloco</TableHead>
                <TableHead>Andar</TableHead>
                <TableHead>Responsável</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredLocalizacoes.map((localizacao) => (
                <TableRow key={localizacao.id}>
                  <TableCell className="font-medium">{localizacao.setor}</TableCell>
                  <TableCell>{localizacao.sala}</TableCell>
                  <TableCell>{localizacao.bloco || '-'}</TableCell>
                  <TableCell>{localizacao.andar || '-'}</TableCell>
                  <TableCell>{localizacao.responsavel || '-'}</TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => handleEdit(localizacao)}>
                          <Edit className="h-4 w-4 mr-2" />
                          Editar
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          onClick={() => handleDelete(localizacao.id)}
                          className="text-red-600"
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Excluir
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          {filteredLocalizacoes.length === 0 && (
            <div className="text-center py-8">
              <Building className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">
                {searchTerm ? 'Nenhuma localização encontrada' : 'Nenhuma localização cadastrada'}
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      <LocalizacaoFormModal
        open={showModal}
        onOpenChange={setShowModal}
        localizacao={selectedLocalizacao}
        onSave={fetchLocalizacoes}
      />
    </div>
  );
}
