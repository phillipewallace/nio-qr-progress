import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { Plus, Edit, Eye, X } from 'lucide-react';
import { useDebounce } from '@/hooks/useDebounce';
import { useApi } from '@/hooks/useApi';
import { toast } from '@/hooks/use-toast';
import { CustomPagination } from '@/components/CustomPagination';

interface Patrimonio {
  id: string;
  codigo: string;
  nome: string;
  descricao?: string;
  categoria: string;
  subcategoria?: string;
  responsavel?: string;
  valor_aquisicao: number;
  valor_atual?: number;
  data_aquisicao: string;
  garantia?: string;
  fornecedor?: string;
  numero_serie?: string;
  status: 'Ativo' | 'Inativo' | 'Manutenção' | 'Descartado';
  observacoes?: string;
  foto?: string;
  qr_code?: string;
  localizacao_setor?: string;
  localizacao_sala?: string;
  localizacao_bloco?: string;
  localizacao_andar?: string;
  created_at: string;
  updated_at: string;
}

export default function PatrimonioList() {
  const navigate = useNavigate();
  const { get } = useApi();
  const [patrimonios, setPatrimonios] = useState<Patrimonio[]>([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(10);
  const [total, setTotal] = useState(0);
  const [pages, setPages] = useState(0);
  const [categoriaFilter, setCategoriaFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [search, setSearch] = useState('');
  const debouncedSearch = useDebounce(search, 500);

  useEffect(() => {
    fetchPatrimonios();
  }, [page, limit, debouncedSearch, categoriaFilter, statusFilter]);

  const fetchPatrimonios = async () => {
    setLoading(true);
    try {
      let url = `/patrimonios?page=${page}&limit=${limit}`;
      if (debouncedSearch) url += `&search=${debouncedSearch}`;
      if (categoriaFilter) url += `&categoria=${categoriaFilter}`;
      if (statusFilter) url += `&status=${statusFilter}`;

      console.log('🌐 [PatrimonioList] Fetching patrimonios:', url);
      const response = await get(url);
      const data = await response.json();

      setPatrimonios(data.data);
      setTotal(data.pagination.total);
      setPages(data.pagination.pages);
      console.log('✅ [PatrimonioList] Patrimonios carregados:', data.data.length);
    } catch (error) {
      console.error('❌ [PatrimonioList] Erro ao buscar patrimonios:', error);
      toast({
        title: "Erro ao carregar",
        description: "Não foi possível carregar a lista de patrimônios.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handlePageChange = (newPage: number) => {
    setPage(newPage);
  };

  const handleLimitChange = (newLimit: number) => {
    setLimit(newLimit);
    setPage(1); // Reset para a primeira página ao mudar o limite
  };

  const handleView = (patrimonio: Patrimonio) => {
    console.log('👁️ [PatrimonioList] Visualizando patrimônio:', patrimonio.id);
    navigate(`/patrimonio/${patrimonio.id}`);
  };

  const handleEdit = (patrimonio: Patrimonio) => {
    console.log('✏️ [PatrimonioList] Editando patrimônio:', patrimonio.id);
    navigate(`/patrimonio/${patrimonio.id}/editar`);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Ativo': return 'bg-green-100 text-green-800';
      case 'Inativo': return 'bg-gray-100 text-gray-800';
      case 'Manutenção': return 'bg-yellow-100 text-yellow-800';
      case 'Descartado': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Patrimônios</h1>
          <p className="text-gray-600 mt-1">
            Gerencie seus itens patrimoniais de forma eficiente.
          </p>
        </div>
      </div>

      <div className="flex justify-between items-center">
        <div className="flex items-center space-x-4">
          <Input
            type="search"
            placeholder="Buscar por nome, código ou descrição..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="max-w-md"
          />
          {search && (
            <Button variant="ghost" size="icon" onClick={() => setSearch('')}>
              <X className="h-4 w-4" />
            </Button>
          )}

          <Select value={categoriaFilter} onValueChange={(value) => {
            setCategoriaFilter(value);
            setPage(1);
          }}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filtrar por Categoria" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas as Categorias</SelectItem>
              <SelectItem value="Informática">Informática</SelectItem>
              <SelectItem value="Móveis">Móveis</SelectItem>
              <SelectItem value="Equipamentos">Equipamentos</SelectItem>
              <SelectItem value="Veículos">Veículos</SelectItem>
              <SelectItem value="Outros">Outros</SelectItem>
            </SelectContent>
          </Select>

          <Select value={statusFilter} onValueChange={(value) => {
            setStatusFilter(value);
            setPage(1);
          }}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filtrar por Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os Status</SelectItem>
              <SelectItem value="Ativo">Ativo</SelectItem>
              <SelectItem value="Inativo">Inativo</SelectItem>
              <SelectItem value="Manutenção">Manutenção</SelectItem>
              <SelectItem value="Descartado">Descartado</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Button 
          onClick={() => navigate('/patrimonio/novo')}
          className="gap-2"
        >
          <Plus className="h-4 w-4" />
          Novo Item
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Lista de Patrimônios</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <ScrollArea>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Código
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Nome
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Categoria
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Ações
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {patrimonios.map((patrimonio) => (
                    <tr key={patrimonio.id}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {patrimonio.codigo}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {patrimonio.nome}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {patrimonio.categoria}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        <Badge className={getStatusColor(patrimonio.status)}>
                          {patrimonio.status}
                        </Badge>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <Button variant="ghost" size="icon" onClick={() => handleView(patrimonio)}>
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleEdit(patrimonio)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </ScrollArea>
        </CardContent>
      </Card>

      <CustomPagination
        page={page}
        pages={pages}
        total={total}
        limit={limit}
        setLimit={handleLimitChange}
        onPageChange={handlePageChange}
      />
    </div>
  );
}
