
import Dashboard from './Dashboard';

export default Dashboard;
