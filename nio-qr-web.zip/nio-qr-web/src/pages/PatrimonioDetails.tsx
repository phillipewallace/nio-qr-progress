
import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ArrowLeft, Edit, Trash2, MapPin, DollarSign, Calendar, User, Package, FileText } from 'lucide-react';
import { useApi } from '@/hooks/useApi';
import { toast } from '@/hooks/use-toast';
import { format } from 'date-fns';

interface Patrimonio {
  id: string;
  codigo: string;
  nome: string;
  descricao?: string;
  categoria: string;
  subcategoria?: string;
  responsavel?: string;
  valor_aquisicao: number;
  valor_atual?: number;
  data_aquisicao: string;
  garantia?: string;
  fornecedor?: string;
  numero_serie?: string;
  status: 'Ativo' | 'Inativo' | 'Manutenção' | 'Descartado';
  observacoes?: string;
  foto?: string;
  qr_code?: string;
  localizacao_setor?: string;
  localizacao_sala?: string;
  localizacao_bloco?: string;
  localizacao_andar?: string;
  created_at: string;
  updated_at: string;
}

export default function PatrimonioDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { get, delete: del } = useApi();
  const [patrimonio, setPatrimonio] = useState<Patrimonio | null>(null);
  const [loading, setLoading] = useState(true);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    fetchPatrimonio();
  }, [id]);

  const fetchPatrimonio = async () => {
    if (!id) return;
    
    try {
      console.log('🔍 [PatrimonioDetails] Buscando patrimônio:', id);
      const response = await get(`/patrimonios/${id}`);
      const data = await response.json();
      setPatrimonio(data);
      console.log('✅ [PatrimonioDetails] Patrimônio carregado:', data);
    } catch (error) {
      console.error('❌ [PatrimonioDetails] Erro ao buscar patrimônio:', error);
      toast({
        title: "Erro ao carregar",
        description: "Não foi possível carregar os dados do patrimônio.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!patrimonio || !confirm('Tem certeza que deseja excluir este item?')) return;
    
    setDeleting(true);
    try {
      console.log('🗑️ [PatrimonioDetails] Excluindo patrimônio:', patrimonio.id);
      await del(`/patrimonios/${patrimonio.id}`);
      
      toast({
        title: "Item excluído!",
        description: `${patrimonio.nome} foi excluído com sucesso.`,
      });
      
      navigate('/patrimonio');
    } catch (error) {
      console.error('❌ [PatrimonioDetails] Erro ao excluir:', error);
      toast({
        title: "Erro ao excluir",
        description: "Não foi possível excluir o item. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setDeleting(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Ativo': return 'bg-green-100 text-green-800';
      case 'Inativo': return 'bg-gray-100 text-gray-800';
      case 'Manutenção': return 'bg-yellow-100 text-yellow-800';
      case 'Descartado': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!patrimonio) {
    return (
      <div className="space-y-6 animate-fade-in">
        <div className="flex items-center gap-4">
          <Button variant="outline" size="icon" onClick={() => navigate('/patrimonio')}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <h1 className="text-3xl font-bold text-gray-900">Item não encontrado</h1>
        </div>
        <Card>
          <CardContent className="p-6">
            <p className="text-gray-600">O item solicitado não foi encontrado.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="outline" size="icon" onClick={() => navigate('/patrimonio')}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">{patrimonio.nome}</h1>
            <p className="text-gray-600 mt-1">Código: {patrimonio.codigo}</p>
          </div>
        </div>
        
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={() => navigate(`/patrimonio/${patrimonio.id}/editar`)}
          >
            <Edit className="h-4 w-4 mr-2" />
            Editar
          </Button>
          <Button
            variant="destructive"
            onClick={handleDelete}
            disabled={deleting}
          >
            <Trash2 className="h-4 w-4 mr-2" />
            {deleting ? 'Excluindo...' : 'Excluir'}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Foto */}
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Package className="h-5 w-5" />
                Foto
              </CardTitle>
            </CardHeader>
            <CardContent>
              {patrimonio.foto ? (
                <img 
                  src={patrimonio.foto} 
                  alt={patrimonio.nome}
                  className="w-full h-64 object-cover rounded-lg border"
                />
              ) : (
                <div className="w-full h-64 bg-gray-100 rounded-lg flex items-center justify-center">
                  <Package className="h-12 w-12 text-gray-400" />
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Informações principais */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Informações Gerais
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-500">Status</label>
                  <div className="mt-1">
                    <Badge className={getStatusColor(patrimonio.status)}>
                      {patrimonio.status}
                    </Badge>
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Categoria</label>
                  <p className="mt-1 text-gray-900">{patrimonio.categoria}</p>
                </div>
              </div>

              {patrimonio.subcategoria && (
                <div>
                  <label className="text-sm font-medium text-gray-500">Subcategoria</label>
                  <p className="mt-1 text-gray-900">{patrimonio.subcategoria}</p>
                </div>
              )}

              {patrimonio.descricao && (
                <div>
                  <label className="text-sm font-medium text-gray-500">Descrição</label>
                  <p className="mt-1 text-gray-900">{patrimonio.descricao}</p>
                </div>
              )}

              {patrimonio.numero_serie && (
                <div>
                  <label className="text-sm font-medium text-gray-500">Número de Série</label>
                  <p className="mt-1 text-gray-900 font-mono">{patrimonio.numero_serie}</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Informações financeiras */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="h-5 w-5" />
                Informações Financeiras
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-500">Valor de Aquisição</label>
                  <p className="mt-1 text-gray-900 font-semibold">
                    R$ {patrimonio.valor_aquisicao.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </p>
                </div>
                {patrimonio.valor_atual && (
                  <div>
                    <label className="text-sm font-medium text-gray-500">Valor Atual</label>
                    <p className="mt-1 text-gray-900 font-semibold">
                      R$ {patrimonio.valor_atual.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </p>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-500">Data de Aquisição</label>
                  <p className="mt-1 text-gray-900 flex items-center gap-2">
                    <Calendar className="h-4 w-4" />
                    {format(new Date(patrimonio.data_aquisicao), 'dd/MM/yyyy')}
                  </p>
                </div>
                {patrimonio.fornecedor && (
                  <div>
                    <label className="text-sm font-medium text-gray-500">Fornecedor</label>
                    <p className="mt-1 text-gray-900">{patrimonio.fornecedor}</p>
                  </div>
                )}
              </div>

              {patrimonio.garantia && (
                <div>
                  <label className="text-sm font-medium text-gray-500">Garantia</label>
                  <p className="mt-1 text-gray-900">{patrimonio.garantia}</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Localização e responsável */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="h-5 w-5" />
                Localização e Responsável
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {patrimonio.responsavel && (
                <div>
                  <label className="text-sm font-medium text-gray-500">Responsável</label>
                  <p className="mt-1 text-gray-900 flex items-center gap-2">
                    <User className="h-4 w-4" />
                    {patrimonio.responsavel}
                  </p>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {patrimonio.localizacao_setor && (
                  <div>
                    <label className="text-sm font-medium text-gray-500">Setor</label>
                    <p className="mt-1 text-gray-900">{patrimonio.localizacao_setor}</p>
                  </div>
                )}
                {patrimonio.localizacao_sala && (
                  <div>
                    <label className="text-sm font-medium text-gray-500">Sala</label>
                    <p className="mt-1 text-gray-900">{patrimonio.localizacao_sala}</p>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {patrimonio.localizacao_bloco && (
                  <div>
                    <label className="text-sm font-medium text-gray-500">Bloco</label>
                    <p className="mt-1 text-gray-900">{patrimonio.localizacao_bloco}</p>
                  </div>
                )}
                {patrimonio.localizacao_andar && (
                  <div>
                    <label className="text-sm font-medium text-gray-500">Andar</label>
                    <p className="mt-1 text-gray-900">{patrimonio.localizacao_andar}</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Observações */}
          {patrimonio.observacoes && (
            <Card>
              <CardHeader>
                <CardTitle>Observações</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-900">{patrimonio.observacoes}</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
