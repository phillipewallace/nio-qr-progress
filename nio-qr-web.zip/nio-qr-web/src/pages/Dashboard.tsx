
import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useApi } from '@/hooks/useApi';
import { Package, DollarSign, Wrench, MapPin, TrendingUp, Users, AlertTriangle, CheckCircle } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

// Componente StatsCard inline para resolver o erro de build
const StatsCard = ({ title, value, icon: Icon, color }: {
  title: string;
  value: string | number;
  icon: React.ComponentType<any>;
  color: string;
}) => (
  <Card>
    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
      <CardTitle className="text-sm font-medium">
        {title}
      </CardTitle>
      <Icon className={`h-4 w-4 ${color}`} />
    </CardHeader>
    <CardContent>
      <div className="text-2xl font-bold">{value}</div>
    </CardContent>
  </Card>
);

interface DashboardStats {
  patrimonio: {
    total: number;
    ativos: number;
    inativos: number;
    manutencao: number;
    valor_total_aquisicao: number;
    valor_total_atual: number;
  };
  categorias: { [key: string]: { quantidade: number; valor_total: number } };
  status: { [key: string]: number };
  alertas: {
    manutencoes_pendentes: number;
    seguros_vencendo: number;
  };
}

export default function Dashboard() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);
  const { get } = useApi();

  useEffect(() => {
    const fetchStats = async () => {
      try {
        console.log('📊 [DASHBOARD] Buscando estatísticas...');
        const response = await get('/dashboard/stats');
        const data = await response.json();
        
        console.log('📊 [DASHBOARD] Dados recebidos:', data);
        setStats(data);
      } catch (error) {
        console.error('❌ [DASHBOARD] Erro ao buscar estatísticas:', error);
        toast({
          title: 'Erro',
          description: 'Não foi possível carregar as estatísticas.',
          variant: 'destructive',
        });
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  if (!stats) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <AlertTriangle className="h-12 w-12 text-yellow-600 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900">Erro ao carregar dados</h3>
          <p className="text-gray-500">Não foi possível carregar as estatísticas do dashboard.</p>
        </div>
      </div>
    );
  }

  // Função helper para formatar números com fallback
  const formatNumber = (value: number | undefined) => {
    return (value || 0).toLocaleString('pt-BR');
  };

  const formatCurrency = (value: number | undefined) => {
    return `R$ ${(value || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`;
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
        <p className="text-muted-foreground">
          Visão geral do sistema de patrimônio
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatsCard
          title="Total de Patrimônios"
          value={formatNumber(stats.patrimonio?.total)}
          icon={Package}
          color="text-blue-600"
        />
        <StatsCard
          title="Valor Total"
          value={formatCurrency(stats.patrimonio?.valor_total_atual)}
          icon={DollarSign}
          color="text-green-600"
        />
        <StatsCard
          title="Manutenções Pendentes"
          value={formatNumber(stats.alertas?.manutencoes_pendentes)}
          icon={Wrench}
          color="text-yellow-600"
        />
        <StatsCard
          title="Seguros Vencendo"
          value={formatNumber(stats.alertas?.seguros_vencendo)}
          icon={MapPin}
          color="text-purple-600"
        />
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-green-600" />
              Patrimônios Ativos
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {formatNumber(stats.patrimonio?.ativos)}
            </div>
            <p className="text-sm text-muted-foreground">
              Em operação normal
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Wrench className="h-5 w-5 text-yellow-600" />
              Em Manutenção
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">
              {formatNumber(stats.patrimonio?.manutencao)}
            </div>
            <p className="text-sm text-muted-foreground">
              Necessitam atenção
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <DollarSign className="h-5 w-5 text-blue-600" />
              Valor Médio
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">
              {formatCurrency(
                stats.patrimonio?.total > 0 
                  ? (stats.patrimonio?.valor_total_atual || 0) / stats.patrimonio.total 
                  : 0
              )}
            </div>
            <p className="text-sm text-muted-foreground">
              Por patrimônio
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
