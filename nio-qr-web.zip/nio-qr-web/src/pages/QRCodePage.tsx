
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  QrCode,
  Download,
  Search,
  Package,
  Eye,
  DownloadIcon
} from 'lucide-react';
import { Patrimonio } from '@/types/patrimonio';
import { generatePatrimonioQRCode, downloadQRCode } from '@/utils/qrcode';
import { toast } from '@/hooks/use-toast';
import { useApi } from '@/hooks/useApi';

export default function QRCodePage() {
  const [patrimonios, setPatrimonios] = useState<Patrimonio[]>([]);
  const [filteredPatrimonios, setFilteredPatrimonios] = useState<Patrimonio[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [generatingQR, setGeneratingQR] = useState<string | null>(null);
  const [qrCodes, setQrCodes] = useState<Record<string, string>>({});

  const { get } = useApi();

  useEffect(() => {
    fetchPatrimonios();
  }, []);

  useEffect(() => {
    filterPatrimonios();
  }, [searchTerm, patrimonios]);

  const fetchPatrimonios = async () => {
    console.log('🏷️ [QRCodes] Buscando patrimônios...');
    try {
      const response = await get('/qrcodes');
      const result = await response.json();
      
      console.log('✅ [QRCodes] Patrimônios recebidos:', result.data);
      setPatrimonios(result.data || []);
    } catch (error) {
      console.error('❌ [QRCodes] Erro ao buscar patrimônios:', error);
      toast({
        title: 'Erro',
        description: 'Erro ao carregar patrimônios',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const filterPatrimonios = () => {
    if (!searchTerm) {
      setFilteredPatrimonios(patrimonios);
      return;
    }

    const filtered = patrimonios.filter(item =>
      item.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.codigo.toLowerCase().includes(searchTerm.toLowerCase())
    );

    setFilteredPatrimonios(filtered);
  };

  const handleGenerateQR = async (item: Patrimonio) => {
    setGeneratingQR(item.id);
    try {
      const qrCode = await generatePatrimonioQRCode(item.id);
      setQrCodes(prev => ({
        ...prev,
        [item.id]: qrCode
      }));
      toast({
        title: "QR Code gerado!",
        description: `QR Code do item ${item.codigo} foi gerado com sucesso.`,
      });
    } catch (error) {
      toast({
        title: "Erro ao gerar QR Code",
        description: "Não foi possível gerar o QR Code. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setGeneratingQR(null);
    }
  };

  const handleDownloadQR = (item: Patrimonio) => {
    const qrCode = qrCodes[item.id];
    if (qrCode) {
      downloadQRCode(qrCode, item.codigo);
      toast({
        title: "Download iniciado!",
        description: `QR Code do item ${item.codigo} foi baixado.`,
      });
    }
  };

  const handleGenerateAllQR = async () => {
    setGeneratingQR('all');
    let successCount = 0;
    
    for (const item of filteredPatrimonios) {
      try {
        const qrCode = await generatePatrimonioQRCode(item.id);
        setQrCodes(prev => ({
          ...prev,
          [item.id]: qrCode
        }));
        successCount++;
      } catch (error) {
        console.error(`Erro ao gerar QR Code para ${item.codigo}:`, error);
      }
    }
    
    setGeneratingQR(null);
    toast({
      title: "QR Codes gerados!",
      description: `${successCount} de ${filteredPatrimonios.length} QR Codes foram gerados com sucesso.`,
    });
  };

  if (loading) {
    return (
      <div className="space-y-6 animate-pulse">
        <div className="h-20 bg-gray-200 rounded-lg"></div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="h-80 bg-gray-200 rounded-lg"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">QR Codes</h1>
          <p className="text-gray-600 mt-1">Gere e gerencie QR Codes para seus itens</p>
        </div>
        <Button 
          onClick={handleGenerateAllQR}
          disabled={generatingQR === 'all'}
          className="gap-2 bg-gradient-primary"
        >
          <QrCode className="h-4 w-4" />
          {generatingQR === 'all' ? 'Gerando...' : `Gerar Todos (${filteredPatrimonios.length})`}
        </Button>
      </div>

      {/* Filtros */}
      <Card>
        <CardContent className="pt-6">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Buscar por nome ou código..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total de Itens</p>
                <p className="text-2xl font-bold">{filteredPatrimonios.length}</p>
              </div>
              <Package className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">QR Codes Gerados</p>
                <p className="text-2xl font-bold">{Object.keys(qrCodes).length}</p>
              </div>
              <QrCode className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Pendentes</p>
                <p className="text-2xl font-bold">
                  {filteredPatrimonios.length - Object.keys(qrCodes).length}
                </p>
              </div>
              <div className="h-8 w-8 bg-orange-100 rounded-full flex items-center justify-center">
                <span className="text-orange-600 text-sm font-bold">!</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Grid de QR Codes */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredPatrimonios.map((item) => {
          const hasQR = qrCodes[item.id];
          const isGenerating = generatingQR === item.id;

          return (
            <Card key={item.id} className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-lg">{item.nome}</CardTitle>
                    <p className="text-sm text-gray-500 mt-1">{item.codigo}</p>
                  </div>
                  <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                    {item.categoria}
                  </Badge>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                {/* QR Code Display */}
                <div className="flex justify-center">
                  {hasQR ? (
                    <div className="p-4 bg-white border-2 border-gray-200 rounded-lg">
                      <img 
                        src={qrCodes[item.id]} 
                        alt={`QR Code ${item.codigo}`}
                        className="w-32 h-32"
                      />
                    </div>
                  ) : (
                    <div className="w-40 h-40 bg-gray-50 border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center">
                      <div className="text-center">
                        <QrCode className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                        <p className="text-sm text-gray-500">QR Code não gerado</p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Item Info */}
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Localização:</span>
                    <span className="font-medium">{item.localizacao_setor || 'N/A'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Responsável:</span>
                    <span className="font-medium">{item.responsavel || 'N/A'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Status:</span>
                    <Badge 
                      variant={item.status === 'Ativo' ? 'default' : 'secondary'}
                      className={item.status === 'Ativo' ? 'bg-green-100 text-green-800' : ''}
                    >
                      {item.status}
                    </Badge>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-2">
                  {hasQR ? (
                    <Button
                      onClick={() => handleDownloadQR(item)}
                      className="flex-1 gap-2"
                      variant="outline"
                    >
                      <DownloadIcon className="h-4 w-4" />
                      Download
                    </Button>
                  ) : (
                    <Button
                      onClick={() => handleGenerateQR(item)}
                      disabled={isGenerating}
                      className="flex-1 gap-2 bg-gradient-primary"
                    >
                      <QrCode className="h-4 w-4" />
                      {isGenerating ? 'Gerando...' : 'Gerar QR'}
                    </Button>
                  )}
                  
                  <Button
                    variant="ghost"
                    size="icon"
                    className="shrink-0"
                  >
                    <Eye className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {filteredPatrimonios.length === 0 && (
        <Card>
          <CardContent className="py-12 text-center">
            <div className="text-gray-500">
              <QrCode className="h-12 w-12 mx-auto mb-4 text-gray-300" />
              <h3 className="text-lg font-medium mb-2">Nenhum item encontrado</h3>
              <p className="text-sm">
                Tente ajustar os filtros de busca
              </p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
