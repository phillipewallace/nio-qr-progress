
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { 
  Shield, 
  Plus, 
  Search, 
  MoreHorizontal, 
  Eye,
  Edit,
  Trash2,
  Calendar,
  DollarSign,
  AlertTriangle
} from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { useApi } from '@/hooks/useApi';

interface Seguro {
  id: string;
  patrimonio_id: string;
  patrimonio_nome?: string;
  patrimonio_codigo?: string;
  seguradora: string;
  numero_apolice: string;
  tipo_cobertura: string;
  valor_segurado: number;
  valor_premio: number;
  data_inicio: string;
  data_vencimento: string;
  status: 'Ativo' | 'Vencido' | 'Cancelado';
  observacoes?: string;
  created_at: string;
}

export default function Seguros() {
  const [seguros, setSeguros] = useState<Seguro[]>([]);
  const [filteredSeguros, setFilteredSeguros] = useState<Seguro[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  const { get, delete: del } = useApi();

  useEffect(() => {
    fetchSeguros();
  }, []);

  useEffect(() => {
    filterSeguros();
  }, [searchTerm, seguros]);

  const fetchSeguros = async () => {
    console.log('🛡️ [Seguros] Buscando seguros...');
    try {
      const response = await get('/seguros');
      const data = await response.json();
      
      console.log('✅ [Seguros] Seguros recebidos:', data);
      setSeguros(data);
    } catch (error) {
      console.error('❌ [Seguros] Erro ao buscar seguros:', error);
      toast({
        title: 'Erro',
        description: 'Erro ao carregar seguros',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const filterSeguros = () => {
    if (!searchTerm) {
      setFilteredSeguros(seguros);
      return;
    }

    const filtered = seguros.filter(seguro =>
      seguro.seguradora.toLowerCase().includes(searchTerm.toLowerCase()) ||
      seguro.numero_apolice.toLowerCase().includes(searchTerm.toLowerCase()) ||
      seguro.patrimonio_nome?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      seguro.patrimonio_codigo?.toLowerCase().includes(searchTerm.toLowerCase())
    );

    setFilteredSeguros(filtered);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Tem certeza que deseja excluir este seguro?')) {
      return;
    }

    try {
      await del(`/seguros/${id}`);
      toast({
        title: 'Sucesso',
        description: 'Seguro excluído com sucesso',
      });
      fetchSeguros();
    } catch (error) {
      console.error('Erro ao excluir seguro:', error);
      toast({
        title: 'Erro',
        description: 'Erro ao excluir seguro',
        variant: 'destructive',
      });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Ativo': return 'bg-green-100 text-green-800';
      case 'Vencido': return 'bg-red-100 text-red-800';
      case 'Cancelado': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const isVencimentoProximo = (dataVencimento: string) => {
    const hoje = new Date();
    const vencimento = new Date(dataVencimento);
    const diasParaVencimento = Math.ceil((vencimento.getTime() - hoje.getTime()) / (1000 * 3600 * 24));
    return diasParaVencimento <= 30 && diasParaVencimento >= 0;
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  // Calcular estatísticas
  const stats = {
    totalSeguros: seguros.length,
    segurosAtivos: seguros.filter(s => s.status === 'Ativo').length,
    valorTotalSegurado: seguros.filter(s => s.status === 'Ativo').reduce((sum, s) => sum + s.valor_segurado, 0),
    premioAnual: seguros.filter(s => s.status === 'Ativo').reduce((sum, s) => sum + s.valor_premio, 0),
    vencendoEm30Dias: seguros.filter(s => s.status === 'Ativo' && isVencimentoProximo(s.data_vencimento)).length
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-2">
            <Shield className="h-8 w-8" />
            Seguros
          </h1>
          <p className="text-gray-600 mt-1">Gerencie apólices de seguro dos patrimônios</p>
        </div>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Novo Seguro
        </Button>
      </div>

      {/* Cards de Estatísticas */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total de Seguros</p>
                <p className="text-2xl font-bold">{stats.totalSeguros}</p>
              </div>
              <Shield className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Seguros Ativos</p>
                <p className="text-2xl font-bold">{stats.segurosAtivos}</p>
              </div>
              <div className="h-8 w-8 bg-green-100 rounded-full flex items-center justify-center">
                <Shield className="h-4 w-4 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Valor Total Segurado</p>
                <p className="text-xl font-bold">{formatCurrency(stats.valorTotalSegurado)}</p>
              </div>
              <DollarSign className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Prêmio Anual</p>
                <p className="text-xl font-bold">{formatCurrency(stats.premioAnual)}</p>
              </div>
              <Calendar className="h-8 w-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Alerta de Vencimentos */}
      {stats.vencendoEm30Dias > 0 && (
        <Card className="border-orange-200 bg-orange-50">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <AlertTriangle className="h-5 w-5 text-orange-600" />
              <div>
                <p className="font-medium text-orange-900">
                  Atenção: {stats.vencendoEm30Dias} seguro(s) vencendo em 30 dias
                </p>
                <p className="text-sm text-orange-700">
                  Verifique os seguros que precisam ser renovados
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <CardTitle>Lista de Seguros</CardTitle>
            <div className="relative w-full sm:w-80">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Buscar seguros..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Patrimônio</TableHead>
                <TableHead>Seguradora</TableHead>
                <TableHead>Nº Apólice</TableHead>
                <TableHead>Valor Segurado</TableHead>
                <TableHead>Prêmio</TableHead>
                <TableHead>Vencimento</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredSeguros.map((seguro) => (
                <TableRow key={seguro.id}>
                  <TableCell>
                    <div>
                      <p className="font-medium">{seguro.patrimonio_codigo}</p>
                      <p className="text-sm text-gray-500">{seguro.patrimonio_nome}</p>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div>
                      <p className="font-medium">{seguro.seguradora}</p>
                      <p className="text-sm text-gray-500">{seguro.tipo_cobertura}</p>
                    </div>
                  </TableCell>
                  <TableCell className="font-mono text-sm">{seguro.numero_apolice}</TableCell>
                  <TableCell className="font-medium text-green-600">
                    {formatCurrency(seguro.valor_segurado)}
                  </TableCell>
                  <TableCell className="font-medium">
                    {formatCurrency(seguro.valor_premio)}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      {isVencimentoProximo(seguro.data_vencimento) && (
                        <AlertTriangle className="h-4 w-4 text-orange-500" />
                      )}
                      {new Date(seguro.data_vencimento).toLocaleDateString('pt-BR')}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge className={getStatusColor(seguro.status)}>
                      {seguro.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Ações</DropdownMenuLabel>
                        <DropdownMenuItem>
                          <Eye className="h-4 w-4 mr-2" />
                          Ver Detalhes
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Edit className="h-4 w-4 mr-2" />
                          Editar
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem 
                          onClick={() => handleDelete(seguro.id)}
                          className="text-red-600"
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Excluir
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          {filteredSeguros.length === 0 && (
            <div className="text-center py-8">
              <Shield className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">
                {searchTerm ? 'Nenhum seguro encontrado' : 'Nenhum seguro cadastrado'}
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
