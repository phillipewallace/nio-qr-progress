
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
} from 'recharts';
import {
  FileText,
  Download,
  Filter,
  Calendar,
  DollarSign,
  Package,
  TrendingUp,
  AlertTriangle,
} from 'lucide-react';
import { useApi } from '@/hooks/useApi';
import { toast } from '@/hooks/use-toast';

interface RelatorioPatrimonio {
  id: string;
  codigo: string;
  nome: string;
  categoria: string;
  status: string;
  valor_atual: string;
  data_aquisicao: string;
  localizacao_setor?: string;
  localizacao_sala?: string;
}

interface RelatorioManutencao {
  id: string;
  titulo: string;
  tipo: string;
  status: string;
  custo: string;
  data_solicitacao: string;
  patrimonio_nome: string;
}

interface RelatorioEstatisticas {
  total_patrimonios: number;
  valor_total: number;
  patrimonios_por_categoria: Array<{ categoria: string; quantidade: number; valor: number }>;
  manutencoes_por_mes: Array<{ mes: string; quantidade: number; custo: number }>;
}

export default function Relatorios() {
  const [tipoRelatorio, setTipoRelatorio] = useState<'patrimonio' | 'manutencao' | 'estatisticas'>('patrimonio');
  const [patrimonios, setPatrimonios] = useState<RelatorioPatrimonio[]>([]);
  const [manutencoes, setManutencoes] = useState<RelatorioManutencao[]>([]);
  const [estatisticas, setEstatisticas] = useState<RelatorioEstatisticas | null>(null);
  const [loading, setLoading] = useState(false);
  const [filtros, setFiltros] = useState({
    dataInicio: '',
    dataFim: '',
    categoria: '',
    status: '',
  });

  const { get } = useApi();

  useEffect(() => {
    carregarRelatorio();
  }, [tipoRelatorio]);

  const carregarRelatorio = async () => {
    console.log('📊 [Relatórios] Carregando relatório:', tipoRelatorio);
    setLoading(true);
    
    try {
      switch (tipoRelatorio) {
        case 'patrimonio':
          await carregarPatrimonios();
          break;
        case 'manutencao':
          await carregarManutencoes();
          break;
        case 'estatisticas':
          await carregarEstatisticas();
          break;
      }
    } catch (error) {
      console.error('❌ [Relatórios] Erro ao carregar relatório:', error);
      toast({
        title: 'Erro',
        description: 'Erro ao carregar relatório',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const carregarPatrimonios = async () => {
    const response = await get('/patrimonios?limit=1000');
    const data = await response.json();
    setPatrimonios(data.data || []);
  };

  const carregarManutencoes = async () => {
    const response = await get('/manutencoes');
    const data = await response.json();
    setManutencoes(data || []);
  };

  const carregarEstatisticas = async () => {
    const response = await get('/dashboard/stats');
    const data = await response.json();
    
    setEstatisticas({
      total_patrimonios: parseInt(data.stats?.total_patrimonios || '0'),
      valor_total: parseFloat(data.stats?.valor_total || '0'),
      patrimonios_por_categoria: data.categorias?.map((cat: any) => ({
        categoria: cat.categoria,
        quantidade: parseInt(cat.quantidade),
        valor: parseFloat(cat.valor_total)
      })) || [],
      manutencoes_por_mes: []
    });
  };

  const exportarRelatorio = () => {
    console.log('📥 [Relatórios] Exportando relatório:', tipoRelatorio);
    
    let dados: any[] = [];
    let nomeArquivo = '';
    
    switch (tipoRelatorio) {
      case 'patrimonio':
        dados = patrimonios;
        nomeArquivo = 'relatorio-patrimonios.csv';
        break;
      case 'manutencao':
        dados = manutencoes;
        nomeArquivo = 'relatorio-manutencoes.csv';
        break;
      case 'estatisticas':
        dados = estatisticas ? [estatisticas] : [];
        nomeArquivo = 'relatorio-estatisticas.csv';
        break;
    }

    if (dados.length === 0) {
      toast({
        title: 'Aviso',
        description: 'Nenhum dado para exportar',
        variant: 'destructive',
      });
      return;
    }

    // Conversão simples para CSV
    const headers = Object.keys(dados[0]);
    const csvContent = [
      headers.join(','),
      ...dados.map(row => headers.map(header => row[header] || '').join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', nomeArquivo);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    toast({
      title: 'Sucesso',
      description: 'Relatório exportado com sucesso',
    });
  };

  const CORES = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-2">
            <FileText className="h-8 w-8" />
            Relatórios
          </h1>
          <p className="text-gray-600 mt-1">Análises e exportações dos dados do sistema</p>
        </div>
        <Button onClick={exportarRelatorio} disabled={loading}>
          <Download className="h-4 w-4 mr-2" />
          Exportar
        </Button>
      </div>

      {/* Seletor de Tipo de Relatório */}
      <Card>
        <CardHeader>
          <CardTitle>Configuração do Relatório</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <Label htmlFor="tipo">Tipo de Relatório</Label>
              <Select value={tipoRelatorio} onValueChange={(value: any) => setTipoRelatorio(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="patrimonio">Patrimônios</SelectItem>
                  <SelectItem value="manutencao">Manutenções</SelectItem>
                  <SelectItem value="estatisticas">Estatísticas</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="dataInicio">Data Início</Label>
              <Input
                id="dataInicio"
                type="date"
                value={filtros.dataInicio}
                onChange={(e) => setFiltros(prev => ({ ...prev, dataInicio: e.target.value }))}
              />
            </div>

            <div>
              <Label htmlFor="dataFim">Data Fim</Label>
              <Input
                id="dataFim"
                type="date"
                value={filtros.dataFim}
                onChange={(e) => setFiltros(prev => ({ ...prev, dataFim: e.target.value }))}
              />
            </div>

            <div className="flex items-end">
              <Button onClick={carregarRelatorio} disabled={loading} className="w-full">
                <Filter className="h-4 w-4 mr-2" />
                Filtrar
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {loading ? (
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
        </div>
      ) : (
        <>
          {/* Relatório de Patrimônios */}
          {tipoRelatorio === 'patrimonio' && (
            <Card>
              <CardHeader>
                <CardTitle>Relatório de Patrimônios</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Código</TableHead>
                      <TableHead>Nome</TableHead>
                      <TableHead>Categoria</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Valor Atual</TableHead>
                      <TableHead>Localização</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {patrimonios.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium">{item.codigo}</TableCell>
                        <TableCell>{item.nome}</TableCell>
                        <TableCell>{item.categoria}</TableCell>
                        <TableCell>
                          <Badge variant={item.status === 'Ativo' ? 'default' : 'secondary'}>
                            {item.status}
                          </Badge>
                        </TableCell>
                        <TableCell>R$ {Number(item.valor_atual || 0).toLocaleString('pt-BR')}</TableCell>
                        <TableCell>
                          {item.localizacao_setor && item.localizacao_sala
                            ? `${item.localizacao_setor} - ${item.localizacao_sala}`
                            : 'Não definida'
                          }
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          )}

          {/* Relatório de Manutenções */}
          {tipoRelatorio === 'manutencao' && (
            <Card>
              <CardHeader>
                <CardTitle>Relatório de Manutenções</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Título</TableHead>
                      <TableHead>Tipo</TableHead>
                      <TableHead>Patrimônio</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Custo</TableHead>
                      <TableHead>Data</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {manutencoes.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium">{item.titulo}</TableCell>
                        <TableCell>{item.tipo}</TableCell>
                        <TableCell>{item.patrimonio_nome}</TableCell>
                        <TableCell>
                          <Badge variant={item.status === 'Concluída' ? 'default' : 'secondary'}>
                            {item.status}
                          </Badge>
                        </TableCell>
                        <TableCell>R$ {Number(item.custo || 0).toLocaleString('pt-BR')}</TableCell>
                        <TableCell>
                          {new Date(item.data_solicitacao).toLocaleDateString('pt-BR')}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          )}

          {/* Relatório de Estatísticas */}
          {tipoRelatorio === 'estatisticas' && estatisticas && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Patrimônios por Categoria</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={estatisticas.patrimonios_por_categoria}
                        cx="50%"
                        cy="50%"
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="quantidade"
                        label={({ categoria, quantidade }) => `${categoria}: ${quantidade}`}
                      >
                        {estatisticas.patrimonios_por_categoria.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={CORES[index % CORES.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Resumo Geral</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <Package className="h-8 w-8 text-blue-600" />
                        <div>
                          <p className="text-sm text-blue-600">Total de Patrimônios</p>
                          <p className="text-2xl font-bold text-blue-900">
                            {estatisticas.total_patrimonios}
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <DollarSign className="h-8 w-8 text-green-600" />
                        <div>
                          <p className="text-sm text-green-600">Valor Total</p>
                          <p className="text-2xl font-bold text-green-900">
                            R$ {estatisticas.valor_total.toLocaleString('pt-BR')}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </>
      )}
    </div>
  );
}
