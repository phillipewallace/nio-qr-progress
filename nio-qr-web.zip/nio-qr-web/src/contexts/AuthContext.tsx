
import React, { createContext, useContext, useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from '@/hooks/use-toast';

interface User {
  id: string;
  nome: string;
  usuario: string;
  permissoes: { [key: string]: 'viewer' | 'editor' | 'admin' };
}

interface AuthContextType {
  user: User | null;
  token: string | null;
  login: (usuario: string, senha: string) => Promise<boolean>;
  logout: () => void;
  isAuthenticated: boolean;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType>({} as AuthContextType);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth deve ser usado dentro de um AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  // Detectar a URL atual automaticamente
  const getCurrentApiUrl = () => {
    const currentHost = window.location.hostname;
    const currentProtocol = window.location.protocol;
    const currentPort = window.location.port;
    
    console.log('🔍 [AUTH] Detectando configuração atual:');
    console.log(`  - Protocol: ${currentProtocol}`);
    console.log(`  - Hostname: ${currentHost}`);
    console.log(`  - Port: ${currentPort}`);
    
    // URL da API (sempre na porta 3001)
    const apiUrl = `${currentProtocol}//${currentHost}:3001/api`;
    
    console.log(`🔧 [AUTH] API URL configurada: ${apiUrl}`);
    return apiUrl;
  };

  const API_BASE_URL = getCurrentApiUrl();

  useEffect(() => {
    const initAuth = async () => {
      console.log('\n🔐 [AUTH] === INICIALIZANDO AUTENTICAÇÃO ===');
      console.log(`🔧 [AUTH] API Base URL: ${API_BASE_URL}`);

      const storedToken = localStorage.getItem('authToken');
      const storedUser = localStorage.getItem('currentUser');

      console.log(`📱 [AUTH] Token no localStorage: ${storedToken ? 'PRESENTE' : 'AUSENTE'}`);
      console.log(`👤 [AUTH] Usuário no localStorage: ${storedUser ? 'PRESENTE' : 'AUSENTE'}`);

      if (storedToken && storedUser) {
        try {
          console.log('🔍 [AUTH] Verificando token armazenado...');
          console.log(`📡 [AUTH] Fazendo request para: ${API_BASE_URL}/auth/verify`);

          const response = await fetch(`${API_BASE_URL}/auth/verify`, {
            method: 'GET',
            headers: {
              'Authorization': `Bearer ${storedToken}`,
              'Content-Type': 'application/json',
            },
          });

          console.log(`📨 [AUTH] Status da resposta: ${response.status}`);
          console.log(`📨 [AUTH] Status text: ${response.statusText}`);
          console.log(`📨 [AUTH] Headers:`, Object.fromEntries(response.headers.entries()));

          if (response.ok) {
            const data = await response.json();
            console.log('✅ [AUTH] Token válido! Usuário autenticado:');
            console.log(`👤 [AUTH] Nome: ${data.usuario?.nome}`);
            console.log(`🆔 [AUTH] ID: ${data.usuario?.id}`);
            console.log(`👮 [AUTH] Permissões:`, data.usuario?.permissoes);
            
            setToken(storedToken);
            setUser(data.usuario);
          } else {
            const errorText = await response.text();
            console.log(`❌ [AUTH] Token inválido - Status: ${response.status}`);
            console.log(`❌ [AUTH] Resposta de erro:`, errorText);
            
            localStorage.removeItem('authToken');
            localStorage.removeItem('currentUser');
          }
        } catch (error) {
          console.error('❌ [AUTH] Erro ao verificar token:');
          console.error('  - Tipo:', error instanceof Error ? error.constructor.name : typeof error);
          console.error('  - Mensagem:', error instanceof Error ? error.message : String(error));
          console.error('  - Stack:', error instanceof Error ? error.stack : 'N/A');
          
          localStorage.removeItem('authToken');
          localStorage.removeItem('currentUser');
        }
      } else {
        console.log('ℹ️ [AUTH] Nenhum token encontrado - usuário não autenticado');
      }

      setIsLoading(false);
      console.log('✅ [AUTH] Inicialização da autenticação concluída');
    };

    initAuth();
  }, [API_BASE_URL]);

  const login = async (usuario: string, senha: string): Promise<boolean> => {
    console.log('\n🔐 [AUTH] === INICIANDO PROCESSO DE LOGIN ===');
    console.log(`👤 [AUTH] Usuário: ${usuario}`);
    console.log(`🔒 [AUTH] Senha: ${'*'.repeat(senha.length)}`);
    console.log(`📡 [AUTH] URL de login: ${API_BASE_URL}/auth/login`);

    try {
      const requestData = { usuario, senha };
      console.log('📦 [AUTH] Dados da requisição:', requestData);

      const response = await fetch(`${API_BASE_URL}/auth/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: JSON.stringify(requestData),
      });

      console.log(`📨 [AUTH] Status da resposta: ${response.status} ${response.statusText}`);
      console.log(`📨 [AUTH] Headers da resposta:`, Object.fromEntries(response.headers.entries()));

      if (response.ok) {
        const data = await response.json();
        console.log('✅ [AUTH] Login realizado com sucesso!');
        console.log(`👤 [AUTH] Usuário logado: ${data.usuario?.nome}`);
        console.log(`🆔 [AUTH] ID do usuário: ${data.usuario?.id}`);
        console.log(`🎫 [AUTH] Token recebido: ${data.token ? 'SIM' : 'NÃO'}`);
        console.log(`👮 [AUTH] Permissões:`, data.usuario?.permissoes);

        setToken(data.token);
        setUser(data.usuario);

        localStorage.setItem('authToken', data.token);
        localStorage.setItem('currentUser', JSON.stringify(data.usuario));

        console.log('💾 [AUTH] Dados salvos no localStorage');
        return true;
      } else {
        let errorMessage = 'Credenciais inválidas.';
        let errorDetails = '';
        
        try {
          const errorText = await response.text();
          console.log(`❌ [AUTH] Erro no login - Status: ${response.status}`);
          console.log(`❌ [AUTH] Resposta de erro (texto):`, errorText);
          
          try {
            const errorData = JSON.parse(errorText);
            errorMessage = errorData.error || errorMessage;
            errorDetails = errorData.details || '';
          } catch (parseError) {
            console.log('⚠️ [AUTH] Não foi possível fazer parse do erro como JSON');
            errorMessage = 'Erro de comunicação com o servidor.';
          }
        } catch (textError) {
          console.error('❌ [AUTH] Erro ao ler resposta de erro:', textError);
          errorMessage = 'Erro de comunicação com o servidor.';
        }

        console.log(`❌ [AUTH] Mensagem de erro final: ${errorMessage}`);
        
        toast({
          title: 'Erro no login',
          description: errorMessage,
          variant: 'destructive',
        });
        return false;
      }
    } catch (error) {
      console.error('\n❌ [AUTH] ERRO DE CONEXÃO NO LOGIN:');
      console.error('  - Tipo:', error instanceof Error ? error.constructor.name : typeof error);
      console.error('  - Mensagem:', error instanceof Error ? error.message : String(error));
      console.error('  - Stack:', error instanceof Error ? error.stack : 'N/A');
      
      let errorMessage = 'Não foi possível conectar ao servidor.';
      
      if (error instanceof TypeError && error.message.includes('fetch')) {
        errorMessage = `Erro de conexão: Verifique se o backend está rodando na porta 3001.`;
      } else if (error instanceof Error) {
        errorMessage = `Erro de conexão: ${error.message}`;
      }
      
      toast({
        title: 'Erro no login',
        description: errorMessage,
        variant: 'destructive',
      });
      return false;
    }
  };

  const logout = async () => {
    console.log('\n👋 [AUTH] === INICIANDO PROCESSO DE LOGOUT ===');
    console.log(`👤 [AUTH] Usuário atual: ${user?.nome || 'N/A'}`);

    try {
      if (token) {
        console.log(`📡 [AUTH] Fazendo request de logout para: ${API_BASE_URL}/auth/logout`);
        
        const response = await fetch(`${API_BASE_URL}/auth/logout`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
        });
        
        console.log(`📨 [AUTH] Status do logout: ${response.status}`);
        
        if (response.ok) {
          console.log('✅ [AUTH] Logout no servidor realizado com sucesso');
        } else {
          console.log('⚠️ [AUTH] Erro no logout do servidor, mas continuando...');
        }
      }
    } catch (error) {
      console.error('⚠️ [AUTH] Erro ao fazer logout no servidor:', error);
      console.error('ℹ️ [AUTH] Continuando com logout local...');
    }

    // Limpar estado local
    setUser(null);
    setToken(null);
    localStorage.removeItem('authToken');
    localStorage.removeItem('currentUser');

    console.log('🧹 [AUTH] Estado local limpo');
    console.log('🔄 [AUTH] Redirecionando para login...');
    
    navigate('/login');
    
    toast({
      title: 'Logout realizado',
      description: 'Você foi desconectado com sucesso.',
    });
  };

  const contextValue = {
    user,
    token,
    login,
    logout,
    isAuthenticated: !!user && !!token,
    isLoading,
  };

  console.log(`🔍 [AUTH] Estado atual:`, {
    isAuthenticated: contextValue.isAuthenticated,
    isLoading,
    hasUser: !!user,
    hasToken: !!token,
    userName: user?.nome || 'N/A'
  });

  return (
    <AuthContext.Provider value={contextValue}>
      {children}
    </AuthContext.Provider>
  );
};
