
import { Patrimonio, Categoria, PatrimonioStats } from '@/types/patrimonio';

export const categorias: Categoria[] = [
  {
    id: '1',
    nome: 'Informática',
    descricao: 'Equipamentos de informática e tecnologia',
    subcategorias: ['Desktop', 'Notebook', 'Monitor', 'Impressora', 'Scanner', 'Servidor', 'Switch', 'Roteador'],
    cor: '#3B82F6',
    icone: 'Monitor'
  },
  {
    id: '2',
    nome: 'Móveis',
    descricao: 'Móveis e mobiliário em geral',
    subcategorias: ['Mesa', 'Cadeira', 'Armário', 'Estante', 'Arquivo', 'Sofá', 'Poltrona'],
    cor: '#10B981',
    icone: 'Armchair'
  },
  {
    id: '3',
    nome: 'Veículos',
    descricao: 'Veículos da frota empresarial',
    subcategorias: ['Carro', 'Caminhão', 'Van', 'Motocicleta', 'Ônibus'],
    cor: '#F59E0B',
    icone: 'Car'
  },
  {
    id: '4',
    nome: 'Eletrônicos',
    descricao: 'Equipamentos eletrônicos diversos',
    subcategorias: ['TV', 'Projetor', 'Som', 'Câmera', 'Telefone', 'Ar Condicionado'],
    cor: '#EF4444',
    icone: 'Tv'
  },
  {
    id: '5',
    nome: 'Ferramentas',
    descricao: 'Ferramentas e equipamentos de trabalho',
    subcategorias: ['Furadeira', 'Serra', 'Martelo', 'Chave', 'Medidor', 'Gerador'],
    cor: '#8B5CF6',
    icone: 'Wrench'
  },
  {
    id: '6',
    nome: 'Eletrodomésticos',
    descricao: 'Eletrodomésticos e aparelhos domésticos',
    subcategorias: ['Geladeira', 'Micro-ondas', 'Cafeteira', 'Aspirador', 'Ventilador', 'Aquecedor'],
    cor: '#06B6D4',
    icone: 'Home'
  },
  {
    id: '7',
    nome: 'Segurança',
    descricao: 'Equipamentos de segurança e vigilância',
    subcategorias: ['Câmera CCTV', 'Alarme', 'Extintor', 'Detector', 'Cofre', 'Controle de Acesso'],
    cor: '#DC2626',
    icone: 'Shield'
  },
  {
    id: '8',
    nome: 'Limpeza',
    descricao: 'Equipamentos e materiais de limpeza',
    subcategorias: ['Aspirador Industrial', 'Lavadora', 'Carrinho de Limpeza', 'Enceradeira'],
    cor: '#059669',
    icone: 'Sparkles'
  },
  {
    id: '9',
    nome: 'Escritório',
    descricao: 'Materiais e equipamentos de escritório',
    subcategorias: ['Telefone', 'Fax', 'Calculadora', 'Grampeador', 'Quadro', 'Projetor'],
    cor: '#7C3AED',
    icone: 'Building'
  },
  {
    id: '10',
    nome: 'Médico/Hospitalar',
    descricao: 'Equipamentos médicos e hospitalares',
    subcategorias: ['Desfibrilador', 'Monitor Cardíaco', 'Termômetro', 'Oxímetro', 'Cadeira de Rodas'],
    cor: '#EC4899',
    icone: 'Heart'
  },
  {
    id: '11',
    nome: 'Iluminação',
    descricao: 'Equipamentos de iluminação',
    subcategorias: ['Luminária', 'Refletor', 'Lâmpada LED', 'Spot', 'Lustre', 'Arandela'],
    cor: '#F59E0B',
    icone: 'Lightbulb'
  },
  {
    id: '12',
    nome: 'Climatização',
    descricao: 'Equipamentos de climatização',
    subcategorias: ['Ar Condicionado Split', 'Ventilador de Teto', 'Aquecedor', 'Umidificador'],
    cor: '#0EA5E9',
    icone: 'Wind'
  }
];

export const setores = [
  { id: '1', nome: 'Administrativo' },
  { id: '2', nome: 'Financeiro' },
  { id: '3', nome: 'Recursos Humanos' },
  { id: '4', nome: 'TI' },
  { id: '5', nome: 'Vendas' },
  { id: '6', nome: 'Marketing' },
  { id: '7', nome: 'Produção' },
  { id: '8', nome: 'Almoxarifado' },
  { id: '9', nome: 'Manutenção' },
  { id: '10', nome: 'Segurança' },
  { id: '11', nome: 'Limpeza' },
  { id: '12', nome: 'Recepção' },
  { id: '13', nome: 'Diretoria' },
  { id: '14', nome: 'Jurídico' },
  { id: '15', nome: 'Compras' }
];

export const fornecedores = [
  { id: '1', nome: 'Dell Technologies' },
  { id: '2', nome: 'HP Inc.' },
  { id: '3', nome: 'Lenovo Brasil' },
  { id: '4', nome: 'Samsung Electronics' },
  { id: '5', nome: 'LG Electronics' },
  { id: '6', nome: 'Móveis Excellence Ltda' },
  { id: '7', nome: 'Flex Móveis' },
  { id: '8', nome: 'Office Total' },
  { id: '9', nome: 'TechSupply Brasil' },
  { id: '10', nome: 'Equipamentos Industriais SA' },
  { id: '11', nome: 'Segurança Total Ltda' },
  { id: '12', nome: 'Eletrônicos do Brasil' },
  { id: '13', nome: 'Ferramentas & Cia' },
  { id: '14', nome: 'Casa & Escritório' },
  { id: '15', nome: 'Distribuidora Nacional' }
];

export const patrimoniosMock: Patrimonio[] = [
  {
    id: '1',
    codigo: 'PAT-2024-001',
    nome: 'Notebook Dell Inspiron 15',
    descricao: 'Notebook para uso administrativo',
    categoria: 'Informática',
    subcategoria: 'Notebook',
    responsavel: 'João Silva Santos',
    valor_aquisicao: 2500.00,
    valor_atual: 1800.00,
    data_aquisicao: '2024-01-15',
    garantia: '12 meses',
    fornecedor: 'Dell Technologies',
    numero_serie: 'DL123456789',
    status: 'Ativo',
    observacoes: 'Equipamento em excelente estado de conservação',
    foto: '',
    qr_code: '',
    localizacao_id: '1',
    localizacao_setor: 'Administrativo',
    localizacao_sala: 'Sala 201',
    localizacao_bloco: 'Bloco A',
    localizacao_andar: '2º Andar',
    created_at: '2024-01-15T10:00:00Z',
    updated_at: '2024-01-15T10:00:00Z'
  },
  {
    id: '2',
    codigo: 'PAT-2024-002',
    nome: 'Mesa de Escritório Executiva',
    descricao: 'Mesa executiva em madeira nobre',
    categoria: 'Móveis',
    subcategoria: 'Mesa',
    responsavel: 'Maria Santos',
    valor_aquisicao: 3200.00,
    valor_atual: 2800.00,
    data_aquisicao: '2024-02-01',
    fornecedor: 'Móveis Excellence Ltda',
    numero_serie: 'ME-EXE-001',
    status: 'Ativo',
    observacoes: 'Móvel de alta qualidade, importado',
    foto: '',
    qr_code: '',
    localizacao_id: '2',
    localizacao_setor: 'Diretoria',
    localizacao_sala: 'Sala da Diretoria',
    localizacao_bloco: 'Bloco A',
    localizacao_andar: '3º Andar',
    created_at: '2024-02-01T10:00:00Z',
    updated_at: '2024-02-01T10:00:00Z'
  }
];

export const statsPatrimonio: PatrimonioStats = {
  total: 156,
  ativos: 132,
  inativos: 8,
  manutencao: 16,
  valorTotal: 2456780.50,
  valorDepreciado: 456890.25,
  porCategoria: {
    'Informática': 45,
    'Móveis': 38,
    'Veículos': 12,
    'Eletrônicos': 32,
    'Ferramentas': 29
  },
  porStatus: {
    'Ativo': 132,
    'Inativo': 8,
    'Manutenção': 16,
    'Baixado': 0,
    'Emprestado': 0
  }
};
