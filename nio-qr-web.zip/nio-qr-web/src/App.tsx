
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from '@/contexts/AuthContext';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { Toaster } from '@/components/ui/toaster';
import { Toaster as Sonner } from '@/components/ui/sonner';
import Layout from '@/components/Layout';
import Login from '@/pages/Login';
import Dashboard from '@/pages/Dashboard';
import PatrimonioList from '@/pages/PatrimonioList';
import PatrimonioForm from '@/pages/PatrimonioForm';
import PatrimonioDetails from '@/pages/PatrimonioDetails';
import Usuarios from '@/pages/Usuarios';
import Localizacao from '@/pages/Localizacao';
import Manutencao from '@/pages/Manutencao';
import Seguros from '@/pages/Seguros';
import QRCodePage from '@/pages/QRCodePage';
import Scanner from '@/pages/Scanner';
import Relatorios from '@/pages/Relatorios';
import Configuracoes from '@/pages/Configuracoes';
import NotFound from '@/pages/NotFound';
import Index from '@/pages/Index';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-background">
        <AuthProvider>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route
              path="/"
              element={
                <ProtectedRoute>
                  <Layout />
                </ProtectedRoute>
              }
            >
              <Route index element={<Index />} />
              <Route path="dashboard" element={<Dashboard />} />
              
              {/* Rotas de Patrimônio */}
              <Route path="patrimonio" element={<PatrimonioList />} />
              <Route path="patrimonio/novo" element={<PatrimonioForm />} />
              <Route path="patrimonio/:id" element={<PatrimonioDetails />} />
              <Route path="patrimonio/:id/editar" element={<PatrimonioForm />} />
              
              {/* Outras rotas */}
              <Route path="usuarios" element={<Usuarios />} />
              <Route path="localizacao" element={<Localizacao />} />
              <Route path="manutencao" element={<Manutencao />} />
              <Route path="seguros" element={<Seguros />} />
              <Route path="qrcode" element={<QRCodePage />} />
              <Route path="qrcodes" element={<QRCodePage />} />
              <Route path="scanner" element={<Scanner />} />
              <Route path="relatorios" element={<Relatorios />} />
              <Route path="configuracoes" element={<Configuracoes />} />
              <Route path="*" element={<NotFound />} />
            </Route>
          </Routes>
          <Toaster />
          <Sonner />
        </AuthProvider>
      </div>
    </Router>
  );
}

export default App;
