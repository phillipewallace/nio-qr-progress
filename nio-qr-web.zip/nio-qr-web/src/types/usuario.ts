
export interface Usuario {
  id: string;
  nome: string;
  usuario: string;
  senha: string;
  email?: string;
  telefone?: string;
  cargo: string;
  status: 'Ativo' | 'Inativo';
  permissoes: {
    [key: string]: 'viewer' | 'editor' | 'admin';
  };
  ultimoAcesso?: string;
  criadoEm: string;
}

export interface UserLog {
  id: string;
  usuarioId: string;
  acao: string;
  modulo: string;
  detalhes: string;
  timestamp: string;
  ip?: string;
}

export interface Atividade {
  acao: string;
  modulo: string;
  detalhes: string;
  created_at: string;
  usuario_nome: string;
}
