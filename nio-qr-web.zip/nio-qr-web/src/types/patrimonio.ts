
export interface Patrimonio {
  id: string;
  codigo: string;
  nome: string;
  descricao?: string;
  categoria: string;
  subcategoria?: string;
  responsavel?: string;
  valor_aquisicao: number;
  valor_atual?: number;
  data_aquisicao: string;
  garantia?: string;
  fornecedor?: string;
  numero_serie?: string;
  status: 'Ativo' | 'Inativo' | 'Manutenção' | 'Descartado';
  observacoes?: string;
  foto?: string;
  qr_code?: string;
  localizacao_id?: string;
  localizacao_setor?: string;
  localizacao_sala?: string;
  localizacao_bloco?: string;
  localizacao_andar?: string;
  created_at?: string;
  updated_at?: string;
}

export interface ManutencaoHistorico {
  id: string;
  patrimonio_id: string;
  tipo: 'Preventiva' | 'Corretiva' | 'Preditiva';
  titulo: string;
  descricao: string;
  prioridade: 'Baixa' | 'Média' | 'Alta' | 'Urgente';
  status: 'Pendente' | 'Em Andamento' | 'Concluída' | 'Cancelada';
  data_solicitacao?: string;
  data_agendamento?: string;
  data_conclusao?: string;
  responsavel_solicitacao?: string;
  responsavel_execucao?: string;
  custo?: number;
  observacoes?: string;
  created_at?: string;
  updated_at?: string;
}

export interface Localizacao {
  id: string;
  bloco?: string;
  andar?: string;
  setor: string;
  sala: string;
  descricao?: string;
  capacidade?: number;
  responsavel?: string;
  observacoes?: string;
  created_at?: string;
  updated_at?: string;
}

export interface Seguro {
  id: string;
  patrimonio_id: string;
  seguradora: string;
  numero_apolice: string;
  tipo_cobertura?: string;
  valor_segurado: number;
  valor_premio?: number;
  data_inicio?: string;
  data_vencimento?: string;
  status: 'Ativo' | 'Vencido' | 'Cancelado';
  observacoes?: string;
  created_at?: string;
  updated_at?: string;
}

export interface Categoria {
  id: string;
  nome: string;
  descricao?: string;
  subcategorias: string[];
  cor?: string;
  icone?: string;
}

export interface PatrimonioStats {
  total: number;
  ativos: number;
  inativos: number;
  manutencao: number;
  valorTotal: number;
  valorDepreciado?: number;
  porCategoria: Record<string, number>;
  porStatus: Record<string, number>;
}

export interface RelatorioFiltros {
  categoria?: string;
  status?: string;
  setor?: string;
  dataInicio?: string;
  dataFim?: string;
  valorMinimo?: number;
  valorMaximo?: number;
  responsavel?: string;
  search?: string;
  limit?: number;
  page?: number;
}
