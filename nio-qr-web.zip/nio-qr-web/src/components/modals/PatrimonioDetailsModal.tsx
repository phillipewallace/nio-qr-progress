
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Calendar, MapPin, User, Package, DollarSign, FileText, Shield, Tag, Image as ImageIcon } from 'lucide-react';
import { Patrimonio } from '@/types/patrimonio';

interface PatrimonioDetailsModalProps {
  patrimonio?: Patrimonio | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function PatrimonioDetailsModal({
  patrimonio,
  open,
  onOpenChange
}: PatrimonioDetailsModalProps) {
  if (!patrimonio) return null;

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const formatDate = (dateValue: Date | string) => {
    const date = typeof dateValue === 'string' ? new Date(dateValue) : dateValue;
    return date.toLocaleDateString('pt-BR');
  };

  const getStatusBadge = (status: string) => {
    const variants = {
      'Ativo': 'bg-green-100 text-green-800 border-green-200',
      'Inativo': 'bg-gray-100 text-gray-800 border-gray-200',
      'Manutenção': 'bg-yellow-100 text-yellow-800 border-yellow-200',
      'Descartado': 'bg-red-100 text-red-800 border-red-200'
    };
    
    return (
      <Badge className={variants[status as keyof typeof variants] || variants['Inativo']}>
        {status}
      </Badge>
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Package className="h-5 w-5" />
            Detalhes do Patrimônio
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Foto do Patrimônio */}
          {patrimonio.foto && (
            <div className="text-center">
              <div className="inline-block border rounded-lg overflow-hidden">
                <img 
                  src={patrimonio.foto} 
                  alt={patrimonio.nome}
                  className="w-48 h-48 object-cover"
                />
              </div>
            </div>
          )}

          {!patrimonio.foto && (
            <div className="text-center">
              <div className="w-48 h-48 mx-auto bg-gray-100 border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center">
                <div className="text-center">
                  <ImageIcon className="h-12 w-12 text-gray-400 mx-auto mb-2" />
                  <p className="text-sm text-gray-500">Sem foto</p>
                </div>
              </div>
            </div>
          )}

          {/* Informações Básicas */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium text-gray-600">Código</label>
              <p className="font-mono text-lg font-semibold">{patrimonio.codigo}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-600">Status</label>
              <div className="mt-1">
                {getStatusBadge(patrimonio.status)}
              </div>
            </div>
          </div>

          <div>
            <label className="text-sm font-medium text-gray-600">Nome</label>
            <p className="text-lg font-medium">{patrimonio.nome}</p>
          </div>

          {patrimonio.descricao && (
            <div>
              <label className="text-sm font-medium text-gray-600">Descrição</label>
              <p className="text-gray-900">{patrimonio.descricao}</p>
            </div>
          )}

          <Separator />

          {/* Categorização */}
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center gap-2">
              <Tag className="h-4 w-4 text-gray-400" />
              <div>
                <label className="text-sm font-medium text-gray-600">Categoria</label>
                <p>{patrimonio.categoria}</p>
              </div>
            </div>
            {patrimonio.subcategoria && (
              <div>
                <label className="text-sm font-medium text-gray-600">Subcategoria</label>
                <p>{patrimonio.subcategoria}</p>
              </div>
            )}
          </div>

          <Separator />

          {/* Localização */}
          <div className="flex items-center gap-2">
            <MapPin className="h-4 w-4 text-gray-400" />
            <div>
              <label className="text-sm font-medium text-gray-600">Localização</label>
              <p>
                {patrimonio.localizacao_setor && patrimonio.localizacao_sala 
                  ? `${patrimonio.localizacao_setor} - ${patrimonio.localizacao_sala}`
                  : 'Não informado'
                }
              </p>
              {patrimonio.localizacao_bloco && (
                <p className="text-sm text-gray-500">Bloco: {patrimonio.localizacao_bloco}</p>
              )}
              {patrimonio.localizacao_andar && (
                <p className="text-sm text-gray-500">Andar: {patrimonio.localizacao_andar}</p>
              )}
            </div>
          </div>

          {/* Responsável */}
          {patrimonio.responsavel && (
            <div className="flex items-center gap-2">
              <User className="h-4 w-4 text-gray-400" />
              <div>
                <label className="text-sm font-medium text-gray-600">Responsável</label>
                <p>{patrimonio.responsavel}</p>
              </div>
            </div>
          )}

          <Separator />

          {/* Informações Financeiras */}
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center gap-2">
              <DollarSign className="h-4 w-4 text-gray-400" />
              <div>
                <label className="text-sm font-medium text-gray-600">Valor de Aquisição</label>
                <p className="font-semibold text-green-600">
                  {formatCurrency(patrimonio.valor_aquisicao)}
                </p>
              </div>
            </div>
            {patrimonio.valor_atual && (
              <div>
                <label className="text-sm font-medium text-gray-600">Valor Atual</label>
                <p className="font-semibold">
                  {formatCurrency(patrimonio.valor_atual)}
                </p>
              </div>
            )}
          </div>

          <Separator />

          {/* Datas */}
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center gap-2">
              <Calendar className="h-4 w-4 text-gray-400" />
              <div>
                <label className="text-sm font-medium text-gray-600">Data de Aquisição</label>
                <p>{formatDate(patrimonio.data_aquisicao)}</p>
              </div>
            </div>
            {patrimonio.updated_at && (
              <div>
                <label className="text-sm font-medium text-gray-600">Última Atualização</label>
                <p>{formatDate(patrimonio.updated_at)}</p>
              </div>
            )}
          </div>

          {/* Garantia */}
          {patrimonio.garantia && (
            <div>
              <label className="text-sm font-medium text-gray-600">Garantia</label>
              <p>{patrimonio.garantia}</p>
            </div>
          )}

          <Separator />

          {/* Fornecedor */}
          {patrimonio.fornecedor && (
            <div>
              <label className="text-sm font-medium text-gray-600">Fornecedor</label>
              <p>{patrimonio.fornecedor}</p>
            </div>
          )}

          {/* Número de Série */}
          {patrimonio.numero_serie && (
            <div>
              <label className="text-sm font-medium text-gray-600">Número de Série</label>
              <p className="font-mono">{patrimonio.numero_serie}</p>
            </div>
          )}

          {/* Observações */}
          {patrimonio.observacoes && (
            <div>
              <div className="flex items-center gap-2 mb-2">
                <FileText className="h-4 w-4 text-gray-400" />
                <label className="text-sm font-medium text-gray-600">Observações</label>
              </div>
              <p className="text-gray-700 bg-gray-50 p-3 rounded-md">
                {patrimonio.observacoes}
              </p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
