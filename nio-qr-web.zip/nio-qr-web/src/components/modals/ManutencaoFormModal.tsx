
import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useApi } from '@/hooks/useApi';
import { toast } from '@/hooks/use-toast';

interface Patrimonio {
  id: string;
  codigo: string;
  nome: string;
}

interface Manutencao {
  id: string;
  protocolo: string;
  patrimonio_id: string;
  patrimonio_nome: string;
  patrimonio_codigo: string;
  tipo: 'Preventiva' | 'Corretiva' | 'Preditiva';
  status: 'Agendada' | 'Em Andamento' | 'Concluída' | 'Cancelada';
  prioridade: 'Baixa' | 'Normal' | 'Alta' | 'Crítica';
  descricao: string;
  tecnico: string;
  data_agendada: string;
  data_inicio?: string;
  data_fim?: string;
  custo?: number;
  observacoes?: string;
}

interface ManutencaoFormModalProps {
  manutencao?: Manutencao | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (data: Omit<Manutencao, 'id' | 'created_at'>) => void;
}

export default function ManutencaoFormModal({
  manutencao,
  open,
  onOpenChange,
  onSave
}: ManutencaoFormModalProps) {
  const [patrimonios, setPatrimonios] = useState<Patrimonio[]>([]);
  const [selectedPatrimonio, setSelectedPatrimonio] = useState<Patrimonio | null>(null);
  const [formData, setFormData] = useState({
    protocolo: '',
    patrimonio_id: '',
    tipo: 'Preventiva' as 'Preventiva' | 'Corretiva' | 'Preditiva',
    status: 'Agendada' as 'Agendada' | 'Em Andamento' | 'Concluída' | 'Cancelada',
    prioridade: 'Normal' as 'Baixa' | 'Normal' | 'Alta' | 'Crítica',
    descricao: '',
    tecnico: '',
    data_agendada: '',
    data_inicio: '',
    data_fim: '',
    custo: '',
    observacoes: ''
  });

  const { get } = useApi();

  useEffect(() => {
    if (open) {
      fetchPatrimonios();
    }
  }, [open]);

  useEffect(() => {
    if (manutencao) {
      setFormData({
        protocolo: manutencao.protocolo,
        patrimonio_id: manutencao.patrimonio_id,
        tipo: manutencao.tipo,
        status: manutencao.status,
        prioridade: manutencao.prioridade,
        descricao: manutencao.descricao,
        tecnico: manutencao.tecnico,
        data_agendada: manutencao.data_agendada.split('T')[0],
        data_inicio: manutencao.data_inicio?.split('T')[0] || '',
        data_fim: manutencao.data_fim?.split('T')[0] || '',
        custo: manutencao.custo?.toString() || '',
        observacoes: manutencao.observacoes || ''
      });
      
      const patrimonio = patrimonios.find(p => p.id === manutencao.patrimonio_id);
      if (patrimonio) {
        setSelectedPatrimonio(patrimonio);
      }
    } else {
      const now = new Date();
      setFormData({
        protocolo: `MAN${String(Date.now()).slice(-6)}`,
        patrimonio_id: '',
        tipo: 'Preventiva',
        status: 'Agendada',
        prioridade: 'Normal',
        descricao: '',
        tecnico: '',
        data_agendada: now.toISOString().split('T')[0],
        data_inicio: '',
        data_fim: '',
        custo: '',
        observacoes: ''
      });
      setSelectedPatrimonio(null);
    }
  }, [manutencao, open, patrimonios]);

  const fetchPatrimonios = async () => {
    try {
      const response = await get('/patrimonios');
      const result = await response.json();
      setPatrimonios(result.data || []);
    } catch (error) {
      console.error('Erro ao buscar patrimônios:', error);
      toast({
        title: 'Erro',
        description: 'Erro ao carregar patrimônios',
        variant: 'destructive',
      });
    }
  };

  const handlePatrimonioSelect = (patrimonioId: string) => {
    const patrimonio = patrimonios.find(p => p.id === patrimonioId);
    if (patrimonio) {
      setSelectedPatrimonio(patrimonio);
      setFormData(prev => ({ ...prev, patrimonio_id: patrimonioId }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedPatrimonio) {
      toast({
        title: 'Erro',
        description: 'Selecione um patrimônio',
        variant: 'destructive',
      });
      return;
    }

    onSave({
      protocolo: formData.protocolo,
      patrimonio_id: formData.patrimonio_id,
      patrimonio_nome: selectedPatrimonio.nome,
      patrimonio_codigo: selectedPatrimonio.codigo,
      tipo: formData.tipo,
      status: formData.status,
      prioridade: formData.prioridade,
      descricao: formData.descricao,
      tecnico: formData.tecnico,
      data_agendada: new Date(formData.data_agendada).toISOString(),
      data_inicio: formData.data_inicio ? new Date(formData.data_inicio).toISOString() : undefined,
      data_fim: formData.data_fim ? new Date(formData.data_fim).toISOString() : undefined,
      custo: formData.custo ? parseFloat(formData.custo) : undefined,
      observacoes: formData.observacoes || undefined
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {manutencao ? 'Editar Manutenção' : 'Nova Manutenção'}
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="protocolo">Protocolo *</Label>
              <Input
                id="protocolo"
                value={formData.protocolo}
                onChange={(e) => setFormData(prev => ({ ...prev, protocolo: e.target.value }))}
                required
                readOnly={!!manutencao}
              />
            </div>
            <div>
              <Label htmlFor="patrimonio">Item do Patrimônio *</Label>
              <Select 
                value={formData.patrimonio_id} 
                onValueChange={handlePatrimonioSelect}
                required
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione um patrimônio" />
                </SelectTrigger>
                <SelectContent>
                  {patrimonios.map((patrimonio) => (
                    <SelectItem key={patrimonio.id} value={patrimonio.id}>
                      {patrimonio.codigo} - {patrimonio.nome}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {selectedPatrimonio && (
            <div className="p-3 bg-blue-50 rounded-lg">
              <p className="text-sm font-medium text-blue-900">
                Patrimônio Selecionado: {selectedPatrimonio.codigo}
              </p>
              <p className="text-sm text-blue-700">{selectedPatrimonio.nome}</p>
            </div>
          )}

          <div className="grid grid-cols-3 gap-4">
            <div>
              <Label htmlFor="tipo">Tipo</Label>
              <Select 
                value={formData.tipo} 
                onValueChange={(value: 'Preventiva' | 'Corretiva' | 'Preditiva') => 
                  setFormData(prev => ({ ...prev, tipo: value }))
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Preventiva">Preventiva</SelectItem>
                  <SelectItem value="Corretiva">Corretiva</SelectItem>
                  <SelectItem value="Preditiva">Preditiva</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="status">Status</Label>
              <Select 
                value={formData.status} 
                onValueChange={(value: 'Agendada' | 'Em Andamento' | 'Concluída' | 'Cancelada') => 
                  setFormData(prev => ({ ...prev, status: value }))
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Agendada">Agendada</SelectItem>
                  <SelectItem value="Em Andamento">Em Andamento</SelectItem>
                  <SelectItem value="Concluída">Concluída</SelectItem>
                  <SelectItem value="Cancelada">Cancelada</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="prioridade">Prioridade</Label>
              <Select 
                value={formData.prioridade} 
                onValueChange={(value: 'Baixa' | 'Normal' | 'Alta' | 'Crítica') => 
                  setFormData(prev => ({ ...prev, prioridade: value }))
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Baixa">Baixa</SelectItem>
                  <SelectItem value="Normal">Normal</SelectItem>
                  <SelectItem value="Alta">Alta</SelectItem>
                  <SelectItem value="Crítica">Crítica</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label htmlFor="tecnico">Técnico Responsável *</Label>
            <Input
              id="tecnico"
              value={formData.tecnico}
              onChange={(e) => setFormData(prev => ({ ...prev, tecnico: e.target.value }))}
              required
            />
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <Label htmlFor="data_agendada">Data Agendada *</Label>
              <Input
                id="data_agendada"
                type="date"
                value={formData.data_agendada}
                onChange={(e) => setFormData(prev => ({ ...prev, data_agendada: e.target.value }))}
                required
              />
            </div>
            <div>
              <Label htmlFor="data_inicio">Data Início</Label>
              <Input
                id="data_inicio"
                type="date"
                value={formData.data_inicio}
                onChange={(e) => setFormData(prev => ({ ...prev, data_inicio: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="data_fim">Data Fim</Label>
              <Input
                id="data_fim"
                type="date"
                value={formData.data_fim}
                onChange={(e) => setFormData(prev => ({ ...prev, data_fim: e.target.value }))}
              />
            </div>
          </div>

          <div>
            <Label htmlFor="custo">Custo (R$)</Label>
            <Input
              id="custo"
              type="number"
              step="0.01"
              value={formData.custo}
              onChange={(e) => setFormData(prev => ({ ...prev, custo: e.target.value }))}
            />
          </div>

          <div>
            <Label htmlFor="descricao">Descrição *</Label>
            <Textarea
              id="descricao"
              value={formData.descricao}
              onChange={(e) => setFormData(prev => ({ ...prev, descricao: e.target.value }))}
              required
              rows={3}
            />
          </div>

          <div>
            <Label htmlFor="observacoes">Observações</Label>
            <Textarea
              id="observacoes"
              value={formData.observacoes}
              onChange={(e) => setFormData(prev => ({ ...prev, observacoes: e.target.value }))}
              rows={3}
            />
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button type="submit">
              {manutencao ? 'Atualizar' : 'Criar'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
