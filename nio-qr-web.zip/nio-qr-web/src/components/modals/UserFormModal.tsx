import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Usuario } from '@/types/usuario';

interface UserFormModalProps {
  usuario?: Usuario | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (data: Omit<Usuario, 'id'> & { senha?: string }) => void;
}

export default function UserFormModal({
  usuario,
  open,
  onOpenChange,
  onSave
}: UserFormModalProps) {
  const [formData, setFormData] = useState({
    nome: '',
    usuario: '',
    email: '',
    telefone: '',
    cargo: '',
    status: 'Ativo' as 'Ativo' | 'Inativo',
    senha: '',
    confirmarSenha: '',
    permissoes: {
      patrimonio: 'viewer' as 'admin' | 'viewer' | 'editor',
      usuarios: 'viewer' as 'admin' | 'viewer' | 'editor',
      localizacao: 'viewer' as 'admin' | 'viewer' | 'editor',
      manutencao: 'viewer' as 'admin' | 'viewer' | 'editor',
      seguros: 'viewer' as 'admin' | 'viewer' | 'editor',
      relatorios: 'viewer' as 'admin' | 'viewer' | 'editor',
      qrcodes: 'viewer' as 'admin' | 'viewer' | 'editor',
    }
  });

  useEffect(() => {
    if (usuario) {
      setFormData({
        nome: usuario.nome,
        usuario: usuario.usuario,
        email: usuario.email || '',
        telefone: usuario.telefone || '',
        cargo: usuario.cargo,
        status: usuario.status,
        senha: '',
        confirmarSenha: '',
        permissoes: {
          patrimonio: usuario.permissoes.patrimonio || 'viewer',
          usuarios: usuario.permissoes.usuarios || 'viewer',
          localizacao: usuario.permissoes.localizacao || 'viewer',
          manutencao: usuario.permissoes.manutencao || 'viewer',
          seguros: usuario.permissoes.seguros || 'viewer',
          relatorios: usuario.permissoes.relatorios || 'viewer',
          qrcodes: usuario.permissoes.qrcodes || 'viewer',
        }
      });
    } else {
      setFormData({
        nome: '',
        usuario: '',
        email: '',
        telefone: '',
        cargo: '',
        status: 'Ativo',
        senha: '',
        confirmarSenha: '',
        permissoes: {
          patrimonio: 'viewer',
          usuarios: 'viewer',
          localizacao: 'viewer',
          manutencao: 'viewer',
          seguros: 'viewer',
          relatorios: 'viewer',
          qrcodes: 'viewer',
        }
      });
    }
  }, [usuario, open]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!usuario && formData.senha !== formData.confirmarSenha) {
      alert('As senhas não coincidem');
      return;
    }

    const userData = {
      nome: formData.nome,
      usuario: formData.usuario,
      email: formData.email,
      telefone: formData.telefone,
      cargo: formData.cargo,
      status: formData.status,
      permissoes: formData.permissoes,
      criadoEm: new Date().toISOString(),
      ...(formData.senha && { senha: formData.senha })
    };

    onSave(userData);
  };

  const handlePermissaoChange = (modulo: string, nivel: 'admin' | 'viewer' | 'editor') => {
    setFormData(prev => ({
      ...prev,
      permissoes: {
        ...prev.permissoes,
        [modulo]: nivel
      }
    }));
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {usuario ? 'Editar Usuário' : 'Novo Usuário'}
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="nome">Nome Completo *</Label>
              <Input
                id="nome"
                value={formData.nome}
                onChange={(e) => setFormData(prev => ({ ...prev, nome: e.target.value }))}
                required
              />
            </div>
            <div>
              <Label htmlFor="usuario">Nome de Usuário *</Label>
              <Input
                id="usuario"
                value={formData.usuario}
                onChange={(e) => setFormData(prev => ({ ...prev, usuario: e.target.value }))}
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="email">E-mail *</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                required
              />
            </div>
            <div>
              <Label htmlFor="telefone">Telefone</Label>
              <Input
                id="telefone"
                value={formData.telefone}
                onChange={(e) => setFormData(prev => ({ ...prev, telefone: e.target.value }))}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="cargo">Cargo *</Label>
              <Input
                id="cargo"
                value={formData.cargo}
                onChange={(e) => setFormData(prev => ({ ...prev, cargo: e.target.value }))}
                required
              />
            </div>
            <div>
              <Label htmlFor="status">Status</Label>
              <Select 
                value={formData.status} 
                onValueChange={(value: 'Ativo' | 'Inativo') => 
                  setFormData(prev => ({ ...prev, status: value }))
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Ativo">Ativo</SelectItem>
                  <SelectItem value="Inativo">Inativo</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {!usuario && (
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="senha">Senha *</Label>
                <Input
                  id="senha"
                  type="password"
                  value={formData.senha}
                  onChange={(e) => setFormData(prev => ({ ...prev, senha: e.target.value }))}
                  required={!usuario}
                />
              </div>
              <div>
                <Label htmlFor="confirmarSenha">Confirmar Senha *</Label>
                <Input
                  id="confirmarSenha"
                  type="password"
                  value={formData.confirmarSenha}
                  onChange={(e) => setFormData(prev => ({ ...prev, confirmarSenha: e.target.value }))}
                  required={!usuario}
                />
              </div>
            </div>
          )}

          <div className="space-y-4">
            <Label className="text-base font-medium">Permissões por Módulo</Label>
            <div className="grid grid-cols-1 gap-4 bg-gray-50 p-4 rounded-lg">
              {Object.keys(formData.permissoes).map((modulo) => (
                <div key={modulo} className="flex items-center justify-between">
                  <Label className="capitalize">{modulo.replace('_', ' ')}</Label>
                  <Select
                    value={formData.permissoes[modulo]}
                    onValueChange={(value: 'admin' | 'viewer' | 'editor') => 
                      handlePermissaoChange(modulo, value)
                    }
                  >
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="viewer">Visualizar</SelectItem>
                      <SelectItem value="editor">Editar</SelectItem>
                      <SelectItem value="admin">Admin</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              ))}
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button type="submit">
              {usuario ? 'Atualizar' : 'Criar'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
