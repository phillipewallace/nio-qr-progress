
import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useApi } from '@/hooks/useApi';
import { toast } from '@/hooks/use-toast';

interface Localizacao {
  id: string;
  setor: string;
  sala: string;
  andar?: string;
  bloco?: string;
  capacidade?: number;
  responsavel?: string;
  descricao?: string;
  observacoes?: string;
}

interface LocalizacaoFormModalProps {
  localizacao?: Localizacao | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: () => void;
}

export default function LocalizacaoFormModal({
  localizacao,
  open,
  onOpenChange,
  onSave
}: LocalizacaoFormModalProps) {
  const [formData, setFormData] = useState({
    setor: '',
    sala: '',
    andar: '',
    bloco: '',
    capacidade: '',
    responsavel: '',
    descricao: '',
    observacoes: ''
  });
  const [loading, setLoading] = useState(false);

  const { post, put } = useApi();

  useEffect(() => {
    if (localizacao) {
      setFormData({
        setor: localizacao.setor,
        sala: localizacao.sala,
        andar: localizacao.andar || '',
        bloco: localizacao.bloco || '',
        capacidade: localizacao.capacidade?.toString() || '',
        responsavel: localizacao.responsavel || '',
        descricao: localizacao.descricao || '',
        observacoes: localizacao.observacoes || ''
      });
    } else {
      setFormData({
        setor: '',
        sala: '',
        andar: '',
        bloco: '',
        capacidade: '',
        responsavel: '',
        descricao: '',
        observacoes: ''
      });
    }
  }, [localizacao, open]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const data = {
        setor: formData.setor,
        sala: formData.sala,
        andar: formData.andar || undefined,
        bloco: formData.bloco || undefined,
        capacidade: formData.capacidade ? parseInt(formData.capacidade) : undefined,
        responsavel: formData.responsavel || undefined,
        descricao: formData.descricao || undefined,
        observacoes: formData.observacoes || undefined
      };

      if (localizacao) {
        await put(`/localizacoes/${localizacao.id}`, data);
        toast({
          title: 'Sucesso',
          description: 'Localização atualizada com sucesso',
        });
      } else {
        await post('/localizacoes', data);
        toast({
          title: 'Sucesso',
          description: 'Localização criada com sucesso',
        });
      }

      onSave();
      onOpenChange(false);
    } catch (error) {
      console.error('❌ [LocalizacaoFormModal] Erro ao salvar:', error);
      toast({
        title: 'Erro',
        description: 'Erro ao salvar localização',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>
            {localizacao ? 'Editar Localização' : 'Nova Localização'}
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="setor">Setor *</Label>
              <Input
                id="setor"
                value={formData.setor}
                onChange={(e) => setFormData(prev => ({ ...prev, setor: e.target.value }))}
                required
              />
            </div>
            <div>
              <Label htmlFor="sala">Sala *</Label>
              <Input
                id="sala"
                value={formData.sala}
                onChange={(e) => setFormData(prev => ({ ...prev, sala: e.target.value }))}
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="andar">Andar</Label>
              <Input
                id="andar"
                value={formData.andar}
                onChange={(e) => setFormData(prev => ({ ...prev, andar: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="bloco">Bloco</Label>
              <Input
                id="bloco"
                value={formData.bloco}
                onChange={(e) => setFormData(prev => ({ ...prev, bloco: e.target.value }))}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="capacidade">Capacidade</Label>
              <Input
                id="capacidade"
                type="number"
                value={formData.capacidade}
                onChange={(e) => setFormData(prev => ({ ...prev, capacidade: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="responsavel">Responsável</Label>
              <Input
                id="responsavel"
                value={formData.responsavel}
                onChange={(e) => setFormData(prev => ({ ...prev, responsavel: e.target.value }))}
              />
            </div>
          </div>

          <div>
            <Label htmlFor="descricao">Descrição</Label>
            <Textarea
              id="descricao"
              value={formData.descricao}
              onChange={(e) => setFormData(prev => ({ ...prev, descricao: e.target.value }))}
              rows={3}
            />
          </div>

          <div>
            <Label htmlFor="observacoes">Observações</Label>
            <Textarea
              id="observacoes"
              value={formData.observacoes}
              onChange={(e) => setFormData(prev => ({ ...prev, observacoes: e.target.value }))}
              rows={3}
            />
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? 'Salvando...' : (localizacao ? 'Atualizar' : 'Criar')}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
