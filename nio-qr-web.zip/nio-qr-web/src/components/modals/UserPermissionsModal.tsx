import { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Save, X, Shield } from 'lucide-react';
import { Usuario } from '@/types/usuario';

interface UserPermissionsModalProps {
  user: Usuario | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (permissoes: { [key: string]: 'viewer' | 'editor' | 'admin' }) => void;
}

const permissoesDisponiveis = [
  { id: 'patrimonio', nome: 'Patrimônio', descricao: 'Gerenciar itens do patrimônio' },
  { id: 'relatorios', nome: 'Relatórios', descricao: 'Gerar e visualizar relatórios' },
  { id: 'qrcodes', nome: 'QR Codes', descricao: 'Gerar e gerenciar QR Codes' },
  { id: 'localizacao', nome: 'Localização', descricao: 'Gerenciar localizações e setores' },
  { id: 'manutencao', nome: 'Manutenção', descricao: 'Gerenciar manutenções e ordens de serviço' },
  { id: 'seguros', nome: 'Seguros', descricao: 'Gerenciar seguros e apólices' },
  { id: 'usuarios', nome: 'Usuários', descricao: 'Gerenciar usuários e permissões' },
  { id: 'configuracoes', nome: 'Configurações', descricao: 'Acessar configurações do sistema' }
];

const niveisPermissao = [
  { value: 'viewer', label: 'Apenas Visualizar' },
  { value: 'editor', label: 'Visualizar e Editar' },
  { value: 'admin', label: 'Controle Total (Criar, Editar, Excluir)' }
];

export default function UserPermissionsModal({
  user,
  open,
  onOpenChange,
  onSave,
}: UserPermissionsModalProps) {
  const [selectedPermissions, setSelectedPermissions] = useState<{[key: string]: 'viewer' | 'editor' | 'admin'}>({});

  useEffect(() => {
    if (user && open) {
      setSelectedPermissions(user.permissoes || {});
    } else {
      setSelectedPermissions({});
    }
  }, [user, open]);

  const handlePermissionChange = (permissionId: string, checked: boolean) => {
    if (checked) {
      setSelectedPermissions(prev => ({ ...prev, [permissionId]: 'viewer' }));
    } else {
      setSelectedPermissions(prev => {
        const newPerms = { ...prev };
        delete newPerms[permissionId];
        return newPerms;
      });
    }
  };

  const handleLevelChange = (permissionId: string, level: 'viewer' | 'editor' | 'admin') => {
    setSelectedPermissions(prev => ({ ...prev, [permissionId]: level }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(selectedPermissions);
  };

  const handleSelectAll = () => {
    const allPermissions: {[key: string]: 'viewer' | 'editor' | 'admin'} = {};
    permissoesDisponiveis.forEach(perm => {
      allPermissions[perm.id] = 'viewer';
    });
    setSelectedPermissions(allPermissions);
  };

  const handleDeselectAll = () => {
    setSelectedPermissions({});
  };

  if (!user) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Permissões - {user.nome}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="flex justify-between items-center">
            <Label className="text-base font-medium">Módulos do Sistema</Label>
            <div className="flex gap-2">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={handleSelectAll}
              >
                Selecionar Todos
              </Button>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={handleDeselectAll}
              >
                Limpar
              </Button>
            </div>
          </div>

          <div className="space-y-3">
            {permissoesDisponiveis.map((permissao) => (
              <div
                key={permissao.id}
                className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50"
              >
                <div className="flex items-start space-x-3 flex-1">
                  <Checkbox
                    id={permissao.id}
                    checked={permissao.id in selectedPermissions}
                    onCheckedChange={(checked) =>
                      handlePermissionChange(permissao.id, checked as boolean)
                    }
                  />
                  <div className="flex-1">
                    <Label
                      htmlFor={permissao.id}
                      className="font-medium cursor-pointer"
                    >
                      {permissao.nome}
                    </Label>
                    <p className="text-sm text-gray-500 mt-1">
                      {permissao.descricao}
                    </p>
                  </div>
                </div>

                {permissao.id in selectedPermissions && (
                  <div className="ml-4 min-w-[200px]">
                    <Select
                      value={selectedPermissions[permissao.id]}
                      onValueChange={(value: 'viewer' | 'editor' | 'admin') => handleLevelChange(permissao.id, value)}
                    >
                      <SelectTrigger className="h-8">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {niveisPermissao.map((nivel) => (
                          <SelectItem key={nivel.value} value={nivel.value}>
                            {nivel.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
            <p className="text-sm text-blue-700">
              <strong>Permissões selecionadas:</strong> {Object.keys(selectedPermissions).length} de {permissoesDisponiveis.length} módulos
            </p>
            <div className="mt-2 text-xs text-blue-600">
              <strong>Níveis:</strong>
              <ul className="mt-1 space-y-1">
                <li>• <strong>Apenas Visualizar:</strong> Pode ver dados mas não modificar</li>
                <li>• <strong>Visualizar e Editar:</strong> Pode ver e modificar dados existentes</li>
                <li>• <strong>Controle Total:</strong> Pode criar, editar e excluir dados</li>
              </ul>
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="gap-2"
            >
              <X className="h-4 w-4" />
              Cancelar
            </Button>
            <Button type="submit" className="gap-2">
              <Save className="h-4 w-4" />
              Salvar Permissões
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
