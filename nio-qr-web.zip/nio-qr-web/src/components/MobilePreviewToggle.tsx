
import React from 'react';
import { Button } from '@/components/ui/button';
import { Smartphone, Monitor } from 'lucide-react';

export default function MobilePreviewToggle() {
  const isMobilePreview = window.location.search.includes('mobile=true');
  
  const toggleMobilePreview = () => {
    const url = new URL(window.location.href);
    if (isMobilePreview) {
      url.searchParams.delete('mobile');
    } else {
      url.searchParams.set('mobile', 'true');
    }
    window.location.href = url.toString();
  };

  return (
    <Button
      variant="outline"
      size="sm"
      onClick={toggleMobilePreview}
      className="gap-2"
    >
      {isMobilePreview ? (
        <>
          <Monitor className="h-4 w-4" />
          Web
        </>
      ) : (
        <>
          <Smartphone className="h-4 w-4" />
          Mobile
        </>
      )}
    </Button>
  );
}
