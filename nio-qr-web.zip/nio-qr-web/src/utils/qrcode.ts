
import QRCode from 'qrcode';

export const generateQRCode = async (data: string): Promise<string> => {
  try {
    const qrCodeDataURL = await QRCode.toDataURL(data, {
      width: 256,
      margin: 2,
      color: {
        dark: '#1f2937',
        light: '#ffffff'
      }
    });
    return qrCodeDataURL;
  } catch (error) {
    console.error('Erro ao gerar QR Code:', error);
    throw error;
  }
};

export const generatePatrimonioQRCode = async (patrimonioId: string): Promise<string> => {
  const baseUrl = window.location.origin;
  const patrimonioUrl = `${baseUrl}/patrimonio/${patrimonioId}`;
  return generateQRCode(patrimonioUrl);
};

export const downloadQRCode = (qrCodeDataURL: string, filename: string) => {
  const link = document.createElement('a');
  link.download = `${filename}-qrcode.png`;
  link.href = qrCodeDataURL;
  link.click();
};
