
import { useAuth } from '@/contexts/AuthContext';

export const useApi = () => {
  const { token, logout } = useAuth();
  
  // Detectar a URL da API automaticamente
  const getCurrentApiUrl = () => {
    const currentHost = window.location.hostname;
    const currentProtocol = window.location.protocol;
    return `${currentProtocol}//${currentHost}:3001/api`;
  };
  
  const API_BASE_URL = getCurrentApiUrl();

  console.log('🔧 [useApi] API_BASE_URL configurado:', API_BASE_URL);

  const apiRequest = async (
    endpoint: string,
    options: RequestInit = {}
  ): Promise<Response> => {
    const url = `${API_BASE_URL}${endpoint}`;
    const timestamp = new Date().toISOString();
    
    console.log(`\n🌐 [API ${timestamp}] === NOVA REQUISIÇÃO ===`);
    console.log(`📍 [API] ${options.method || 'GET'} ${url}`);
    console.log(`🎫 [API] Token presente: ${!!token}`);

    const headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      ...(token && { 'Authorization': `Bearer ${token}` }),
      ...options.headers,
    };

    console.log('📋 [API] Headers da requisição:');
    Object.entries(headers).forEach(([key, value]) => {
      if (key === 'Authorization') {
        console.log(`  ${key}: Bearer [TOKEN PRESENTE]`);
      } else {
        console.log(`  ${key}: ${value}`);
      }
    });

    if (options.body) {
      console.log('📦 [API] Body da requisição:', options.body);
    }

    try {
      console.log('⏳ [API] Enviando requisição...');
      
      const response = await fetch(url, {
        ...options,
        headers,
      });

      console.log(`📨 [API] Resposta recebida:`);
      console.log(`  Status: ${response.status} ${response.statusText}`);
      console.log(`  Headers:`, Object.fromEntries(response.headers.entries()));

      if (response.status === 401) {
        console.log('🚫 [API] Token inválido (401) - executando logout...');
        logout();
        return response;
      }

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`❌ [API] Erro na resposta (${response.status}):`, errorText);
        
        let errorMessage = `HTTP ${response.status}`;
        try {
          const errorData = JSON.parse(errorText);
          errorMessage = errorData.error || errorMessage;
        } catch {
          errorMessage = errorText || errorMessage;
        }
        
        throw new Error(`${errorMessage}`);
      }

      console.log('✅ [API] Requisição bem-sucedida');
      return response;
    } catch (error) {
      console.error('\n❌ [API] ERRO NA REQUISIÇÃO:');
      console.error('  URL:', url);
      console.error('  Método:', options.method || 'GET');
      console.error('  Tipo do erro:', error instanceof Error ? error.constructor.name : typeof error);
      console.error('  Mensagem:', error instanceof Error ? error.message : String(error));
      console.error('  Stack:', error instanceof Error ? error.stack : 'N/A');
      
      throw error;
    }
  };

  const get = async (endpoint: string) => {
    console.log(`🔍 [API] GET Request: ${endpoint}`);
    return apiRequest(endpoint, { method: 'GET' });
  };
  
  const post = async (endpoint: string, data?: any) => {
    console.log(`📝 [API] POST Request: ${endpoint}`);
    if (data) console.log(`📦 [API] POST Data:`, data);
    
    return apiRequest(endpoint, {
      method: 'POST',
      body: data ? JSON.stringify(data) : undefined,
    });
  };

  const put = async (endpoint: string, data?: any) => {
    console.log(`✏️ [API] PUT Request: ${endpoint}`);
    if (data) console.log(`📦 [API] PUT Data:`, data);
    
    return apiRequest(endpoint, {
      method: 'PUT',
      body: data ? JSON.stringify(data) : undefined,
    });
  };

  const del = async (endpoint: string) => {
    console.log(`🗑️ [API] DELETE Request: ${endpoint}`);
    return apiRequest(endpoint, { method: 'DELETE' });
  };

  return { get, post, put, delete: del, apiRequest, API_BASE_URL };
};
