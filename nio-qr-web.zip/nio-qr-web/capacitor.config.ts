
import { CapacitorConfig } from '@capacitor/core';

const config: CapacitorConfig = {
  appId: 'app.lovable.dc60a696195c449fbf2dde786be69585',
  appName: 'nio-qr-web',
  webDir: 'dist',
  server: {
    url: 'https://dc60a696-195c-449f-bf2d-de786be69585.lovableproject.com?forceHideBadge=true',
    cleartext: true
  },
  plugins: {
    Camera: {
      permissions: {
        camera: 'Camera access is required to take photos of patrimony items.',
        photos: 'Photo library access is required to select photos.'
      }
    }
  }
};

export default config;
